/**
 * VALE DO CREPÚSCULO - MOTOR DO JOGO E CONTROLADOR PRINCIPAL
 * Gerencia ciclo de jogo, seleção de personagens (Luis, Sofi, Rebeca), movimentação, colisões, agricultura e decoração
 */

class FarmRPGGame {
    constructor() {
        this.canvas = document.getElementById('game-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.renderer = new GameRenderer(this.canvas, this.ctx);

        // Estado Geral
        this.state = this.loadSaveData() || this.getDefaultState();
        
        // Migração suave de saves com nomes anteriores
        if (this.state.player.characterId === 'lucas') this.state.player.characterId = 'luis';
        if (this.state.player.characterId === 'maya' || this.state.player.characterId === 'sofi') this.state.player.characterId = 'sofia';
        if (this.state.player.characterId === 'aisha') this.state.player.characterId = 'rebeca';

        // Migração: saves antigos podem ter móveis/personagem dentro da parede da casa
        if (Array.isArray(this.state.placedFurniture)) {
            this.state.placedFurniture.forEach(item => {
                if (!FURNITURE_CATALOG[item.type]) return;
                const minY = getFurnitureMinY(item.type);
                if (item.y < minY) item.y = minY;
            });
        }
        if (this.state.currentScene === 'house' || this.state.currentScene === 'house2') {
            const hc = MAP_CONFIG.house;
            const minPy = hc.roomBounds.startY * MAP_CONFIG.tileSize + 4 - 20;
            if (this.state.player.y < minPy) this.state.player.y = minPy;
        }

        if (!this.state.player.characterId || !CHARACTERS[this.state.player.characterId]) {
            this.state.player.characterId = 'luis';
        }

        // Migração: o mapa da fazenda virou um mundo maior (v2) - reposiciona canteiros e jogador
        if (this.state && (this.state.worldVersion || 1) < 2) {
            const OLD = { startX: 9, startY: 6, endX: 18, endY: 11 };
            const NEW = MAP_CONFIG.farm.soilBounds;
            const dx = NEW.startX - OLD.startX, dy = NEW.startY - OLD.startY;
            if (Array.isArray(this.state.farmPlots)) {
                this.state.farmPlots.forEach(p => {
                    if (p.x >= OLD.startX && p.x <= OLD.endX && p.y >= OLD.startY && p.y <= OLD.endY) {
                        p.x += dx; p.y += dy;
                    }
                });
            }
            if (this.state.currentScene === 'farm' && this.state.player) {
                this.state.player.x = MAP_CONFIG.farm.spawn.x * 32;
                this.state.player.y = MAP_CONFIG.farm.spawn.y * 32;
            }
            this.state.worldVersion = 2;
        }

        // Save antigo que ficou na Vila/Feira (removida): volta para a fazenda, perto do portão leste
        if (this.state && this.state.currentScene === 'town' && this.state.player) {
            this.state.currentScene = 'farm';
            this.state.player.x = MAP_CONFIG.farm.worldW - 5 * 32;
            this.state.player.y = 18 * 32;
        }

        if (this.state && this.state.currentScene === 'barn' && this.state.player && window.BARN_WORLD) {
            const pl = this.state.player;
            const box = { left: pl.x + 8, right: pl.x + 24, top: pl.y + 20, bottom: pl.y + 30 };
            if (pl.x > window.BARN_WORLD.w || pl.y > window.BARN_WORLD.h || window.barnWorldBlocked(box)) {
                pl.x = window.BARN_WORLD.entry.x;
                pl.y = window.BARN_WORLD.entry.y;
            }
        }

        if (this.state && this.state.currentScene === 'barnin' && this.state.player && window.BARN_INSIDE) {
            window.BARN_INSIDE.kind = this.state.barnInKind || 'cow';
            const pl = this.state.player;
            const box = { left: pl.x + 6, right: pl.x + 26, top: pl.y + 19, bottom: pl.y + 31 };
            if (window.barnInsideBlocked(box)) {
                pl.x = window.BARN_INSIDE.entry.x;
                pl.y = window.BARN_INSIDE.entry.y;
            }
        }

        if (this.state && this.state.currentScene === 'city' && this.state.player && window.CITY_WORLD) {
            const pl = this.state.player;
            const box = { left: pl.x + 8, right: pl.x + 24, top: pl.y + 20, bottom: pl.y + 30 };
            if (window.cityWorldBlocked(box)) {
                pl.x = window.CITY_WORLD.entry.x;
                pl.y = window.CITY_WORLD.entry.y;
            }
        }

        // Garante que todos os canteiros da fazenda estejam sincronizados
        if (this.state && this.state.farmPlots) {
            const bounds = MAP_CONFIG.farm.soilBounds;
            for (let y = bounds.startY; y <= bounds.endY; y++) {
                for (let x = bounds.startX; x <= bounds.endX; x++) {
                    if (!this.state.farmPlots.some(p => p.x === x && p.y === y)) {
                        this.state.farmPlots.push({
                            x: x,
                            y: y,
                            state: 'dry',
                            isWatered: false,
                            crop: null
                        });
                    }
                }
            }
        }

        // Estado dos NPCs Companheiros e Diálogos Stardew Valley
        this.npcState = {};
        this.isDialogueOpen = false;
        this.currentDialogueNpc = null;

        // Estado Transiente de Controle
        this.keys = {};
        this.activeTool = 'hoe';
        this.activeSeed = 'carrot';
        this.activeCrop = null;
        this.interactionPrompt = null;
        this.currentInteractiveTarget = null;

        // Sistema de Seleção e Marcações de Solo (Soltar para Executar)
        this.soilSelection = {
            active: false,
            source: null, // 'mouse' | 'keyboard'
            selectedPlots: [],
            reachRadius: 96,
            hoverTile: null,
            tool: null,
            seed: null
        };

        // Hotbar Stardew Valley (12 Caixas Oficiais)
        this.activeHotbarIndex = 0;
        this.hotbarConfig = [
            {
                id: 'hoe',
                key: '1',
                type: 'tool',
                tool: 'hoe',
                name: 'Enxada',
                subtext: 'Ferramenta Básica',
                desc: 'Prepara o solo arando a terra para receber o plantio de culturas.',
                iconHtml: `<svg width="26" height="26" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="shape-rendering: crispEdges;"><rect x="2" y="13" width="2" height="2" fill="#5c2e0b"/><rect x="3" y="12" width="2" height="2" fill="#8b4513"/><rect x="4" y="11" width="2" height="2" fill="#a0522d"/><rect x="5" y="10" width="2" height="2" fill="#8b4513"/><rect x="6" y="9" width="2" height="2" fill="#a0522d"/><rect x="7" y="8" width="2" height="2" fill="#8b4513"/><rect x="8" y="7" width="2" height="2" fill="#a0522d"/><rect x="9" y="6" width="2" height="2" fill="#8b4513"/><rect x="10" y="5" width="2" height="2" fill="#475569"/><rect x="11" y="3" width="3" height="2" fill="#94a3b8"/><rect x="12" y="2" width="3" height="2" fill="#cbd5e1"/><rect x="11" y="5" width="2" height="4" fill="#64748b"/><rect x="12" y="6" width="2" height="3" fill="#94a3b8"/><rect x="13" y="2" width="2" height="1" fill="#f8fafc"/></svg>`
            },
            {
                id: 'water',
                key: '2',
                type: 'tool',
                tool: 'water',
                name: 'Regador',
                subtext: 'Ferramenta Básica',
                desc: 'Rega a terra arada e os brotos em crescimento para acelerar o cultivo.',
                iconHtml: `<svg width="26" height="26" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="shape-rendering: crispEdges;"><rect x="4" y="7" width="7" height="6" fill="#3b82f6"/><rect x="5" y="8" width="5" height="4" fill="#60a5fa"/><rect x="5" y="8" width="2" height="2" fill="#93c5fd"/><rect x="4" y="13" width="7" height="1" fill="#1d4ed8"/><rect x="3" y="8" width="1" height="5" fill="#1e40af"/><rect x="5" y="6" width="5" height="1" fill="#93c5fd"/><rect x="1" y="8" width="3" height="1" fill="#1d4ed8"/><rect x="1" y="9" width="1" height="3" fill="#2563eb"/><rect x="1" y="12" width="3" height="1" fill="#1d4ed8"/><rect x="11" y="9" width="2" height="2" fill="#60a5fa"/><rect x="13" y="7" width="2" height="2" fill="#93c5fd"/><rect x="14" y="5" width="2" height="3" fill="#cbd5e1"/><rect x="14" y="5" width="1" height="1" fill="#ffffff"/><rect x="13" y="10" width="1" height="2" fill="#38bdf8"/></svg>`
            },
            {
                id: 'harvest',
                key: '3',
                type: 'tool',
                tool: 'harvest',
                name: 'Foice / Colheita',
                subtext: 'Ferramenta Básica',
                desc: 'Colhe os vegetais maduros dos canteiros para o seu estoque.',
                iconHtml: `<svg width="26" height="26" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="shape-rendering: crispEdges;"><rect x="3" y="13" width="2" height="2" fill="#5c2e0b"/><rect x="4" y="11" width="2" height="2" fill="#8b4513"/><rect x="5" y="9" width="2" height="2" fill="#a0522d"/><rect x="6" y="7" width="2" height="2" fill="#8b4513"/><rect x="7" y="5" width="2" height="2" fill="#a0522d"/><rect x="7" y="3" width="3" height="2" fill="#64748b"/><rect x="9" y="2" width="4" height="2" fill="#cbd5e1"/><rect x="13" y="3" width="2" height="2" fill="#94a3b8"/><rect x="14" y="5" width="1" height="2" fill="#64748b"/><rect x="10" y="2" width="3" height="1" fill="#ffffff"/><rect x="8" y="4" width="3" height="1" fill="#e2e8f0"/></svg>`
            },
            {
                id: 'seed_carrot',
                key: '4',
                type: 'seed',
                cropId: 'carrot',
                name: 'Sem. Cenoura',
                subtext: 'Semente • 2 dias',
                desc: 'Sementes de cenoura fresca. Tempo de crescimento: 2 dias.',
                badge: '🌱',
                iconEmoji: '🥕'
            },
            {
                id: 'seed_strawberry',
                key: '5',
                type: 'seed',
                cropId: 'strawberry',
                name: 'Sem. Morango',
                subtext: 'Semente • 3 dias',
                desc: 'Sementes de morango doce. Tempo de crescimento: 3 dias.',
                badge: '🌱',
                iconEmoji: '🍓'
            },
            {
                id: 'seed_corn',
                key: '6',
                type: 'seed',
                cropId: 'corn',
                name: 'Sem. Milho',
                subtext: 'Semente • 4 dias',
                desc: 'Sementes de milho dourado. Tempo de crescimento: 4 dias.',
                badge: '🌱',
                iconEmoji: '🌽'
            },
            {
                id: 'seed_pumpkin',
                key: '7',
                type: 'seed',
                cropId: 'pumpkin',
                name: 'Sem. Abóbora',
                subtext: 'Semente • 5 dias',
                desc: 'Sementes de abóbora robusta. Tempo de crescimento: 5 dias.',
                badge: '🌱',
                iconEmoji: '🎃'
            },
            {
                id: 'crop_carrot',
                key: '8',
                type: 'crop',
                cropId: 'carrot',
                name: 'Cenoura Fresca',
                subtext: 'Colheita • Venda: 20g',
                desc: 'Cenouras colhidas da fazenda. Venda no baú ao lado da casa!',
                badge: '🧺',
                iconEmoji: '🥕'
            },
            {
                id: 'crop_strawberry',
                key: '9',
                type: 'crop',
                cropId: 'strawberry',
                name: 'Morango Doce',
                subtext: 'Colheita • Venda: 46g',
                desc: 'Morangos doces colhidos. Alto valor de venda no mercado!',
                badge: '🧺',
                iconEmoji: '🍓'
            },
            {
                id: 'crop_corn',
                key: '0',
                type: 'crop',
                cropId: 'corn',
                name: 'Milho Dourado',
                subtext: 'Colheita • Venda: 85g',
                desc: 'Espigas de milho maduras e nutritivas.',
                badge: '🧺',
                iconEmoji: '🌽'
            },
            {
                id: 'crop_pumpkin',
                key: '-',
                type: 'crop',
                cropId: 'pumpkin',
                name: 'Abóbora Madura',
                subtext: 'Colheita • Venda: 165g',
                desc: 'Abóbora gigante e pesada. O cultivo mais lucrativo do vale!',
                badge: '🧺',
                iconEmoji: '🎃'
            },
            {
                id: 'shipping_bin',
                key: '=',
                type: 'action',
                action: 'shipping',
                name: 'Baú de Vendas',
                subtext: 'Celeiro Comercial',
                desc: 'Venda toda a colheita guardada em troca de ouro imediato!',
                badge: '🪙',
                iconEmoji: '📦'
            }
        ];

        // Estado do Modo Decoração (Casa)
        this.decorMode = false;
        this.draggedFurniture = null;
        this.dragGhostPos = { x: 0, y: 0 };
        this.dragGhostValid = false;
        this.selectedPlacedFurniture = null;

        this.initDOM();
        this.bindEvents();
        this.updateUI();
        this.updateCharacterUI();

        // Loop Principal
        this.lastFrameTime = performance.now();
        this.loop = this.loop.bind(this);
        requestAnimationFrame(this.loop);

        if (!localStorage.getItem('stardew_rpg_first_time')) {
            this.openModal('modal-character');
            localStorage.setItem('stardew_rpg_first_time', 'true');
        }
    }

    getDefaultState() {
        const farmPlots = [];
        const bounds = MAP_CONFIG.farm.soilBounds;
        for (let y = bounds.startY; y <= bounds.endY; y++) {
            for (let x = bounds.startX; x <= bounds.endX; x++) {
                farmPlots.push({
                    x: x,
                    y: y,
                    state: 'dry',
                    isWatered: false,
                    crop: null
                });
            }
        }

        const initialFurniture = [
            { id: 1, type: 'bed_royal', x: 12, y: 3 },
            { id: 2, type: 'rug_purple', x: 6, y: 4 },
            { id: 3, type: 'lamp_cozy', x: 11, y: 3 }
        ];

        return {
            currentScene: 'farm',
            player: {
                characterId: 'luis', // 'luis', 'sofi' ou 'rebeca'
                x: MAP_CONFIG.farm.spawn.x * 32,
                y: MAP_CONFIG.farm.spawn.y * 32,
                width: 32,
                height: 32,
                speed: 3.2,
                dir: 'down',
                isMoving: false,
                stamina: 100,
                maxStamina: 100
            },
            day: 1,
            time: 360, // minutos desde 00:00 (06:00 = início do dia; 1440 = meia-noite; 1560 = 02:00 desmaio)
            gold: 80,
            weather: 'sunny',
            inventory: {
                seeds: {
                    carrot: 5,
                    strawberry: 3,
                    corn: 0,
                    pumpkin: 0
                },
                crops: {
                    carrot: 0,
                    strawberry: 0,
                    corn: 0,
                    pumpkin: 0
                },
                furniture: ['sofa_indigo', 'plant_pot']
            },
            farmPlots: farmPlots,
            placedFurniture: initialFurniture,
            nextFurnitureId: 4,
            worldVersion: 2
        };
    }

    saveState() {
        try {
            localStorage.setItem('stardew_rpg_save', JSON.stringify(this.state));
        } catch (e) {
            console.warn('Erro ao salvar estado:', e);
        }
    }

    loadSaveData() {
        try {
            const data = localStorage.getItem('stardew_rpg_save');
            return data ? JSON.parse(data) : null;
        } catch (e) {
            return null;
        }
    }

    resetGame() {
        if (confirm('Deseja realmente reiniciar todo o progresso do RPG da Fazenda?')) {
            localStorage.removeItem('stardew_rpg_save');
            this.state = this.getDefaultState();
            this.saveState();
            this.updateUI();
            this.updateCharacterUI();
            this.showToast('Jogo Reiniciado do Zero!', 'gold');
            this.closeAllModals();
        }
    }

    // ==========================================================
    // SISTEMA DE SELEÇÃO DE PERSONAGENS (LUIS, SOFI, REBECA)
    // ==========================================================
    selectCharacter(charId) {
        if (!CHARACTERS[charId]) return;

        this.state.player.characterId = charId;
        const charDef = CHARACTERS[charId];

        window.soundManager.playClick();
        this.updateCharacterUI();
        this.closeDialogue();
        this.saveState();
        this.closeAllModals();
        this.showToast(`Agora jogando como ${charDef.name}!`, 'plant');
    }

    updateCharacterUI() {
        const charId = this.state.player.characterId || 'luis';
        const charDef = CHARACTERS[charId] || CHARACTERS.luis;

        if (this.dom.hudCharacterAvatar) {
            this.dom.hudCharacterAvatar.src = charDef.avatar;
        }
        if (this.dom.hudCharacterName) {
            this.dom.hudCharacterName.textContent = charDef.name;
        }

        document.querySelectorAll('.character-select-card').forEach(card => {
            const isSelected = card.dataset.charId === charId;
            card.classList.toggle('selected', isSelected);
            const btn = card.querySelector('.char-pick-btn');
            if (btn) {
                btn.textContent = isSelected ? '✓ Personagem Ativo' : 'Escolher';
                btn.disabled = isSelected;
            }
        });
    }

    // ==========================================================
    // SISTEMA DE NPCS COMPANHEIROS (LUIS, SOFIA, REBECA NO MUNDO)
    // ==========================================================
        getActiveNPCs() {
        const playerCharId = (this.state.player.characterId === 'sofi') ? 'sofia' : (this.state.player.characterId || 'luis');
        const allChars = ['luis', 'sofia', 'rebeca'];
        const otherChars = allChars.filter(id => id !== playerCharId);
        const scene = this.state.currentScene;

        // Moradores da cidade (Arthur, Evelyn, Pietro, Daniel, Mary, Thiago, Padre, Regina, Dr. Antonie e Princesa)
        if (scene === 'city') {
            if (!this.npcState) this.npcState = {};
            return (window.TOWN_NPCS || []).map(n => {
                if (!this.npcState[n.id]) this.npcState[n.id] = { dir: n.dir, quoteIndex: 0, x: n.fx - 16, y: n.fy - 30, targetX: n.fx - 16, targetY: n.fy - 30 };
                
                // Movimento simples da Princesa (pet)
                if (n.isPet && this.npcState[n.id]) {
                    const state = this.npcState[n.id];
                    if (Math.hypot(state.targetX - state.x, state.targetY - state.y) < 5) {
                        // Novo alvo perto da Evelyn
                        state.targetX = 1424 - 16 + (Math.random() * 60 - 30);
                        state.targetY = 608 - 30 + (Math.random() * 40 - 20);
                    } else {
                        const dx = state.targetX - state.x;
                        const dy = state.targetY - state.y;
                        const dist = Math.hypot(dx, dy);
                        state.x += (dx / dist) * 0.5;
                        state.y += (dy / dist) * 0.5;
                        if (Math.abs(dx) > Math.abs(dy)) {
                            state.dir = dx > 0 ? 'right' : 'left';
                        } else {
                            state.dir = dy > 0 ? 'down' : 'up';
                        }
                    }
                } else {
                    this.npcState[n.id].x = n.fx - 16;
                    this.npcState[n.id].y = n.fy - 30;
                }

                return {
                    id: n.id, characterId: n.id, town: true, name: n.name, title: n.title, avatar: n.avatar,
                    scene: 'city', x: this.npcState[n.id].x, y: this.npcState[n.id].y,
                    dir: this.npcState[n.id].dir || n.dir, animOffset: n.anim || 0, isPet: n.isPet
                };
            });
        }

        // Os personagens não selecionados ficam somente na Casa dos Amigos ou trabalhando na Fazenda
        if (scene === 'house2') {
            return otherChars.map(id => {
                const charDef = CHARACTERS[id] || CHARACTERS.rebeca;
                const spawnTable = (window.NPC_SPAWNS && window.NPC_SPAWNS[scene]) || {};
                const spawn = spawnTable[id] || { x: 7 * 32, y: 7 * 32, dir: 'down', animOffset: 0 };

                if (!this.npcState) this.npcState = {};
                if (!this.npcState[id]) {
                    this.npcState[id] = { dir: spawn.dir, quoteIndex: 0 };
                }

                return {
                    id: id,
                    characterId: id,
                    name: charDef.name,
                    title: charDef.title,
                    avatar: charDef.avatar,
                    scene: scene,
                    x: spawn.x,
                    y: spawn.y,
                    dir: this.npcState[id].dir || spawn.dir,
                    animOffset: spawn.animOffset || 0
                };
            });
        }

        // NOVO: NPCs trabalhando na fazenda
        if (scene === 'farm') {
            return otherChars.map(id => {
                const charDef = CHARACTERS[id] || CHARACTERS.rebeca;
                
                if (!this.npcState) this.npcState = {};
                if (!this.npcState[id] || !this.npcState[id].targetX) {
                    // Posições iniciais perto dos canteiros
                    const bounds = MAP_CONFIG.farm.soilBounds;
                    this.npcState[id] = { 
                        dir: 'down', 
                        quoteIndex: 0,
                        x: (bounds.startX + Math.random() * (bounds.endX - bounds.startX)) * 32,
                        y: (bounds.startY - 2 + Math.random() * 2) * 32,
                        targetX: (bounds.startX + Math.random() * (bounds.endX - bounds.startX)) * 32,
                        targetY: (bounds.startY - 2 + Math.random() * 2) * 32,
                        actionTimer: 0
                    };
                }

                const state = this.npcState[id];
                
                // Lógica de movimento simples na fazenda
                if (Math.hypot(state.targetX - state.x, state.targetY - state.y) < 5) {
                    state.actionTimer -= 1;
                    if (state.actionTimer <= 0) {
                        // Escolhe um novo canteiro para "trabalhar"
                        const bounds = MAP_CONFIG.farm.soilBounds;
                        state.targetX = (bounds.startX + Math.random() * (bounds.endX - bounds.startX)) * 32;
                        state.targetY = (bounds.startY - 1 + Math.random() * 2) * 32;
                        state.actionTimer = 60 + Math.random() * 120; // Fica um tempo "trabalhando"
                        state.dir = Math.random() > 0.5 ? 'left' : 'right';
                    }
                } else {
                    const dx = state.targetX - state.x;
                    const dy = state.targetY - state.y;
                    const dist = Math.hypot(dx, dy);
                    state.x += (dx / dist) * 1.5;
                    state.y += (dy / dist) * 1.5;
                    if (Math.abs(dx) > Math.abs(dy)) {
                        state.dir = dx > 0 ? 'right' : 'left';
                    } else {
                        state.dir = dy > 0 ? 'down' : 'up';
                    }
                }

                return {
                    id: id,
                    characterId: id,
                    name: charDef.name,
                    title: charDef.title,
                    avatar: charDef.avatar,
                    scene: scene,
                    x: state.x,
                    y: state.y,
                    dir: state.dir,
                    animOffset: Math.random() * 3
                };
            });
        }

        return [];
    }

    openDialogue(npc) {
        window.soundManager.playDialogueBlip();
        this.currentDialogueNpc = npc;
        const dialogues = (npc.town && window.TOWN_DIALOGUES && window.TOWN_DIALOGUES[npc.id] && { quotes: window.TOWN_DIALOGUES[npc.id] }) || (window.NPC_DIALOGUES && (window.NPC_DIALOGUES[npc.characterId] || window.NPC_DIALOGUES[npc.id])) || {
            quotes: ["Olá, que lindo dia no Vale do Crepúsculo!"]
        };
        const quotes = dialogues.quotes;

        if (!this.npcState) this.npcState = {};
        if (!this.npcState[npc.id]) this.npcState[npc.id] = { quoteIndex: 0, dir: npc.dir };

        // NPC da cidade vira o rosto para o jogador
        if (npc.town && this.state && this.state.player) {
            const dx = (this.state.player.x) - npc.x, dy = (this.state.player.y) - npc.y;
            this.npcState[npc.id].dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
        }
        if (this.dom.dialogueSwitchBtn) this.dom.dialogueSwitchBtn.style.display = npc.town ? 'none' : '';

        const qIdx = this.npcState[npc.id].quoteIndex % quotes.length;
        const text = quotes[qIdx];
        this.npcState[npc.id].quoteIndex = (qIdx + 1) % quotes.length;

        if (this.dom.dialogueBox) {
            this.dom.dialogueBox.style.display = 'flex';
            if (this.dom.dialogueAvatar) this.dom.dialogueAvatar.src = npc.avatar;
            if (this.dom.dialogueSpeakerName) this.dom.dialogueSpeakerName.textContent = npc.name;
            if (this.dom.dialogueSpeakerTitle) this.dom.dialogueSpeakerTitle.textContent = npc.title;
            if (this.dom.dialogueText) this.dom.dialogueText.textContent = `"${text}"`;
            if (this.dom.dialogueSwitchTargetName) this.dom.dialogueSwitchTargetName.textContent = npc.name;
        }
        if (this.dom.hotbarContainer) {
            this.dom.hotbarContainer.style.display = 'none';
        }
        this.isDialogueOpen = true;
    }

    advanceOrCloseDialogue() {
        if (!this.isDialogueOpen || !this.currentDialogueNpc) {
            this.closeDialogue();
            return;
        }
        window.soundManager.playDialogueBlip();
        this.closeDialogue();
    }

    closeDialogue() {
        if (this.dom.dialogueBox) {
            this.dom.dialogueBox.style.display = 'none';
        }
        if (this.dom.hotbarContainer) {
            this.dom.hotbarContainer.style.display = 'flex';
        }
        this.isDialogueOpen = false;
        this.currentDialogueNpc = null;
    }

    // ==========================================================
    // INICIALIZAÇÃO DE ELEMENTOS DOM E EVENTOS
    // ==========================================================
    initDOM() {
        this.dom = {
            dayDisplay: document.getElementById('hud-day'),
            clockDisplay: document.getElementById('hud-clock'),
            clockIcon: document.getElementById('hud-clock-icon'),
            goldDisplay: document.getElementById('hud-gold'),
            weatherDisplay: document.getElementById('hud-weather'),
            locationDisplay: document.getElementById('hud-location'),
            // Personagem no HUD
            btnCharacterBadge: document.getElementById('btn-open-character-select'),
            hudCharacterAvatar: document.getElementById('hud-character-avatar'),
            hudCharacterName: document.getElementById('hud-character-name'),
            // Hotbar Estilo Stardew Valley (Caixas de Inventário)
            hotbarContainer: document.getElementById('stardew-hotbar-container'),
            hotbar: document.getElementById('stardew-hotbar'),
            hotbarTooltip: document.getElementById('sdv-hotbar-tooltip'),
            hotbarTooltipTitle: document.getElementById('sdv-tooltip-title'),
            hotbarTooltipSub: document.getElementById('sdv-tooltip-sub'),
            hotbarTooltipDesc: document.getElementById('sdv-tooltip-desc'),
            // Painel / Modo Decoração
            btnToggleDecor: document.getElementById('btn-toggle-decor'),
            decorDrawer: document.getElementById('decor-drawer'),
            furnitureStockContainer: document.getElementById('furniture-stock-list'),
            // Ações Globais
            btnShop: document.getElementById('btn-open-shop'),
            btnTutorial: document.getElementById('btn-tutorial'),
            btnSoundToggle: document.getElementById('btn-sound-toggle'),
            btnFullscreenToggle: document.getElementById('btn-fullscreen-toggle'),
            // Modais
            modalShop: document.getElementById('modal-shop'),
            modalTutorial: document.getElementById('modal-tutorial'),
            modalNightRecap: document.getElementById('modal-night-recap'),
            modalCharacter: document.getElementById('modal-character'),
            nightRecapDetails: document.getElementById('night-recap-details'),
            shopItemsList: document.getElementById('shop-items-container'),
            shopCategoryTabs: document.querySelectorAll('.shop-tab-btn'),
            characterCardsList: document.getElementById('character-cards-container'),
            // Diálogo com NPCs (Stardew Valley)
            dialogueBox: document.getElementById('dialogue-box'),
            dialogueAvatar: document.getElementById('dialogue-avatar'),
            dialogueSpeakerName: document.getElementById('dialogue-speaker-name'),
            dialogueSpeakerTitle: document.getElementById('dialogue-speaker-title'),
            dialogueText: document.getElementById('dialogue-text'),
            dialogueSwitchBtn: document.getElementById('btn-dialogue-switch-char'),
            dialogueSwitchTargetName: document.getElementById('dialogue-switch-target-name'),
            dialogueNextBtn: document.getElementById('btn-dialogue-next')
        };

        this.renderCharacterSelectionCards();
    }

    renderCharacterSelectionCards() {
        if (!this.dom.characterCardsList) return;
        this.dom.characterCardsList.innerHTML = '';

        ['luis', 'sofia', 'rebeca'].forEach(charId => {
            const char = CHARACTERS[charId];
            if (!char) return;
            const isSelected = (this.state.player.characterId || 'luis') === char.id;
            const card = document.createElement('div');
            card.className = `character-select-card ${isSelected ? 'selected' : ''}`;
            card.dataset.charId = char.id;

            card.innerHTML = `
                <div class="char-avatar-box">
                    <img src="${char.avatar}" alt="${char.name}" class="char-avatar-img">
                </div>
                <div class="char-card-info">
                    <h3>${char.name}</h3>
                    <span class="char-card-title">${char.title}</span>
                    <p class="char-card-desc">${char.desc}</p>
                </div>
                <button class="btn-pill-primary char-pick-btn" style="width: 100%; justify-content: center;" ${isSelected ? 'disabled' : ''}>
                    ${isSelected ? '✓ Personagem Ativo' : 'Jogar como ' + char.name}
                </button>
            `;

            card.querySelector('.char-pick-btn').addEventListener('click', () => {
                this.selectCharacter(char.id);
            });

            this.dom.characterCardsList.appendChild(card);
        });
    }

    bindEvents() {
        // Teclado
        window.addEventListener('keydown', (e) => {
            if (['input', 'textarea'].includes(e.target.tagName.toLowerCase())) return;

            // Diálogo com NPC aberto: avançar com Espaço, E ou Enter
            if (this.isDialogueOpen) {
                if (e.key.toLowerCase() === 'e' || e.key === ' ' || e.key.toLowerCase() === 'enter' || e.key === 'Escape') {
                    e.preventDefault();
                    this.advanceOrCloseDialogue();
                    return;
                }
            }

            this.keys[e.key.toLowerCase()] = true;
            this.keys[e.key] = true;

            // Atalhos numéricos da Hotbar Estilo Stardew Valley (1 a 0, -, =)
            const hotkeyMap = {
                '1': 0, '2': 1, '3': 2, '4': 3, '5': 4,
                '6': 5, '7': 6, '8': 7, '9': 8, '0': 9,
                '-': 10, '=': 11
            };
            if (hotkeyMap.hasOwnProperty(e.key)) {
                this.selectHotbarSlotByIndex(hotkeyMap[e.key]);
                window.soundManager.playClick();
            }

            // Interação
            if ((e.key.toLowerCase() === 'e' || e.key === ' ') && !this.decorMode) {
                e.preventDefault();
                if (this.state.currentScene === 'farm' && this.currentInteractiveTarget && this.currentInteractiveTarget.type === 'plot') {
                    if (!this.soilSelection.active) {
                        const targetPlot = this.currentInteractiveTarget.plot;
                        this.startSoilSelection('keyboard', targetPlot.x, targetPlot.y);
                    }
                } else {
                    this.performInteraction();
                }
            }

            // Tecla M para Mercado
            if (e.key.toLowerCase() === 'm') {
                this.openShop();
            }

            // Tecla C para Seleção de Personagem
            if (e.key.toLowerCase() === 'c') {
                this.openModal('modal-character');
            }

            // Alternar Tela Cheia [F ou F11]
            if ((e.key.toLowerCase() === 'f' || e.key === 'F11' || e.key === 'f11') && !e.ctrlKey && !e.altKey && !e.metaKey) {
                if (e.key.toLowerCase() === 'f11') e.preventDefault();
                this.toggleFullscreen();
            }

            // Tecla ESC
            if (e.key === 'Escape') {
                if (this.soilSelection && this.soilSelection.active) {
                    this.cancelSoilSelection();
                    return;
                }
                if (this.isDialogueOpen) {
                    this.closeDialogue();
                    return;
                }
                if (this.decorMode) {
                    this.toggleDecorMode(false);
                }
                this.closeAllModals();
            }
        });

        window.addEventListener('keyup', (e) => {
            this.keys[e.key.toLowerCase()] = false;
            this.keys[e.key] = false;

            // Executa a tarefa do solo ao soltar a tecla (somente após soltar o botão)
            if ((e.key.toLowerCase() === 'e' || e.key === ' ') && this.soilSelection && this.soilSelection.active && this.soilSelection.source === 'keyboard') {
                e.preventDefault();
                this.executeSoilSelection();
            }
        });

        // Eventos da Caixa de Diálogo Stardew Valley
        if (this.dom.dialogueNextBtn) {
            this.dom.dialogueNextBtn.addEventListener('click', () => {
                this.advanceOrCloseDialogue();
            });
        }
        if (this.dom.dialogueSwitchBtn) {
            this.dom.dialogueSwitchBtn.addEventListener('click', () => {
                if (this.currentDialogueNpc) {
                    const targetId = this.currentDialogueNpc.characterId || this.currentDialogueNpc.id;
                    this.selectCharacter(targetId);
                    this.closeDialogue();
                }
            });
        }

        // Roda do Mouse para alternar slots da Hotbar (estilo Stardew Valley)
        window.addEventListener('wheel', (e) => {
            if (document.querySelector('.modal-overlay.active')) return;
            if (this.isDialogueOpen || this.decorMode) return;
            if (e.deltaY > 0) {
                this.cycleHotbar(1);
            } else if (e.deltaY < 0) {
                this.cycleHotbar(-1);
            }
        }, { passive: true });

        // Botão Modo Decoração
        this.dom.btnToggleDecor.addEventListener('click', () => {
            this.toggleDecorMode(!this.decorMode);
            window.soundManager.playClick();
        });

        // Botão Trocar Personagem
        if (this.dom.btnCharacterBadge) {
            this.dom.btnCharacterBadge.addEventListener('click', () => {
                this.openModal('modal-character');
                window.soundManager.playClick();
            });
        }

        // Drag & Drop no Canvas
        this.bindCanvasMouseEvents();

        // Botão Loja
        this.dom.btnShop.addEventListener('click', () => {
            this.openShop();
            window.soundManager.playClick();
        });

        // Botão Tutorial
        this.dom.btnTutorial.addEventListener('click', () => {
            this.openModal('modal-tutorial');
            window.soundManager.playClick();
        });

        // Botão de Som (com auto-unmute e atualização de estado)
        this.dom.btnSoundToggle.addEventListener('click', () => {
            const isMuted = window.soundManager.toggleMute();
            this.dom.btnSoundToggle.textContent = isMuted ? '🔇' : '🔊';
            this.dom.btnSoundToggle.title = isMuted ? 'Ativar Música & Som (🔊)' : 'Desativar Som (🔇)';
        });
        const isMutedInitial = window.soundManager.isMuted();
        this.dom.btnSoundToggle.textContent = isMutedInitial ? '🔇' : '🔊';
        this.dom.btnSoundToggle.title = isMutedInitial ? 'Ativar Música & Som (🔊)' : 'Desativar Som (🔇)';

        // Botão de Tela Cheia (Responsivo)
        if (this.dom.btnFullscreenToggle) {
            this.dom.btnFullscreenToggle.addEventListener('click', () => {
                this.toggleFullscreen();
                window.soundManager.playClick();
            });
        }
        document.addEventListener('fullscreenchange', () => this.handleFullscreenChange());
        document.addEventListener('webkitfullscreenchange', () => this.handleFullscreenChange());

        // Redimensionamento responsivo do Canvas (ocupa 100% da tela preservando proporção)
        window.addEventListener('resize', () => this.adjustCanvasSize());
        if (window.ResizeObserver && this.canvas.parentElement) {
            const ro = new ResizeObserver(() => this.adjustCanvasSize());
            ro.observe(this.canvas.parentElement);
        }
        this.adjustCanvasSize();

        // Fechamento de Modais
        document.querySelectorAll('.close-btn, .modal-close-trigger').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal-overlay');
                if (modal) modal.classList.remove('active');
                window.soundManager.playClick();
            });
        });

        // Abas da Loja
        this.currentShopTab = 'seeds';
        this.dom.shopCategoryTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                this.dom.shopCategoryTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                this.currentShopTab = tab.dataset.tab;
                this.renderShopItems();
                window.soundManager.playClick();
            });
        });
    }

    // ==========================================================
    // AJUSTE RESPONSIVO DO CANVAS (TELA INTEIRA DO NAVEGADOR)
    // ==========================================================
    adjustCanvasSize() {
        if (!this.canvas || !this.canvas.parentElement) return;
        const container = this.canvas.parentElement;
        const cw = container.clientWidth;
        const ch = container.clientHeight;
        if (cw <= 0 || ch <= 0) return;

        const ts = MAP_CONFIG.tileSize; // 32px

        // Escala vertical base de 16 blocos (512px) que garante nitidez e tamanho ideal dos personagens.
        // O número de colunas (largura do mapa) se expande dinamicamente para preencher 100% da tela do navegador,
        // eliminando completamente o espaço preto e disponibilizando mais área de jogo.
        const baseRows = 16;
        const containerAspect = cw / ch;

        let rows = baseRows;
        let cols = Math.max(24, Math.round(baseRows * containerAspect));

        if (containerAspect < 1.3) {
            // Em telas verticais (modo retrato), expande verticalmente
            cols = 24;
            rows = Math.max(16, Math.round(24 / containerAspect));
        }

        // Atualiza a grade da fazenda
        MAP_CONFIG.farm.cols = cols;
        MAP_CONFIG.farm.rows = rows;

        // Centraliza perfeitamente o interior da casa quando estiver dentro dela
        MAP_CONFIG.house.offsetX = Math.max(0, Math.floor((cols - MAP_CONFIG.house.cols) / 2));
        MAP_CONFIG.house.offsetY = Math.max(0, Math.floor((rows - MAP_CONFIG.house.rows) / 2));

        const targetW = cols * ts;
        const targetH = rows * ts;

        if (this.canvas.width !== targetW || this.canvas.height !== targetH) {
            this.canvas.width = targetW;
            this.canvas.height = targetH;
        }

        this.canvas.style.width = '100%';
        this.canvas.style.height = '100%';

        // Limita o jogador dentro do cercado caso a janela seja redimensionada
        if (false && this.state && this.state.player && this.state.currentScene === 'barn') {
            const maxW = (cols - 2) * ts;
            const maxH = (rows - 2) * ts;
            if (this.state.player.x > maxW) this.state.player.x = maxW;
            if (this.state.player.y > maxH) this.state.player.y = maxH;
        }
    }

    toggleFullscreen() {
        if (!document.fullscreenElement && !document.webkitFullscreenElement) {
            const root = document.documentElement;
            if (root.requestFullscreen) {
                root.requestFullscreen().catch(() => {});
            } else if (root.webkitRequestFullscreen) {
                root.webkitRequestFullscreen();
            }
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen().catch(() => {});
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
        }
    }

    handleFullscreenChange() {
        const isFull = !!(document.fullscreenElement || document.webkitFullscreenElement);
        if (this.dom.btnFullscreenToggle) {
            this.dom.btnFullscreenToggle.textContent = isFull ? '🗗' : '⛶';
            this.dom.btnFullscreenToggle.title = isFull ? 'Sair da Tela Cheia [F]' : 'Tela Cheia [F]';
        }
        if (isFull) {
            document.body.classList.add('is-fullscreen');
        } else {
            document.body.classList.remove('is-fullscreen');
        }
        setTimeout(() => this.adjustCanvasSize(), 50);
    }

    // ==========================================================
    // INTERAÇÕES COM MOUSE / DRAG AND DROP & SELEÇÃO DE SOLO
    // ==========================================================
    bindCanvasMouseEvents() {
        const getCanvasCoords = (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const scaleX = this.canvas.width / rect.width;
            const scaleY = this.canvas.height / rect.height;
            const inWorld = ['farm', 'city', 'barn', 'barnin'].includes(this.state.currentScene) && this.renderer && this.renderer.cam;
            return {
                x: (e.clientX - rect.left) * scaleX + (inWorld ? Math.round(this.renderer.cam.x) : 0),
                y: (e.clientY - rect.top) * scaleY + (inWorld ? Math.round(this.renderer.cam.y) : 0)
            };
        };

        const getHouseTile = (cx, cy) => {
            const ts = MAP_CONFIG.tileSize;
            const ox = MAP_CONFIG.house.offsetX * ts;
            const oy = MAP_CONFIG.house.offsetY * ts;
            return {
                tileX: Math.floor((cx - ox) / ts),
                tileY: Math.floor((cy - oy) / ts)
            };
        };

        const getFarmTile = (cx, cy) => {
            const ts = MAP_CONFIG.tileSize;
            return {
                tileX: Math.floor(cx / ts),
                tileY: Math.floor(cy / ts)
            };
        };

        this.canvas.addEventListener('mousedown', (e) => {
            // Interior da Casa
            if (this.state.currentScene === 'house') {
                const { x, y } = getCanvasCoords(e);
                const { tileX, tileY } = getHouseTile(x, y);

                if (this.decorMode) {
                    if (e.button === 2) {
                        e.preventDefault();
                        this.pickupFurnitureAt(tileX, tileY);
                        return;
                    }

                    if (e.button === 0) {
                        if (this.draggedFurniture) {
                            this.placeDraggedFurniture();
                        } else {
                            const target = this.getPlacedFurnitureAt(tileX, tileY);
                            if (target) {
                                this.draggedFurniture = {
                                    type: target.type,
                                    fromInventory: false,
                                    originalItem: target
                                };
                                this.selectedPlacedFurniture = target;
                                this.state.placedFurniture = this.state.placedFurniture.filter(f => f !== target);
                                window.soundManager.playClick();
                            }
                        }
                    }
                } else {
                    if (e.button === 0) {
                        this.performInteraction();
                    }
                }
                return;
            }

            // Cenário da Fazenda (Interação com Solo e Objetos)
            if (this.state.currentScene === 'farm') {
                if (e.button === 2) {
                    // Botão direito cancela qualquer seleção em andamento
                    e.preventDefault();
                    this.cancelSoilSelection();
                    return;
                }

                if (e.button === 0) {
                    const { x, y } = getCanvasCoords(e);
                    const { tileX, tileY } = getFarmTile(x, y);

                    const plot = this.state.farmPlots.find(p => p.x === tileX && p.y === tileY);
                    if (plot) {
                        // Inicia seleção com marcações visuais - a execução ocorrerá ao soltar o botão
                        this.startSoilSelection('mouse', tileX, tileY);
                    } else if (tileX === MAP_CONFIG.farm.shippingBin.x && tileY === MAP_CONFIG.farm.shippingBin.y) {
                        this.sellAllHarvest();
                    }
                }
            }

            // Cenário do Centro da Cidade
            if (this.state.currentScene === 'city' && e.button === 0) {
                const { x, y } = getCanvasCoords(e);
                const hit = window.CITY_WORLD.interactives.find(it =>
                    x >= it.left && x <= it.right && y >= it.top && y <= it.bottom);
                if (hit) {
                    this.performCityInteraction({ kind: hit.type, msg: hit.msg });
                }
            }
        });

        this.canvas.addEventListener('contextmenu', (e) => {
            if (this.decorMode) {
                e.preventDefault();
            } else if (this.state.currentScene === 'farm' && this.soilSelection && this.soilSelection.active) {
                e.preventDefault();
                this.cancelSoilSelection();
            }
        });

        this.canvas.addEventListener('mousemove', (e) => {
            const { x, y } = getCanvasCoords(e);

            if (this.state.currentScene === 'house') {
                if (!this.decorMode) return;
                const { tileX, tileY } = getHouseTile(x, y);
                if (this.draggedFurniture) {
                    this.dragGhostPos = { x: tileX, y: tileY };
                    this.dragGhostValid = this.isPositionValidForFurniture(this.draggedFurniture.type, tileX, tileY);
                }
                return;
            }

            if (this.state.currentScene === 'farm') {
                const { tileX, tileY } = getFarmTile(x, y);
                this.soilSelection.hoverTile = { tileX, tileY };

                // Seleção em área / arrasto com o mouse: adiciona novos canteiros sob o cursor
                if (this.soilSelection.active && this.soilSelection.source === 'mouse') {
                    this.addPlotToSelection(tileX, tileY);
                }
            }
        });

        this.canvas.addEventListener('mouseleave', () => {
            this.soilSelection.hoverTile = null;
        });

        // Soltar o botão do mouse executa a ação planejada nas marcações válidas
        window.addEventListener('mouseup', (e) => {
            if (e.button === 0 && this.soilSelection && this.soilSelection.active && this.soilSelection.source === 'mouse') {
                this.executeSoilSelection();
            }
        });
    }

    // ==========================================================
    // SISTEMA DE DECORAÇÃO DA CASA (MÓVEIS DRAG & DROP)
    // ==========================================================
    toggleDecorMode(active) {
        if (this.state.currentScene !== 'house') {
            this.showToast('Você só pode decorar dentro de sua Casa!', 'error');
            return;
        }

        this.decorMode = active;
        this.dom.btnToggleDecor.classList.toggle('active', active);
        this.dom.decorDrawer.style.display = active ? 'flex' : 'none';

        if (active) {
            this.renderFurnitureStockList();
            this.showToast('Modo Decoração Ativado! Arraste móveis ou clique para mover.', 'plant');
        } else {
            if (this.draggedFurniture) {
                if (this.draggedFurniture.fromInventory) {
                    this.state.inventory.furniture.push(this.draggedFurniture.type);
                } else if (this.draggedFurniture.originalItem) {
                    this.state.placedFurniture.push(this.draggedFurniture.originalItem);
                }
                this.draggedFurniture = null;
            }
            this.selectedPlacedFurniture = null;
            this.saveState();
        }
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    renderFurnitureStockList() {
        this.dom.furnitureStockContainer.innerHTML = '';
        const items = this.state.inventory.furniture;

        if (!items || items.length === 0) {
            this.dom.furnitureStockContainer.innerHTML = `
                <div style="font-size: 0.8rem; color: var(--text-muted); padding: 8px;">
                    Sem móveis no inventário. Compre novos no Mercado!
                </div>
            `;
            return;
        }

        const counts = {};
        items.forEach(type => {
            counts[type] = (counts[type] || 0) + 1;
        });

        Object.keys(counts).forEach(type => {
            const def = FURNITURE_CATALOG[type];
            const chip = document.createElement('div');
            chip.className = 'furniture-chip';
            chip.innerHTML = `
                ${def.sprite ? `<img class="chip-thumb" src="${def.sprite}" alt="">` : ''}
                <span>${def.name}</span>
                <span class="chip-count">${counts[type]}x</span>
            `;

            chip.addEventListener('click', () => {
                this.startPlacingFromInventory(type);
                window.soundManager.playClick();
            });

            this.dom.furnitureStockContainer.appendChild(chip);
        });
    }

    startPlacingFromInventory(type) {
        const idx = this.state.inventory.furniture.indexOf(type);
        if (idx !== -1) {
            this.state.inventory.furniture.splice(idx, 1);
        }

        this.draggedFurniture = {
            type: type,
            fromInventory: true
        };
        this.dragGhostPos = { x: 5, y: 5 };
        this.dragGhostValid = this.isPositionValidForFurniture(type, 5, 5);
        this.renderFurnitureStockList();
    }

    placeDraggedFurniture() {
        if (!this.dragGhostValid) {
            window.soundManager.playError();
            this.showToast('Local obstruído ou fora dos limites do quarto!', 'error');
            return;
        }

        const newId = this.state.nextFurnitureId++;
        const newItem = {
            id: newId,
            type: this.draggedFurniture.type,
            x: this.dragGhostPos.x,
            y: this.dragGhostPos.y
        };

        this.state.placedFurniture.push(newItem);
        window.soundManager.playFurniturePlace();
        this.showToast('Móvel posicionado com sucesso!', 'plant');

        this.draggedFurniture = null;
        this.selectedPlacedFurniture = null;
        this.renderFurnitureStockList();
        this.saveState();
    }

    pickupFurnitureAt(tileX, tileY) {
        const item = this.getPlacedFurnitureAt(tileX, tileY);
        if (!item) return;

        if (item.type === 'bed_royal' && this.state.placedFurniture.filter(f => f.type === 'bed_royal').length <= 1) {
            this.showToast('Mantenha pelo menos uma cama na casa para dormir!', 'error');
            window.soundManager.playError();
            return;
        }

        this.state.placedFurniture = this.state.placedFurniture.filter(f => f !== item);
        this.state.inventory.furniture.push(item.type);

        window.soundManager.playFurniturePickup();
        this.showToast(`${FURNITURE_CATALOG[item.type].name} recolhido ao inventário!`, 'gold');

        this.renderFurnitureStockList();
        this.saveState();
    }

    getPlacedFurnitureAt(tileX, tileY) {
        return this.state.placedFurniture.find(item => {
            const def = FURNITURE_CATALOG[item.type];
            return tileX >= item.x && tileX < item.x + def.width &&
                   tileY >= item.y && tileY < item.y + def.height;
        });
    }

    isPositionValidForFurniture(type, x, y) {
        const def = FURNITURE_CATALOG[type];
        const bounds = MAP_CONFIG.house.roomBounds;

        if (x < bounds.startX || x + def.width - 1 > bounds.endX ||
            y < getFurnitureMinY(type) || y + def.height - 1 > bounds.endY) {
            return false;
        }

        const exit = MAP_CONFIG.house.exitDoor;
        for (let fx = x; fx < x + def.width; fx++) {
            for (let fy = y; fy < y + def.height; fy++) {
                if (fx === exit.x && fy >= exit.y - 1) return false;
            }
        }

        for (let other of this.state.placedFurniture) {
            const otherDef = FURNITURE_CATALOG[other.type];
            if (def.solid && otherDef.solid) {
                const overlap = !(x + def.width <= other.x ||
                                  x >= other.x + otherDef.width ||
                                  y + def.height <= other.y ||
                                  y >= other.y + otherDef.height);
                if (overlap) return false;
            }
        }

        return true;
    }

    // ==========================================================
    // MOVIMENTAÇÃO DO PERSONAGEM E COLISÕES
    // ==========================================================
    updatePlayerMovement() {
        if (this.decorMode || this.isDialogueOpen) {
            this.state.player.isMoving = false;
            return;
        }

        const p = this.state.player;
        let dx = 0;
        let dy = 0;

        if (this.keys['arrowup'] || this.keys['w']) {
            dy -= p.speed;
            p.dir = 'up';
        }
        if (this.keys['arrowdown'] || this.keys['s']) {
            dy += p.speed;
            p.dir = 'down';
        }
        if (this.keys['arrowleft'] || this.keys['a']) {
            dx -= p.speed;
            p.dir = 'left';
        }
        if (this.keys['arrowright'] || this.keys['d']) {
            dx += p.speed;
            p.dir = 'right';
        }

        p.isMoving = (dx !== 0 || dy !== 0);

        if (p.isMoving) {
            window.soundManager.playStep(this.state.currentScene === 'house' || this.state.currentScene === 'house2');

            if (dx !== 0) {
                const targetX = p.x + dx;
                if (!this.checkCollision(targetX, p.y)) {
                    p.x = targetX;
                }
            }
            if (dy !== 0) {
                const targetY = p.y + dy;
                if (!this.checkCollision(p.x, targetY)) {
                    p.y = targetY;
                }
            }
        }

        this.checkDoorTriggers();
        this.updateInteractiveTarget();
    }

    checkCollision(x, y) {
        // Caixa de colisão focada nos pés, ligeiramente mais larga para
        // cobrir a largura real do personagem ao encostar em cercas e postes.
        const footBox = {
            left: x + 6,
            right: x + 26,
            top: y + 19,
            bottom: y + 31
        };

        // Colisão com NPCs companheiros presentes na cena
        const activeNpcs = this.getActiveNPCs();
        for (const npc of activeNpcs) {
            if (npc.scene === this.state.currentScene) {
                const npcBox = {
                    left: npc.x + 6,
                    right: npc.x + 26,
                    top: npc.y + 16,
                    bottom: npc.y + 32
                };
                if (this.boxOverlap(footBox, npcBox)) return true;
            }
        }

        if (this.state.currentScene === 'farm') {
            return this.checkFarmCollision(footBox);
        } else if (this.state.currentScene === 'house') {
            return this.checkHouseCollision(footBox);
        } else if (this.state.currentScene === 'barn') {
            return this.checkBarnCollision(footBox);
        } else if (this.state.currentScene === 'barnin') {
            return window.barnInsideBlocked(footBox);
        } else if (this.state.currentScene === 'house2') {
            return this.checkHouseCollision(footBox, FRIEND_HOUSE_FURNITURE);
        } else if (this.state.currentScene === 'city') {
            return this.checkCityCollision(footBox);
        }
        return false;
    }

    checkCityCollision(box) {
        const T = window.CITY_WORLD;
        if (box.left < 0 || box.right > T.w - 8 || box.top < 8 || box.bottom > T.h - 8) {
            return true;
        }
        return window.cityWorldBlocked(box);
    }

    checkBarnCollision(box) {
        const T = window.BARN_WORLD;
        if (box.left < 0 || box.right > T.w || box.top < 8 || box.bottom > T.h) return true;
        return window.barnWorldBlocked(box);
    }

    checkFarmCollision(box) {
        const ts = MAP_CONFIG.tileSize;
        const F = MAP_CONFIG.farm;
        const worldW = F.worldW;

        // Saídas do mapa: caminho norte (celeiro) e portão leste (cidade)
        const inBarnPath = box.left >= 690 && box.right <= 750 && box.top >= 0;
        const inTownGate = box.right > worldW - 24 && box.top >= 16.5 * ts && box.bottom <= 20.3 * ts;
        if (box.top < 0 && !inBarnPath) return true;
        if (box.right > worldW - 24 && !inTownGate) return true;
        if (box.left < 24 || box.bottom > F.worldH - 24) return true;

        // Terreno bloqueado (água, penhascos, árvores) segundo o mapa de colisão da imagem
        if (!inTownGate && !inBarnPath && window.farmWorldBlocked(box)) return true;
        if (inBarnPath && box.top > 0 && window.farmWorldBlocked(box)) return true;
        if (inTownGate && box.right <= worldW - 24 && window.farmWorldBlocked(box)) return true;

        // Casa principal
        const hx = F.house.x, hy = F.house.y;
        const houseBox = { left: hx * ts, right: (hx + 5) * ts, top: hy * ts + 20, bottom: (hy + 4) * ts };
        if (this.boxOverlap(box, houseBox)) {
            const doorX = (hx + 2) * ts;
            if (box.left >= doorX + 4 && box.right <= doorX + 28 && box.bottom >= (hy + 4) * ts - 8) {
                return false;
            }
            return true;
        }

        const fh = getFriendHouse();
        const fhBox = { left: fh.x * ts, right: (fh.x + 5) * ts, top: fh.y * ts + 20, bottom: (fh.y + 4) * ts };
        if (this.boxOverlap(box, fhBox)) {
            const fdX = fh.doorX * ts;
            if (box.left >= fdX + 4 && box.right <= fdX + 28 && box.bottom >= (fh.y + 4) * ts - 8) {
                return false;
            }
            return true;
        }

        const bin = F.shippingBin;
        const binBox = { left: bin.x * ts + 2, right: (bin.x + 1) * ts - 2, top: bin.y * ts + 4, bottom: (bin.y + 1) * ts - 4 };
        if (this.boxOverlap(box, binBox)) return true;

        // Placa da Cidade
        const sg = F.townSign;
        const signBox = { left: sg.x * ts + 10, right: sg.x * ts + 24, top: sg.y * ts + 14, bottom: sg.y * ts + 30 };
        if (this.boxOverlap(box, signBox)) return true;

        return false;
    }

    checkHouseCollision(box, furniture) {
        furniture = furniture || this.state.placedFurniture;
        const ts = MAP_CONFIG.tileSize;
        const conf = MAP_CONFIG.house;
        const w = conf.cols * ts;
        const h = conf.rows * ts;

        // Limites do chão (a parede ocupa as linhas 0-2 e a borda inferior começa na linha 10)
        const exitX = conf.exitDoor.x * ts;
        const inDoorColumn = box.left >= exitX - 4 && box.right <= exitX + ts + 4;
        const floorBottom = inDoorColumn ? h : (conf.roomBounds.endY + 1) * ts;
        const floorTop = conf.roomBounds.startY * ts + 4;

        if (box.left < ts + 4 || box.right > w - ts - 4 || box.top < floorTop || box.bottom > floorBottom) {
            return true;
        }

        for (let item of furniture) {
            const def = FURNITURE_CATALOG[item.type];
            if (def.solid) {
                const mBox = {
                    left: item.x * ts,
                    right: (item.x + def.width) * ts,
                    top: item.y * ts + 8,
                    bottom: (item.y + def.height) * ts
                };
                if (this.boxOverlap(box, mBox)) return true;
            }
        }

        return false;
    }

    boxOverlap(b1, b2) {
        return !(b1.right <= b2.left || b1.left >= b2.right || b1.bottom <= b2.top || b1.top >= b2.bottom);
    }

    // ==========================================================
    // TRANSIÇÃO DE CENÁRIOS (FAZENDA <-> CASA)
    // ==========================================================
    checkDoorTriggers() {
        const p = this.state.player;
        const ts = MAP_CONFIG.tileSize;
        const now = performance.now();
        const canSwitch = !this._sceneCooldown || now > this._sceneCooldown;
        const holdingUp = this.keys['arrowup'] || this.keys['w'];
        const holdingDown = this.keys['arrowdown'] || this.keys['s'];

        // Borda de cima da fazenda -> Celeiro | Borda de baixo do celeiro -> Fazenda
        if (canSwitch && this.state.currentScene === 'farm' && holdingUp && p.y <= 10 && p.x >= 680 && p.x <= 750) {
            this.enterBarn();
            return;
        }
        if (canSwitch && this.state.currentScene === 'barn' && holdingDown &&
            p.y >= window.BARN_WORLD.exitY) {
            this.exitBarn();
            return;
        }
        // Porta do celeiro vermelho (no curral) -> Interior | porta do interior -> curral
        if (canSwitch && this.state.currentScene === 'barn' && holdingUp) {
            const D = window.BARN_WORLD.barnDoors.find(d => p.y <= d.maxY && p.x >= d.minX && p.x <= d.maxX);
            if (D) {
                this.enterBarnInside(D.kind);
                return;
            }
        }
        if (canSwitch && this.state.currentScene === 'barnin' && holdingDown &&
            p.y >= window.BARN_INSIDE.exitY) {
            this.exitBarnInside();
            return;
        }

        // Estrada leste da fazenda -> Centro da Cidade | ponte oeste da cidade -> Fazenda
        if (canSwitch && this.state.currentScene === 'farm' &&
            p.x >= MAP_CONFIG.farm.worldW - 2 * ts - 6 && p.y >= 16 * ts && p.y <= 20.5 * ts) {
            this.enterCity();
            return;
        }
        if (canSwitch && this.state.currentScene === 'city') {
            const C = window.CITY_WORLD;
            if (p.x <= C.westGate.x && p.y >= C.westGate.top && p.y <= C.westGate.bottom) {
                this.exitCity();
                return;
            }
        }

        if (this.state.currentScene === 'farm') {
            const fh = getFriendHouse();
            const fdX = fh.doorX * ts, fdY = fh.doorY * ts;
            if (Math.hypot(p.x - fdX, p.y - fdY) < 20 && (p.dir === 'up' || p.y <= fdY + 6)) {
                this.enterFriendsHouse();
                return;
            }
            const doorX = MAP_CONFIG.farm.houseDoor.x * ts;
            const doorY = MAP_CONFIG.farm.houseDoor.y * ts;
            const dist = Math.hypot(p.x - doorX, p.y - doorY);

            if (dist < 20 && (p.dir === 'up' || p.y <= doorY + 6)) {
                this.enterHouse();
            }
        } else if (this.state.currentScene === 'house' || this.state.currentScene === 'house2') {
            const exitX = MAP_CONFIG.house.exitDoor.x * ts;
            const exitY = MAP_CONFIG.house.exitDoor.y * ts;
            const dist = Math.hypot(p.x - exitX, p.y - exitY);

            if (dist < 18) {
                if (this.state.currentScene === 'house2') this.exitFriendsHouse();
                else this.exitHouse();
            }
        }
    }

    enterHouse() {
        this.cancelSoilSelection();
        window.soundManager.playDoor();
        this.state.currentScene = 'house';
        this.state.player.x = MAP_CONFIG.house.spawn.x * MAP_CONFIG.tileSize;
        this.state.player.y = MAP_CONFIG.house.spawn.y * MAP_CONFIG.tileSize;
        this.state.player.dir = 'up';

        this.dom.locationDisplay.textContent = '🏠 Interior da Casa';
        this.dom.btnToggleDecor.style.display = 'inline-flex';
        this.showToast('Entrou na Casa Aconchegante', 'plant');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    // Procura uma posição livre próxima (variando o X) após trocar de cenário
    placePlayerFree(x, y) {
        const ts = MAP_CONFIG.tileSize;
        const maxX = (this.state.currentScene === 'farm' ? MAP_CONFIG.farm.worldW : this.state.currentScene === 'city' ? window.CITY_WORLD.w : this.state.currentScene === 'barn' ? window.BARN_WORLD.w : this.state.currentScene === 'barnin' ? window.BARN_INSIDE.w : MAP_CONFIG.farm.cols * ts) - 3 * ts;
        x = Math.max(2 * ts, Math.min(maxX, x));
        const p = this.state.player;
        for (let i = 0; i <= 24; i++) {
            for (const sign of (i === 0 ? [1] : [1, -1])) {
                const cx = x + sign * i * 16;
                if (cx < 2 * ts || cx > maxX) continue;
                if (!this.checkCollision(cx, y)) {
                    p.x = cx; p.y = y;
                    return;
                }
            }
        }
        p.x = x; p.y = y;
    }

    enterBarn() {
        this.cancelSoilSelection();
        const ts = MAP_CONFIG.tileSize;
        window.soundManager.playDoor();
        this.state.currentScene = 'barn';
        this._sceneCooldown = performance.now() + 500;
        this.state.player.dir = 'up';
        this.state.player.x = window.BARN_WORLD.entry.x;
        this.state.player.y = window.BARN_WORLD.entry.y;
        this.dom.locationDisplay.textContent = '🐄 Celeiro';
        this.dom.btnToggleDecor.style.display = 'none';
        this.showToast('Você chegou ao Celeiro 🐄', 'plant');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    enterBarnInside(kind) {
        kind = kind || 'cow';
        this.state.barnInKind = kind;
        window.BARN_INSIDE.kind = kind;
        const label = { cow: 'Celeiro 🐄', pig: 'Abrigo dos Porquinhos 🐷', hen: 'Galinheiro 🐔' }[kind];
        this.cancelSoilSelection();
        window.soundManager.playDoor();
        this.state.currentScene = 'barnin';
        this._sceneCooldown = performance.now() + 500;
        this.state.player.dir = 'up';
        this.state.player.x = window.BARN_INSIDE.entry.x;
        this.state.player.y = window.BARN_INSIDE.entry.y;
        this.dom.locationDisplay.textContent = '🏚️ ' + label;
        this.dom.btnToggleDecor.style.display = 'none';
        this.showToast('Você entrou no ' + label, 'plant');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    exitBarnInside() {
        window.soundManager.playDoor();
        this.state.currentScene = 'barn';
        this._sceneCooldown = performance.now() + 500;
        this.state.player.dir = 'down';
        const door = window.BARN_WORLD.barnDoors.find(d => d.kind === (this.state.barnInKind || 'cow')) || window.BARN_WORLD.barnDoor;
        this.state.player.x = door.exitX;
        this.state.player.y = door.exitY;
        this.dom.locationDisplay.textContent = '🐄 Celeiro';
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    exitBarn() {
        window.soundManager.playDoor();
        this.state.currentScene = 'farm';
        this._sceneCooldown = performance.now() + 500;
        this.state.player.dir = 'down';
        this.placePlayerFree(716, 110);
        this.dom.locationDisplay.textContent = '🌾 Vale do Crepúsculo (Fazenda)';
        this.showToast('Voltou para a Fazenda', 'plant');
        this.saveState();
    }

    enterCity() {
        this.cancelSoilSelection();
        window.soundManager.playDoor();
        this.state.currentScene = 'city';
        this._sceneCooldown = performance.now() + 600;
        this.state.player.dir = 'right';
        this.state.player.x = window.CITY_WORLD.entry.x;
        this.state.player.y = window.CITY_WORLD.entry.y;
        this.dom.locationDisplay.textContent = '🏙️ Centro da Cidade';
        this.dom.btnToggleDecor.style.display = 'none';
        this.showToast('Bem-vindo ao Centro da Cidade! 🏙️ Mercado, hospital, igreja e muito mais para explorar', 'gold');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    exitCity() {
        const ts = MAP_CONFIG.tileSize;
        window.soundManager.playDoor();
        this.state.currentScene = 'farm';
        this._sceneCooldown = performance.now() + 600;
        this.state.player.dir = 'left';
        this.placePlayerFree(MAP_CONFIG.farm.worldW - 5 * ts, 18 * ts);
        this.dom.locationDisplay.textContent = '🌾 Vale do Crepúsculo (Fazenda)';
        this.dom.btnToggleDecor.style.display = 'none';
        this.showToast('Voltou para a Fazenda 🌾', 'plant');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    enterFriendsHouse() {
        this.cancelSoilSelection();
        window.soundManager.playDoor();
        this.state.currentScene = 'house2';
        this.state.player.x = MAP_CONFIG.house.spawn.x * MAP_CONFIG.tileSize;
        this.state.player.y = MAP_CONFIG.house.spawn.y * MAP_CONFIG.tileSize;
        this.state.player.dir = 'up';
        this.dom.locationDisplay.textContent = '🏡 Casa dos Amigos';
        this.dom.btnToggleDecor.style.display = 'none';
        this.showToast('Você entrou na Casa dos Amigos', 'plant');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    exitFriendsHouse() {
        const fh = getFriendHouse();
        window.soundManager.playDoor();
        this.state.currentScene = 'farm';
        this.state.player.x = fh.doorX * MAP_CONFIG.tileSize;
        this.state.player.y = (fh.doorY + 1.2) * MAP_CONFIG.tileSize;
        this.state.player.dir = 'down';
        this.dom.locationDisplay.textContent = '🌾 Vale do Crepúsculo (Fazenda)';
        this.showToast('Saiu para a Fazenda', 'plant');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    exitHouse() {
        if (this.decorMode) this.toggleDecorMode(false);

        window.soundManager.playDoor();
        this.state.currentScene = 'farm';
        this.state.player.x = MAP_CONFIG.farm.houseDoor.x * MAP_CONFIG.tileSize;
        this.state.player.y = (MAP_CONFIG.farm.houseDoor.y + 1.2) * MAP_CONFIG.tileSize;
        this.state.player.dir = 'down';

        this.dom.locationDisplay.textContent = '🌾 Vale do Crepúsculo (Fazenda)';
        this.dom.btnToggleDecor.style.display = 'none';
        this.showToast('Saiu para a Fazenda', 'plant');
        this.saveState();
        setTimeout(() => this.adjustCanvasSize(), 30);
    }

    // ==========================================================
    // INTERAÇÕES CONTEXTUAIS (PLANTIO, COLHEITA, VENDA, CAMA)
    // ==========================================================
    updateInteractiveTarget() {
        const p = this.state.player;
        const ts = MAP_CONFIG.tileSize;

        let frontX = p.x + 16;
        let frontY = p.y + 24;

        if (p.dir === 'up') frontY -= 24;
        if (p.dir === 'down') frontY += 24;
        if (p.dir === 'left') frontX -= 24;
        if (p.dir === 'right') frontX += 24;

        const tileX = Math.floor(frontX / ts);
        const tileY = Math.floor(frontY / ts);

        this.interactionPrompt = null;
        this.currentInteractiveTarget = null;

        // 1. Interação prioritária com NPCs companheiros (Luis, Sofia, Rebeca)
        const activeNpcs = this.getActiveNPCs();
        for (const npc of activeNpcs) {
            if (npc.scene === this.state.currentScene) {
                const dist = Math.hypot((p.x + 16) - (npc.x + 16), (p.y + 16) - (npc.y + 16));
                if (dist <= 48) {
                    this.interactionPrompt = `[E] Conversar com ${npc.name}`;
                    this.currentInteractiveTarget = { type: 'npc', npc: npc };
                    return;
                }
            }
        }

        if (this.state.currentScene === 'farm') {
            const fhd = getFriendHouse();
            if (tileX === fhd.doorX && tileY <= fhd.doorY + 1) {
                this.interactionPrompt = '[E] Entrar na Casa dos Amigos';
                this.currentInteractiveTarget = { type: 'door2' };
                return;
            }

            if (tileX === MAP_CONFIG.farm.houseDoor.x && tileY <= MAP_CONFIG.farm.houseDoor.y + 1) {
                this.interactionPrompt = '[E] Entrar na Casa';
                this.currentInteractiveTarget = { type: 'door' };
                return;
            }

            if (tileX === MAP_CONFIG.farm.shippingBin.x && tileY === MAP_CONFIG.farm.shippingBin.y) {
                this.interactionPrompt = '[E] Vender Toda a Colheita';
                this.currentInteractiveTarget = { type: 'shipping_bin' };
                return;
            }

            const plot = this.state.farmPlots.find(pt => pt.x === tileX && pt.y === tileY);
            if (plot) {
                this.currentInteractiveTarget = { type: 'plot', plot: plot };

                if (this.soilSelection && this.soilSelection.active) {
                    if (this.soilSelection.source === 'keyboard') {
                        this.addPlotToSelection(tileX, tileY);
                    }
                    this.interactionPrompt = null;
                    return;
                }

                if (plot.crop && plot.crop.ready) {
                    this.interactionPrompt = `[E] Colher ${CROPS_DATA[plot.crop.type].name}!`;
                } else if (plot.state === 'dry') {
                    this.interactionPrompt = (this.activeTool === 'hoe') ? '[E] Arar Terra' : '[1] Selecionar Enxada';
                } else if (plot.state === 'tilled' && !plot.crop) {
                    if (this.activeTool === 'seed') {
                        const cropName = CROPS_DATA[this.activeSeed].name;
                        this.interactionPrompt = `[E] Plantar ${cropName}`;
                    } else if (this.activeTool === 'water' && !plot.isWatered) {
                        this.interactionPrompt = '[E] Regar Solo';
                    } else {
                        this.interactionPrompt = '[E] Preparado para Sementes';
                    }
                } else if (plot.crop && !plot.crop.ready) {
                    if (this.activeTool === 'water' && !plot.isWatered) {
                        this.interactionPrompt = '[E] Regar Planta';
                    } else {
                        const progress = `${plot.crop.daysPlanted}/${plot.crop.daysToGrow} dias`;
                        this.interactionPrompt = `${CROPS_DATA[plot.crop.type].name} (${progress})`;
                    }
                }
            }
        } else if (this.state.currentScene === 'barn') {
            // Acariciar os animais dos cercados (por cima da cerca)
            const nearAnimal = window.barnAnimals && window.barnAnimals.findNear(frontX, frontY);
            if (nearAnimal) {
                this.interactionPrompt = `[E] Acariciar ${nearAnimal.name}`;
                this.currentInteractiveTarget = { type: 'animal', animal: nearAnimal };
            }
        } else if (this.state.currentScene === 'city') {
            const m = 10;
            const hit = window.CITY_WORLD.interactives.find(it =>
                frontX >= it.left - m && frontX <= it.right + m && frontY >= it.top - m && frontY <= it.bottom + m);
            if (hit) {
                this.interactionPrompt = hit.prompt;
                this.currentInteractiveTarget = { type: 'town', kind: hit.type, msg: hit.msg };
            }
        } else if (this.state.currentScene === 'house2') {
            if (tileX === MAP_CONFIG.house.exitDoor.x && tileY >= MAP_CONFIG.house.exitDoor.y - 1) {
                this.interactionPrompt = '[E] Sair para a Fazenda';
                this.currentInteractiveTarget = { type: 'exit2' };
                return;
            }
        } else if (this.state.currentScene === 'house') {
            const item = this.getPlacedFurnitureAt(tileX, tileY);
            if (item && FURNITURE_CATALOG[item.type].isBed) {
                this.interactionPrompt = '[E] Dormir / Passar a Noite';
                this.currentInteractiveTarget = { type: 'bed' };
                return;
            }

            if (tileX === MAP_CONFIG.house.exitDoor.x && tileY >= MAP_CONFIG.house.exitDoor.y - 1) {
                this.interactionPrompt = '[E] Sair para a Fazenda';
                this.currentInteractiveTarget = { type: 'exit' };
                return;
            }
        }
    }

    performInteraction() {
        if (!this.currentInteractiveTarget) return;

        const target = this.currentInteractiveTarget;

        if (target.type === 'prop') {
            this.showToast(target.msg, 'plant');
            return;
        }

        if (target.type === 'town') {
            this.performCityInteraction(target);
            return;
        }

        if (target.type === 'animal') {
            const a = target.animal;
            window.barnAnimals.pet(a);
            const sounds = { cow: '🐄 Muuuu!', pig: '🐖 Oinc oinc!', hen: '🐔 Có có có!' };
            this.showToast(`${sounds[a.sp] || ''} ${a.name} adorou o carinho! ❤️`, 'plant');
            return;
        }

        if (target.type === 'npc') {
            const npc = target.npc;
            // Virar NPC de frente para o jogador
            const dx = this.state.player.x - npc.x;
            const dy = this.state.player.y - npc.y;
            if (Math.abs(dx) > Math.abs(dy)) {
                npc.dir = dx > 0 ? 'right' : 'left';
            } else {
                npc.dir = dy > 0 ? 'down' : 'up';
            }
            if (!this.npcState) this.npcState = {};
            if (!this.npcState[npc.id]) this.npcState[npc.id] = {};
            this.npcState[npc.id].dir = npc.dir;

            this.openDialogue(npc);
            return;
        } else if (target.type === 'door2') {
            this.enterFriendsHouse();
        } else if (target.type === 'exit2') {
            this.exitFriendsHouse();
        } else if (target.type === 'door') {
            this.enterHouse();
        } else if (target.type === 'exit') {
            this.exitHouse();
        } else if (target.type === 'shipping_bin') {
            this.sellAllHarvest();
        } else if (target.type === 'bed') {
            this.advanceDay();
        } else if (target.type === 'plot') {
            this.handlePlotAction(target.plot);
        }
    }

    performCityInteraction(target) {
        const p = this.state.player;
        switch (target.kind) {
            case 'to_farm':
                this.exitCity();
                break;
            case 'city_market':
                this.openShop('seeds');
                this.showToast(target.msg, 'gold');
                break;
            case 'city_hospital':
                p.stamina = p.maxStamina;
                this.updateUI();
                window.soundManager.playPlant();
                this.showToast(target.msg + ' Energia totalmente recuperada! ✨', 'plant');
                break;
            case 'city_fountain':
                window.soundManager.playCoin();
                this.showToast(target.msg, 'gold');
                break;
            default:
                this.showToast(target.msg, 'plant');
        }
    }

    handlePlotAction(plot) {
        if (plot.crop && plot.crop.ready) {
            const cropType = plot.crop.type;
            const def = CROPS_DATA[cropType];

            this.state.inventory.crops[cropType] = (this.state.inventory.crops[cropType] || 0) + 1;
            plot.crop = null;

            window.soundManager.playHarvest();
            this.showToast(`+1 ${def.icon} ${def.name} colhida!`, 'gold');
            this.saveState();
            this.updateUI();
            return;
        }

        switch (this.activeTool) {
            case 'hoe':
                if (plot.state === 'dry') {
                    plot.state = 'tilled';
                    window.soundManager.playTill();
                    this.showToast('⛏️ Terra Arada!', 'till');
                } else {
                    this.showToast('O solo já está preparado!', 'till');
                }
                break;

            case 'water':
                if (plot.state === 'dry') {
                    this.showToast('Are a terra antes de regar!', 'error');
                    window.soundManager.playError();
                } else if (plot.isWatered) {
                    this.showToast('A terra já está úmida!', 'water');
                } else {
                    plot.isWatered = true;
                    window.soundManager.playWater();
                    this.showToast('💧 Solo Regado com sucesso!', 'water');
                }
                break;

            case 'seed':
                if (plot.state === 'dry') {
                    this.showToast('Are a terra antes de plantar!', 'error');
                    window.soundManager.playError();
                } else if (plot.crop) {
                    this.showToast('Já há uma plantação aqui!', 'error');
                    window.soundManager.playError();
                } else {
                    const seedType = this.activeSeed;
                    const stock = this.state.inventory.seeds[seedType] || 0;

                    if (stock <= 0) {
                        this.showToast(`Sem sementes de ${CROPS_DATA[seedType].name}! Compre no Mercado.`, 'error');
                        window.soundManager.playError();
                    } else {
                        this.state.inventory.seeds[seedType]--;
                        plot.crop = {
                            type: seedType,
                            daysPlanted: 0,
                            daysToGrow: CROPS_DATA[seedType].daysToGrow,
                            ready: false
                        };
                        window.soundManager.playPlant();
                        this.showToast(`🌱 ${CROPS_DATA[seedType].name} plantada!`, 'plant');
                    }
                }
                break;

            case 'harvest':
                if (plot.crop && !plot.crop.ready) {
                    this.showToast('Ainda está amadurecendo!', 'error');
                    window.soundManager.playError();
                }
                break;
        }

        this.saveState();
        this.updateUI();
    }

    // ==========================================================
    // SISTEMA DE SELEÇÃO E MARCAÇÕES DE SOLO (STARDEW VALLEY)
    // ==========================================================
    getPlotAction(plot, tool = this.activeTool, seed = this.activeSeed) {
        if (!plot) return { action: 'invalid', valid: false };

        // Colheita prioritária caso a planta já esteja madura
        if (plot.crop && plot.crop.ready) {
            return {
                action: 'harvest',
                valid: true,
                cropType: plot.crop.type,
                name: (CROPS_DATA[plot.crop.type] && CROPS_DATA[plot.crop.type].name) || 'Safra'
            };
        }

        if (tool === 'hoe') {
            if (plot.state === 'dry') {
                return { action: 'till', valid: true };
            }
            return { action: 'till', valid: false, reason: 'Solo já preparado' };
        }

        if (tool === 'water') {
            if (plot.state === 'dry') {
                return { action: 'water', valid: false, reason: 'Are a terra antes de regar' };
            }
            if (plot.isWatered) {
                return { action: 'water', valid: false, reason: 'Solo já está regado' };
            }
            return { action: 'water', valid: true };
        }

        if (tool === 'seed') {
            const seedType = seed || this.activeSeed;
            const stock = (this.state.inventory && this.state.inventory.seeds && this.state.inventory.seeds[seedType]) || 0;
            if (plot.state === 'dry') {
                return { action: 'plant', valid: false, seedType, reason: 'Are a terra antes de plantar' };
            }
            if (plot.crop) {
                return { action: 'plant', valid: false, seedType, reason: 'Já há uma plantação aqui' };
            }
            if (stock <= 0) {
                const seedName = (CROPS_DATA[seedType] && CROPS_DATA[seedType].name) || 'Semente';
                return { action: 'plant', valid: false, seedType, reason: `Sem sementes de ${seedName}` };
            }
            return { action: 'plant', valid: true, seedType };
        }

        if (tool === 'harvest') {
            if (plot.crop && plot.crop.ready) {
                return { action: 'harvest', valid: true, cropType: plot.crop.type };
            }
            return { action: 'harvest', valid: false, reason: 'Nenhuma colheita madura' };
        }

        // Padrão de conveniência baseado no estado do canteiro
        if (plot.state === 'dry') {
            return { action: 'till', valid: this.activeTool === 'hoe' };
        }
        if (!plot.crop) {
            return { action: 'plant', valid: this.activeTool === 'seed', seedType: this.activeSeed };
        }
        return { action: 'water', valid: this.activeTool === 'water' && !plot.isWatered };
    }

    startSoilSelection(source, tileX, tileY) {
        if (this.state.currentScene !== 'farm') return;
        const plot = this.state.farmPlots.find(p => p.x === tileX && p.y === tileY);
        if (!plot) return;

        this.soilSelection.active = true;
        this.soilSelection.source = source;
        this.soilSelection.selectedPlots = [];
        this.soilSelection.tool = this.activeTool;
        this.soilSelection.seed = this.activeSeed;

        this.addPlotToSelection(tileX, tileY);
    }

    addPlotToSelection(tileX, tileY) {
        if (!this.soilSelection.active) return;
        const plot = this.state.farmPlots.find(p => p.x === tileX && p.y === tileY);
        if (!plot) return;

        // Evita duplicatas na lista de seleção
        if (this.soilSelection.selectedPlots.some(item => item.plot === plot)) return;

        const info = this.getPlotAction(plot, this.soilSelection.tool, this.soilSelection.seed);
        this.soilSelection.selectedPlots.push({
            plot: plot,
            action: info.action,
            valid: info.valid,
            seedType: info.seedType,
            reason: info.reason
        });
    }

    executeSoilSelection() {
        if (!this.soilSelection.active) return;

        const plotsToExecute = [...this.soilSelection.selectedPlots];
        const reachRadius = this.soilSelection.reachRadius || 96;
        const px = this.state.player.x + 16;
        const py = this.state.player.y + 16;

        this.soilSelection.active = false;
        this.soilSelection.selectedPlots = [];

        if (plotsToExecute.length === 0) return;

        // 1. Filtrar canteiros que estão dentro do alcance (reachRadius) do jogador
        const inRangePlots = plotsToExecute.filter(item => {
            const tx = item.plot.x * MAP_CONFIG.tileSize + 16;
            const ty = item.plot.y * MAP_CONFIG.tileSize + 16;
            return Math.hypot(tx - px, ty - py) <= reachRadius;
        });

        if (inRangePlots.length === 0) {
            window.soundManager.playError();
            this.showToast('Muito longe! Aproxime-se dos canteiros marcados.', 'error');
            return;
        }

        // 2. Filtrar canteiros válidos para a ferramenta ou semente ativa
        const validPlots = inRangePlots.filter(item => item.valid);

        if (validPlots.length === 0) {
            window.soundManager.playError();
            const firstReason = inRangePlots[0]?.reason;
            this.showToast(firstReason || 'Nenhuma ação válida nos canteiros selecionados.', 'error');
            return;
        }

        // 3. Virar o personagem em direção ao centro das marcações
        let sumX = 0, sumY = 0;
        validPlots.forEach(item => {
            sumX += item.plot.x * MAP_CONFIG.tileSize + 16;
            sumY += item.plot.y * MAP_CONFIG.tileSize + 16;
        });
        const avgX = sumX / validPlots.length;
        const avgY = sumY / validPlots.length;
        const dx = avgX - px;
        const dy = avgY - py;
        if (Math.abs(dx) > Math.abs(dy)) {
            this.state.player.dir = dx > 0 ? 'right' : 'left';
        } else {
            this.state.player.dir = dy > 0 ? 'down' : 'up';
        }

        // 4. Executar tarefas em lote (somente após soltar o botão)
        const executedCounts = { till: 0, water: 0, plant: 0, harvest: 0 };
        let lastPlantSeed = null;

        for (const item of validPlots) {
            const plot = item.plot;

            if (item.action === 'harvest') {
                if (plot.crop && plot.crop.ready) {
                    const cType = plot.crop.type;
                    this.state.inventory.crops[cType] = (this.state.inventory.crops[cType] || 0) + 1;
                    plot.crop = null;
                    executedCounts.harvest++;
                }
            } else if (item.action === 'till') {
                if (plot.state === 'dry') {
                    plot.state = 'tilled';
                    executedCounts.till++;
                }
            } else if (item.action === 'water') {
                if (plot.state === 'tilled' && !plot.isWatered) {
                    plot.isWatered = true;
                    executedCounts.water++;
                }
            } else if (item.action === 'plant') {
                const sType = item.seedType || this.activeSeed;
                const stock = this.state.inventory.seeds[sType] || 0;
                if (stock > 0 && plot.state === 'tilled' && !plot.crop) {
                    this.state.inventory.seeds[sType]--;
                    plot.crop = {
                        type: sType,
                        daysPlanted: 0,
                        daysToGrow: CROPS_DATA[sType].daysToGrow,
                        ready: false
                    };
                    executedCounts.plant++;
                    lastPlantSeed = sType;
                }
            }
        }

        // 5. Sons de feedback e aviso flutuante
        if (executedCounts.harvest > 0) {
            window.soundManager.playHarvest();
            this.showToast(`+${executedCounts.harvest} Colheita realizada! 🧺`, 'gold');
        } else if (executedCounts.plant > 0) {
            window.soundManager.playPlant();
            const cropName = (CROPS_DATA[lastPlantSeed] && CROPS_DATA[lastPlantSeed].name) || 'Semente';
            this.showToast(`🌱 ${cropName} plantada (${executedCounts.plant})!`, 'plant');
        } else if (executedCounts.water > 0) {
            window.soundManager.playWater();
            this.showToast(`💧 Solo Regado (${executedCounts.water})!`, 'water');
        } else if (executedCounts.till > 0) {
            window.soundManager.playTill();
            this.showToast(`⛏️ Terra Arada (${executedCounts.till})!`, 'till');
        }

        this.saveState();
        this.updateUI();
    }

    cancelSoilSelection() {
        if (this.soilSelection) {
            this.soilSelection.active = false;
            this.soilSelection.selectedPlots = [];
        }
    }

    sellAllHarvest() {
        let earned = 0;
        let count = 0;

        Object.keys(this.state.inventory.crops).forEach(key => {
            const amount = this.state.inventory.crops[key];
            if (amount > 0) {
                earned += amount * CROPS_DATA[key].sellPrice;
                count += amount;
                this.state.inventory.crops[key] = 0;
            }
        });

        if (count === 0) {
            this.showToast('Nenhum vegetal no celeiro para vender!', 'error');
            window.soundManager.playError();
            return;
        }

        this.state.gold += earned;
        window.soundManager.playCoin();
        this.showToast(`💰 Colheita vendida! +${earned}🪙 Ouro`, 'gold');
        this.saveState();
        this.updateUI();
    }

    // ==========================================================
    // RELÓGIO DO DIA (estilo Stardew Valley)
    // 06:00 -> 24:00 em ~12 min reais (10 min de jogo a cada 7 s). Meia-noite avisa para dormir; 02:00 desmaia.
    // ==========================================================
    get DAY_START() { return 360; }

    formatClock(t) {
        const m = Math.floor(t) % 1440;
        const hh = String(Math.floor(m / 60)).padStart(2, '0');
        const mm = String(Math.floor(m / 10) * 10 % 60).padStart(2, '0');
        return `${hh}:${mm}`;
    }

    updateClockUI() {
        if (!this.dom || !this.dom.clockDisplay) return;
        const t = this.state.time;
        this.dom.clockDisplay.textContent = this.formatClock(t);
        const icon = t >= 1440 ? '🌙' : t >= 1110 ? '🌇' : t >= 1020 ? '🌤️' : '☀️';
        if (this.dom.clockIcon) this.dom.clockIcon.textContent = icon;
        this.dom.clockDisplay.parentElement.classList.toggle('late', t >= 1440);
    }

    tickClock(dt) {
        if (!this.state || typeof this.state.time !== 'number') this.state.time = this.DAY_START;
        // pausa com qualquer janela aberta (loja, diálogo, escolha de personagem, resumo da noite...)
        if (document.querySelector('.modal-overlay.active')) return;
        this._clockAcc = (this._clockAcc || 0) + Math.min(dt, 100);
        const TICK_MS = 7000;           // 7 s reais = 10 min de jogo
        let changed = false;
        while (this._clockAcc >= TICK_MS) {
            this._clockAcc -= TICK_MS;
            this.state.time += 10;
            changed = true;
        }
        // avança suavemente entre os ticks (para o escurecer ficar fluido) sem mudar o texto
        this._clockFrac = this._clockAcc / TICK_MS * 10;
        if (!changed) return;
        this.updateClockUI();
        if (this.state.time >= 1440 && !this._midnightWarned && this.state.time < 1560) {
            this._midnightWarned = true;
            this.showToast('🌙 Já é meia-noite! Vá para a cama dormir.', 'gold');
            window.soundManager && window.soundManager.playSleep && window.soundManager.playSleep();
            this.openModal('modal-midnight');
        }
        if (this.state.time >= 1560) {
            this.advanceDay(true);
            return;
        }
        if (this.state.time % 60 === 0) this.saveState();
    }

    advanceDay(passedOut) {
        this.state.day++;
        this.state.time = this.DAY_START;
        this._midnightWarned = false;
        this.closeAllModals();
        this.state.player.stamina = passedOut ? Math.round(this.state.player.maxStamina * 0.5) : this.state.player.maxStamina;
        if (passedOut && this.state.currentScene !== 'house') this.enterHouse();
        window.soundManager.playSleep();

        const willRain = Math.random() < 0.25;
        this.state.weather = willRain ? 'rainy' : 'sunny';

        let grownCount = 0;
        let readyCount = 0;

        this.state.farmPlots.forEach(plot => {
            if (plot.crop && !plot.crop.ready) {
                if (plot.isWatered) {
                    plot.crop.daysPlanted++;
                    grownCount++;
                    if (plot.crop.daysPlanted >= plot.crop.daysToGrow) {
                        plot.crop.ready = true;
                        readyCount++;
                    }
                }
            }

            if (willRain) {
                if (plot.state === 'tilled') plot.isWatered = true;
            } else {
                plot.isWatered = false;
            }
        });

        this.saveState();
        this.updateUI();

        const weatherDesc = willRain ? '🌧️ Chuvoso (A chuva regou seus canteiros!)' : '☀️ Ensolarado';
        this.dom.nightRecapDetails.innerHTML = `
            <div><strong>Dia:</strong> #${this.state.day}</div>
            <div><strong>Clima de Hoje:</strong> ${weatherDesc}</div>
            <div><strong>Plantas que cresceram:</strong> ${grownCount}</div>
            <div><strong>Prontas para Colher:</strong> <span style="color: var(--gold); font-weight: 800;">${readyCount}</span></div>
            <div><strong>Energia do Fazendeiro:</strong> ${passedOut ? '50% (você desmaiou de cansaço às 02:00)' : '100% Restaurada!'}</div>
        `;
        this.openModal('modal-night-recap');
    }

    openShop(tab) {
        if (tab === 'seeds' || tab === 'furniture') {
            this.currentShopTab = tab;
        }
        this.dom.shopCategoryTabs.forEach(t => t.classList.toggle('active', t.dataset.tab === this.currentShopTab));
        this.renderShopItems();
        this.openModal('modal-shop');
    }

    renderShopItems() {
        this.dom.shopItemsList.innerHTML = '';

        if (this.currentShopTab === 'seeds') {
            Object.values(CROPS_DATA).forEach(crop => {
                const canAfford = this.state.gold >= crop.seedCost;
                const card = document.createElement('div');
                card.className = 'shop-item-card';
                card.innerHTML = `
                    <div class="shop-item-info">
                        <div class="shop-item-icon">${crop.icon}</div>
                        <div class="shop-item-details">
                            <h4>${crop.seedName}</h4>
                            <p>Cresce em ${crop.daysToGrow} dias • Vende por <strong>${crop.sellPrice}🪙</strong></p>
                        </div>
                    </div>
                    <div style="display: flex; gap: 6px;">
                        <button class="shop-buy-btn" data-type="${crop.id}" data-cat="seed" data-amount="1" ${!canAfford ? 'disabled' : ''}>
                            1x (${crop.seedCost}🪙)
                        </button>
                        <button class="shop-buy-btn" data-type="${crop.id}" data-cat="seed" data-amount="5" ${this.state.gold < crop.seedCost * 5 ? 'disabled' : ''}>
                            5x (${crop.seedCost * 5}🪙)
                        </button>
                    </div>
                `;
                this.dom.shopItemsList.appendChild(card);
            });
        } else {
            // Filtro por conjunto (Clássicos, Gata Preta, Gata Rosa, Cachorro Caramelo)
            if (!this.currentFurnitureSet) this.currentFurnitureSet = 'all';
            const bar = document.createElement('div');
            bar.className = 'furniture-set-bar';
            const setList = [{ id: 'all', name: 'Todos', emoji: '✨' }, ...Object.values(window.FURNITURE_SETS || {})];
            setList.forEach(st => {
                const b = document.createElement('button');
                b.className = 'furniture-set-btn' + (st.id === this.currentFurnitureSet ? ' active' : '');
                b.textContent = `${st.emoji} ${st.name}`;
                b.addEventListener('click', () => {
                    this.currentFurnitureSet = st.id;
                    window.soundManager.playClick();
                    this.renderShopItems();
                });
                bar.appendChild(b);
            });
            this.dom.shopItemsList.appendChild(bar);

            Object.values(FURNITURE_CATALOG).filter(it =>
                this.currentFurnitureSet === 'all' || (it.set || 'classic') === this.currentFurnitureSet
            ).forEach(item => {
                const canAfford = this.state.gold >= item.cost;
                const card = document.createElement('div');
                card.className = 'shop-item-card';
                const iconHtml = item.sprite
                    ? `<div class="shop-item-icon shop-item-thumb"><img src="${item.sprite}" alt=""></div>`
                    : `<div class="shop-item-icon" style="background: ${item.colorMain}; border: 1px solid ${item.colorAccent}; font-size: 1.2rem;">🛋️</div>`;
                card.innerHTML = `
                    <div class="shop-item-info">
                        ${iconHtml}
                        <div class="shop-item-details">
                            <h4>${item.name}</h4>
                            <p>${item.desc} (${item.width}x${item.height} blocos)</p>
                        </div>
                    </div>
                    <div>
                        <button class="shop-buy-btn" data-type="${item.id}" data-cat="furniture" data-amount="1" ${!canAfford ? 'disabled' : ''}>
                            Comprar (${item.cost}🪙)
                        </button>
                    </div>
                `;
                this.dom.shopItemsList.appendChild(card);
            });
        }

        this.dom.shopItemsList.querySelectorAll('.shop-buy-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const type = btn.dataset.type;
                const cat = btn.dataset.cat;
                const amount = parseInt(btn.dataset.amount, 10);

                if (cat === 'seed') {
                    this.buySeed(type, amount);
                } else {
                    this.buyFurniture(type);
                }
            });
        });
    }

    buySeed(seedType, amount) {
        const cost = CROPS_DATA[seedType].seedCost * amount;
        if (this.state.gold < cost) return;

        this.state.gold -= cost;
        this.state.inventory.seeds[seedType] = (this.state.inventory.seeds[seedType] || 0) + amount;

        window.soundManager.playCoin();
        this.showToast(`+${amount} ${CROPS_DATA[seedType].seedName}!`, 'gold');
        this.saveState();
        this.updateUI();
        this.renderShopItems();
    }

    buyFurniture(type) {
        const item = FURNITURE_CATALOG[type];
        if (this.state.gold < item.cost) return;

        this.state.gold -= item.cost;
        this.state.inventory.furniture.push(type);

        window.soundManager.playCoin();
        this.showToast(`+1 ${item.name} adicionado ao Inventário de Decoração!`, 'gold');
        this.saveState();
        this.updateUI();
        this.renderShopItems();
        if (this.decorMode) this.renderFurnitureStockList();
    }

    updateUI() {
        this.dom.dayDisplay.textContent = `Dia ${this.state.day}`;
        this.updateClockUI();
        this.dom.goldDisplay.textContent = `${this.state.gold}g`;

        const weatherIcon = this.state.weather === 'rainy' ? '🌧️' : '☀️';
        const weatherLabel = this.state.weather === 'rainy' ? 'Chuvoso' : 'Ensolarado';
        this.dom.weatherDisplay.textContent = `${weatherIcon} ${weatherLabel}`;

        this.renderHotbar();
    }

    renderHotbar() {
        if (!this.dom.hotbar) return;

        // Se os elementos dos slots ainda não foram criados, instancia-os
        if (this.dom.hotbar.children.length === 0) {
            this.dom.hotbar.innerHTML = '';
            this.hotbarConfig.forEach((slot, index) => {
                const slotEl = document.createElement('div');
                slotEl.className = `sdv-slot ${index === this.activeHotbarIndex ? 'active' : ''}`;
                slotEl.dataset.index = index;

                slotEl.innerHTML = `
                    <span class="slot-key">${slot.key}</span>
                    ${slot.badge ? `<span class="slot-type-badge">${slot.badge}</span>` : ''}
                    <div class="slot-icon">${slot.iconHtml || slot.iconEmoji}</div>
                    <span class="slot-qty"></span>
                `;

                slotEl.addEventListener('click', () => {
                    this.selectHotbarSlotByIndex(index);
                    window.soundManager.playClick();
                });

                slotEl.addEventListener('mouseenter', () => {
                    this.showHotbarTooltip(slot, slotEl);
                });

                slotEl.addEventListener('mouseleave', () => {
                    this.hideHotbarTooltip();
                });

                this.dom.hotbar.appendChild(slotEl);
            });
        }

        // Atualiza quantidades e classes ativas em cada caixa
        const slotElements = this.dom.hotbar.querySelectorAll('.sdv-slot');
        this.hotbarConfig.forEach((slot, index) => {
            const el = slotElements[index];
            if (!el) return;

            el.classList.toggle('active', index === this.activeHotbarIndex);

            const qtyEl = el.querySelector('.slot-qty');
            let isEmpty = false;

            if (slot.type === 'seed') {
                const count = (this.state.inventory.seeds && this.state.inventory.seeds[slot.cropId]) || 0;
                isEmpty = count <= 0;
                if (qtyEl) qtyEl.textContent = count > 0 ? `${count}` : '0';
            } else if (slot.type === 'crop') {
                const count = (this.state.inventory.crops && this.state.inventory.crops[slot.cropId]) || 0;
                isEmpty = count <= 0;
                if (qtyEl) qtyEl.textContent = count > 0 ? `${count}` : '0';
            } else if (slot.type === 'action') {
                let totalCrops = 0;
                if (this.state.inventory.crops) {
                    Object.values(this.state.inventory.crops).forEach(v => totalCrops += (v || 0));
                }
                if (qtyEl) qtyEl.textContent = totalCrops > 0 ? `${totalCrops}` : '';
                isEmpty = totalCrops <= 0;
            } else {
                if (qtyEl) qtyEl.textContent = '';
            }

            el.classList.toggle('empty', isEmpty);
        });
    }

    selectHotbarSlotByIndex(index) {
        if (index < 0 || index >= this.hotbarConfig.length) return;
        this.activeHotbarIndex = index;
        const slot = this.hotbarConfig[index];

        if (slot.type === 'tool') {
            this.activeTool = slot.tool;
        } else if (slot.type === 'seed') {
            this.activeTool = 'seed';
            this.activeSeed = slot.cropId;
        } else if (slot.type === 'crop') {
            this.activeTool = 'crop';
            this.activeCrop = slot.cropId;
        } else if (slot.type === 'action' && slot.action === 'shipping') {
            this.sellAllHarvest();
        }

        this.renderHotbar();
    }

    cycleHotbar(delta) {
        let next = this.activeHotbarIndex + delta;
        if (next < 0) next = this.hotbarConfig.length - 1;
        if (next >= this.hotbarConfig.length) next = 0;
        this.selectHotbarSlotByIndex(next);
        window.soundManager.playClick();
    }

    showHotbarTooltip(slot, element) {
        if (!this.dom.hotbarTooltip) return;
        let qtyText = '';
        if (slot.type === 'seed') {
            const count = (this.state.inventory.seeds && this.state.inventory.seeds[slot.cropId]) || 0;
            qtyText = ` • Estoque: ${count} semente(s)`;
        } else if (slot.type === 'crop') {
            const count = (this.state.inventory.crops && this.state.inventory.crops[slot.cropId]) || 0;
            qtyText = ` • No Cesto: ${count} colhida(s)`;
        } else if (slot.type === 'action') {
            let totalCrops = 0;
            let totalVal = 0;
            if (this.state.inventory.crops) {
                Object.keys(this.state.inventory.crops).forEach(k => {
                    const qty = this.state.inventory.crops[k] || 0;
                    totalCrops += qty;
                    totalVal += qty * (CROPS_DATA[k] ? CROPS_DATA[k].sellPrice : 0);
                });
            }
            qtyText = totalCrops > 0 ? ` • ${totalCrops} itens prontos (+${totalVal}g)` : ' • Cesto vazio';
        }

        if (this.dom.hotbarTooltipTitle) this.dom.hotbarTooltipTitle.textContent = slot.name;
        if (this.dom.hotbarTooltipSub) this.dom.hotbarTooltipSub.textContent = `${slot.subtext}${qtyText}`;
        if (this.dom.hotbarTooltipDesc) this.dom.hotbarTooltipDesc.textContent = slot.desc;

        if (this.dom.hotbarContainer) {
            const rect = element.getBoundingClientRect();
            const containerRect = this.dom.hotbarContainer.getBoundingClientRect();
            const leftOffset = (rect.left + rect.width / 2) - containerRect.left;
            this.dom.hotbarTooltip.style.left = `${leftOffset}px`;
            this.dom.hotbarTooltip.classList.add('show');
        }
    }

    hideHotbarTooltip() {
        if (this.dom.hotbarTooltip) {
            this.dom.hotbarTooltip.classList.remove('show');
        }
    }

    selectTool(tool) {
        const index = this.hotbarConfig.findIndex(s => s.type === 'tool' && s.tool === tool);
        if (index !== -1) {
            this.selectHotbarSlotByIndex(index);
        }
    }

    selectSeed(seedType) {
        const index = this.hotbarConfig.findIndex(s => s.type === 'seed' && s.cropId === seedType);
        if (index !== -1) {
            this.selectHotbarSlotByIndex(index);
        }
    }

    showToast(message, type = 'gold') {
        const toast = document.createElement('div');
        toast.className = `floating-text ${type}`;
        toast.textContent = message;

        toast.style.left = '50%';
        toast.style.top = '15%';
        toast.style.transform = 'translate(-50%, 0)';

        document.body.appendChild(toast);
        setTimeout(() => {
            if (toast && toast.parentNode) toast.parentNode.removeChild(toast);
        }, 1200);
    }

    openModal(id) {
        const m = document.getElementById(id);
        if (m) m.classList.add('active');
    }

    closeAllModals() {
        document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
    }

    loop(timestamp) {
        const dt = timestamp - this.lastFrameTime;
        this.lastFrameTime = timestamp;

        this.updatePlayerMovement();
        this.tickClock(dt);

        // Transparência suave na hotbar quando o personagem caminha perto do fundo da tela
        if (this.dom && this.dom.hotbarContainer) {
            const camY = (['farm', 'city', 'barn', 'barnin'].includes(this.state.currentScene) && this.renderer && this.renderer.cam) ? this.renderer.cam.y : 0;
            const isNearBottom = (this.state.player.y - camY) > (MAP_CONFIG.farm.rows - 3.2) * MAP_CONFIG.tileSize;
            this.dom.hotbarContainer.classList.toggle('player-near', isNearBottom);
        }

        if (this._hudScene !== this.state.currentScene) {
            this._hudScene = this.state.currentScene;
            const names = { farm: '🌾 Vale do Crepúsculo (Fazenda)', house: '🏠 Interior da Casa', barn: '🐄 Celeiro', barnin: '🏚️ ' + ({ cow: 'Celeiro', pig: 'Abrigo dos Porquinhos', hen: 'Galinheiro' }[this.state.barnInKind || 'cow']), house2: '🏡 Casa dos Amigos', city: '🏙️ Centro da Cidade' };
            if (this.dom && this.dom.locationDisplay && names[this._hudScene]) {
                this.dom.locationDisplay.textContent = names[this._hudScene];
            }
        }

        this.renderer.render({
            currentScene: this.state.currentScene,
            player: this.state.player,
            npcs: this.getActiveNPCs(),
            weather: this.state.weather,
            time: (this.state.time || 360) + (this._clockFrac || 0),
            farmPlots: this.state.farmPlots,
            placedFurniture: this.state.placedFurniture,
            interactionPrompt: this.interactionPrompt,
            decorMode: this.decorMode,
            draggedFurniture: this.draggedFurniture,
            dragGhostPos: this.dragGhostPos,
            dragGhostValid: this.dragGhostValid,
            selectedPlacedFurniture: this.selectedPlacedFurniture,
            soilSelection: this.soilSelection
        });

        requestAnimationFrame(this.loop);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.game = new FarmRPGGame();
});
