/**
 * VALE DO CREPÚSCULO - GERENCIADOR DE ÁUDIO WEB AUDIO API
 * Efeitos sonoros e trilha sonora acolhedora (cozy farm ambient) sintetizados proceduralmente.
 * Sem dependência de arquivos externos mp3/wav.
 * Sistema resiliente com auto-recuperação de foco, visibilidade e gestos do jogador.
 */

class SoundManager {
    constructor() {
        this.ctx = null;
        this.masterGain = null;
        this.sfxGain = null;
        this.bgmGain = null;

        // Por padrão o som inicia ativado (salvo se o usuário explicitamente mutou)
        const savedMute = localStorage.getItem('stardew_sound_muted');
        this.muted = savedMute === 'true';

        this.bgmPlaying = false;
        this.bgmTimer = null;
        this.lastStepTime = 0;
        this.unlocked = false;
        this.barIdx = 0;

        // Auto-desbloqueio persistente e resiliente
        this.setupAutoUnlock();
    }

    setupGainNodes() {
        if (!this.ctx) return;
        if (!this.masterGain) {
            this.masterGain = this.ctx.createGain();
            this.sfxGain = this.ctx.createGain();
            this.bgmGain = this.ctx.createGain();

            const now = this.ctx.currentTime;
            this.masterGain.gain.setValueAtTime(this.muted ? 0.0001 : 0.85, now);
            this.sfxGain.gain.setValueAtTime(0.75, now);
            this.bgmGain.gain.setValueAtTime(0.35, now); // Volume claro, aconchegante e audível

            this.sfxGain.connect(this.masterGain);
            this.bgmGain.connect(this.masterGain);
            this.masterGain.connect(this.ctx.destination);
        }
    }

    setupAutoUnlock() {
        const tryResume = () => {
            if (!this.ctx) {
                this.unlockAudio();
            } else if (this.ctx.state === 'suspended') {
                this.ctx.resume().then(() => {
                    if (!this.muted && !this.bgmPlaying) {
                        this.startBGM();
                    }
                }).catch(() => {});
            } else if (!this.muted && !this.bgmPlaying) {
                this.startBGM();
            }
        };

        // Mantém ouvintes permanentes em interações comuns para reativação imediata
        ['click', 'pointerdown', 'keydown', 'touchstart'].forEach(evt => {
            window.addEventListener(evt, tryResume, { passive: true });
        });

        // Retomada automática ao voltar para a aba ou focar na janela do navegador
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                tryResume();
            }
        });
        window.addEventListener('focus', tryResume);
    }

    unlockAudio() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            this.ctx = new AudioCtx();
            this.setupGainNodes();

            // Monitora mudanças de estado do contexto
            this.ctx.onstatechange = () => {
                if (this.ctx && this.ctx.state === 'running' && !this.muted && !this.bgmPlaying) {
                    this.startBGM();
                }
            };
        }

        if (this.ctx.state === 'suspended') {
            this.ctx.resume().then(() => {
                if (!this.muted && !this.bgmPlaying) {
                    this.startBGM();
                }
            }).catch(() => {});
        }

        this.unlocked = true;

        if (!this.muted && !this.bgmPlaying) {
            this.startBGM();
        }
    }

    ensureContext() {
        if (!this.ctx) {
            this.unlockAudio();
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume().catch(() => {});
        }
        return !!this.ctx;
    }

    toggleMute() {
        this.ensureContext();
        this.muted = !this.muted;
        localStorage.setItem('stardew_sound_muted', this.muted);

        if (this.masterGain && this.ctx) {
            const now = this.ctx.currentTime;
            this.masterGain.gain.cancelScheduledValues(now);
            this.masterGain.gain.setValueAtTime(this.masterGain.gain.value, now);
            this.masterGain.gain.linearRampToValueAtTime(this.muted ? 0.0001 : 0.85, now + 0.05);
        }

        if (!this.muted) {
            if (!this.bgmPlaying) {
                this.startBGM();
            }
            setTimeout(() => this.playCoin(), 60);
        } else {
            this.stopBGM();
        }

        return this.muted;
    }

    isMuted() {
        return this.muted;
    }

    // ==========================================================
    // MÚSICA DE FUNDO ACOLHEDORA (STARDEW COZY AMBIENT BGM)
    // ==========================================================
    startBGM() {
        if (this.muted) return;
        this.bgmPlaying = true;
        if (this.bgmTimer) {
            clearTimeout(this.bgmTimer);
            this.bgmTimer = null;
        }

        // Progressão harmônica relaxante e doce de fazenda (8 compassos em Dó Maior / Lá Menor)
        // Cada compasso possui: Baixo raiz, Acorde caloroso tipo Rhodes e Melodia delicada tipo Kalimba/Violão
        const progression = [
            {
                // Cmaj7 (Dó Maior com 7ª Maior)
                bass: 65.41, // C2
                chord: [130.81, 196.00, 246.94, 329.63], // C3, G3, B3, E4
                melody: [
                    { time: 0.25, freq: 523.25 }, // C5
                    { time: 1.10, freq: 659.25 }, // E5
                    { time: 1.85, freq: 587.33 }, // D5
                    { time: 2.50, freq: 493.88 }  // B4
                ]
            },
            {
                // Fmaj7 (Fá Maior com 7ª Maior)
                bass: 87.31, // F2
                chord: [174.61, 220.00, 261.63, 329.63], // F3, A3, C4, E4
                melody: [
                    { time: 0.30, freq: 440.00 }, // A4
                    { time: 1.15, freq: 523.25 }, // C5
                    { time: 1.90, freq: 659.25 }, // E5
                    { time: 2.55, freq: 587.33 }  // D5
                ]
            },
            {
                // Em7 (Mi Menor com 7ª)
                bass: 82.41, // E2
                chord: [164.81, 196.00, 246.94, 293.66], // E3, G3, B3, D4
                melody: [
                    { time: 0.25, freq: 392.00 }, // G4
                    { time: 1.10, freq: 493.88 }, // B4
                    { time: 1.85, freq: 587.33 }, // D5
                    { time: 2.50, freq: 523.25 }  // C5
                ]
            },
            {
                // Am7 (Lá Menor com 7ª)
                bass: 55.00, // A1
                chord: [220.00, 261.63, 329.63, 392.00], // A3, C4, E4, G4
                melody: [
                    { time: 0.30, freq: 523.25 }, // C5
                    { time: 1.15, freq: 440.00 }, // A4
                    { time: 1.90, freq: 392.00 }, // G4
                    { time: 2.55, freq: 329.63 }  // E4
                ]
            },
            {
                // Dm7 (Ré Menor com 7ª)
                bass: 73.42, // D2
                chord: [146.83, 174.61, 220.00, 261.63], // D3, F3, A3, C4
                melody: [
                    { time: 0.25, freq: 587.33 }, // D5
                    { time: 1.10, freq: 523.25 }, // C5
                    { time: 1.85, freq: 440.00 }, // A4
                    { time: 2.50, freq: 392.00 }  // G4
                ]
            },
            {
                // G7 (Sol com 7ª)
                bass: 49.00, // G1
                chord: [196.00, 246.94, 293.66, 349.23], // G3, B3, D4, F4
                melody: [
                    { time: 0.30, freq: 392.00 }, // G4
                    { time: 1.15, freq: 493.88 }, // B4
                    { time: 1.90, freq: 587.33 }, // D5
                    { time: 2.55, freq: 659.25 }  // E5
                ]
            },
            {
                // Em7 (Mi Menor)
                bass: 82.41, // E2
                chord: [164.81, 196.00, 246.94, 329.63], // E3, G3, B3, E4
                melody: [
                    { time: 0.25, freq: 659.25 }, // E5
                    { time: 1.10, freq: 587.33 }, // D5
                    { time: 1.85, freq: 523.25 }, // C5
                    { time: 2.50, freq: 440.00 }  // A4
                ]
            },
            {
                // Cadd9 (Dó com 9ª - resolução alegre e calorosa)
                bass: 65.41, // C2
                chord: [130.81, 196.00, 293.66, 329.63], // C3, G3, D4, E4
                melody: [
                    { time: 0.30, freq: 523.25 }, // C5
                    { time: 1.15, freq: 659.25 }, // E5
                    { time: 1.90, freq: 783.99 }, // G5
                    { time: 2.55, freq: 523.25 }  // C5
                ]
            }
        ];

        const barDuration = 3.2; // segundos por compasso (ritmo calmo de ~75 BPM)

        const playNextBar = () => {
            if (!this.bgmPlaying || this.muted) return;
            if (!this.ensureContext()) {
                this.bgmTimer = setTimeout(playNextBar, 1000);
                return;
            }

            try {
                const now = this.ctx.currentTime;
                const bar = progression[this.barIdx % progression.length];
                this.barIdx++;

                // 1. NOTA DE BAIXO PROFUNDA E ACOLHEDORA
                if (bar.bass) {
                    const bassOsc = this.ctx.createOscillator();
                    const bassGain = this.ctx.createGain();
                    const bassFilter = this.ctx.createBiquadFilter();

                    bassOsc.type = 'sine';
                    bassOsc.frequency.setValueAtTime(bar.bass, now);

                    bassFilter.type = 'lowpass';
                    bassFilter.frequency.setValueAtTime(260, now);

                    bassGain.gain.setValueAtTime(0.0001, now);
                    bassGain.gain.linearRampToValueAtTime(0.18, now + 0.15);
                    bassGain.gain.exponentialRampToValueAtTime(0.0001, now + barDuration * 0.85);

                    bassOsc.connect(bassFilter);
                    bassFilter.connect(bassGain);
                    bassGain.connect(this.bgmGain);

                    bassOsc.start(now);
                    bassOsc.stop(now + barDuration * 0.9);
                }

                // 2. ACORDE ESTILO RHODES / SINTETIZADOR ANALÓGICO
                bar.chord.forEach((freq, i) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    const filter = this.ctx.createBiquadFilter();

                    osc.type = i === 0 ? 'sine' : 'triangle';
                    const noteStart = now + i * 0.04;
                    osc.frequency.setValueAtTime(freq, noteStart);

                    filter.type = 'lowpass';
                    filter.frequency.setValueAtTime(1100, now);

                    gain.gain.setValueAtTime(0.0001, noteStart);
                    gain.gain.linearRampToValueAtTime(0.09, noteStart + 0.25);
                    gain.gain.linearRampToValueAtTime(0.05, noteStart + 1.8);
                    gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + barDuration * 0.95);

                    osc.connect(filter);
                    filter.connect(gain);
                    gain.connect(this.bgmGain);

                    osc.start(noteStart);
                    osc.stop(noteStart + barDuration);
                });

                // 3. NOTAS MELÓDICAS TIPO KALIMBA / VIOLÃO ACÚSTICO
                if (bar.melody) {
                    bar.melody.forEach(m => {
                        const mStart = now + m.time;
                        const mOsc = this.ctx.createOscillator();
                        const mGain = this.ctx.createGain();

                        mOsc.type = 'sine';
                        mOsc.frequency.setValueAtTime(m.freq, mStart);

                        mGain.gain.setValueAtTime(0.0001, mStart);
                        mGain.gain.linearRampToValueAtTime(0.08, mStart + 0.02);
                        mGain.gain.exponentialRampToValueAtTime(0.0001, mStart + 0.75);

                        mOsc.connect(mGain);
                        mGain.connect(this.bgmGain);

                        mOsc.start(mStart);
                        mOsc.stop(mStart + 0.8);
                    });
                }
            } catch (e) {
                console.warn('BGM bar error:', e);
            }

            this.bgmTimer = setTimeout(playNextBar, barDuration * 1000);
        };

        playNextBar();
    }

    stopBGM() {
        this.bgmPlaying = false;
        if (this.bgmTimer) {
            clearTimeout(this.bgmTimer);
            this.bgmTimer = null;
        }
    }

    // ==========================================================
    // EFEITOS SONOROS DE AÇÃO (SFX)
    // ==========================================================

    // Passo do personagem (grama ou piso de madeira)
    playStep(isWood = false) {
        if (this.muted) return;
        const nowMs = performance.now();
        if (nowMs - this.lastStepTime < 220) return;
        this.lastStepTime = nowMs;

        if (!this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = isWood ? 'sine' : 'triangle';
            const baseFreq = isWood ? 160 : 115;
            osc.frequency.setValueAtTime(baseFreq + (Math.random() * 24 - 12), now);
            osc.frequency.linearRampToValueAtTime(35, now + 0.06);

            gain.gain.setValueAtTime(0.25, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.07);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.08);
        } catch (e) {}
    }

    // Transição de porta (Entrar / Sair da Casa)
    playDoor() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const chord = [330, 440, 660];

            chord.forEach((freq, i) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                const start = now + i * 0.05;

                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, start);

                gain.gain.setValueAtTime(0.3, start);
                gain.gain.linearRampToValueAtTime(0.0001, start + 0.25);

                osc.connect(gain);
                gain.connect(this.sfxGain);

                osc.start(start);
                osc.stop(start + 0.26);
            });
        } catch (e) {}
    }

    // Posicionar móvel (thud acolhedor de madeira)
    playFurniturePlace() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(190, now);
            osc.frequency.linearRampToValueAtTime(65, now + 0.11);

            gain.gain.setValueAtTime(0.45, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.13);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.14);
        } catch (e) {}
    }

    // Recolher móvel (pop ascendente)
    playFurniturePickup() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(280, now);
            osc.frequency.linearRampToValueAtTime(560, now + 0.09);

            gain.gain.setValueAtTime(0.4, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.1);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.11);
        } catch (e) {}
    }

    // Som da Enxada (Arar terra - som rústico de escavação)
    playTill() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(160, now);
            osc.frequency.linearRampToValueAtTime(45, now + 0.13);

            gain.gain.setValueAtTime(0.5, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.15);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.16);
        } catch (e) {}
    }

    // Som do Regador (Água cristalina borrifando)
    playWater() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;

            [0, 0.05, 0.1].forEach((delay, idx) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                const start = now + delay;

                osc.type = 'sine';
                const baseFreq = 540 + idx * 140;
                osc.frequency.setValueAtTime(baseFreq, start);
                osc.frequency.linearRampToValueAtTime(baseFreq + 280, start + 0.08);

                gain.gain.setValueAtTime(0.35, start);
                gain.gain.linearRampToValueAtTime(0.0001, start + 0.09);

                osc.connect(gain);
                gain.connect(this.sfxGain);

                osc.start(start);
                osc.stop(start + 0.1);
            });
        } catch (e) {}
    }

    // Som de Plantar Semente (pop vegetal delicado)
    playPlant() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(340, now);
            osc.frequency.linearRampToValueAtTime(680, now + 0.1);

            gain.gain.setValueAtTime(0.4, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.11);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.12);
        } catch (e) {}
    }

    // Som de Colheita (Arpeggio alegre em Sol Maior)
    playHarvest() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const notes = [392.00, 493.88, 587.33, 783.99, 987.77];

            notes.forEach((freq, idx) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                const startTime = now + idx * 0.055;

                osc.type = 'triangle';
                osc.frequency.setValueAtTime(freq, startTime);

                gain.gain.setValueAtTime(0.35, startTime);
                gain.gain.linearRampToValueAtTime(0.0001, startTime + 0.22);

                osc.connect(gain);
                gain.connect(this.sfxGain);

                osc.start(startTime);
                osc.stop(startTime + 0.24);
            });
        } catch (e) {}
    }

    // Som de Moedas / Venda (Jingle brilhante de ouro)
    playCoin() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const tones = [987.77, 1318.51, 1567.98];

            tones.forEach((freq, idx) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                const startTime = now + idx * 0.07;

                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, startTime);

                gain.gain.setValueAtTime(0.4, startTime);
                gain.gain.linearRampToValueAtTime(0.0001, startTime + 0.28);

                osc.connect(gain);
                gain.connect(this.sfxGain);

                osc.start(startTime);
                osc.stop(startTime + 0.3);
            });
        } catch (e) {}
    }

    // Som de Diálogo Stardew Valley (Blip fofo ao conversar com NPCs)
    playDialogueBlip() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'triangle';
            const rndFreq = 420 + Math.random() * 120;
            osc.frequency.setValueAtTime(rndFreq, now);
            osc.frequency.linearRampToValueAtTime(rndFreq + 80, now + 0.04);

            gain.gain.setValueAtTime(0.24, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.05);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.06);
        } catch (e) {}
    }

    // Som de Dormir / Passar a Noite (Acorde pacífico de ninar)
    playSleep() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const chord = [392.00, 493.88, 587.33, 783.99];

            chord.forEach((freq, idx) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                const startTime = now + idx * 0.09;

                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, startTime);

                gain.gain.setValueAtTime(0.3, startTime);
                gain.gain.linearRampToValueAtTime(0.0001, startTime + 0.7);

                osc.connect(gain);
                gain.connect(this.sfxGain);

                osc.start(startTime);
                osc.stop(startTime + 0.75);
            });
        } catch (e) {}
    }

    // Som de Erro
    playError() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(140, now);
            osc.frequency.setValueAtTime(115, now + 0.07);

            gain.gain.setValueAtTime(0.22, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.16);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.18);
        } catch (e) {}
    }

    // Som de Clique na UI
    playClick() {
        if (this.muted || !this.ensureContext()) return;

        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(680, now);
            osc.frequency.linearRampToValueAtTime(320, now + 0.04);

            gain.gain.setValueAtTime(0.25, now);
            gain.gain.linearRampToValueAtTime(0.0001, now + 0.05);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(now);
            osc.stop(now + 0.06);
        } catch (e) {}
    }
}

window.soundManager = new SoundManager();
