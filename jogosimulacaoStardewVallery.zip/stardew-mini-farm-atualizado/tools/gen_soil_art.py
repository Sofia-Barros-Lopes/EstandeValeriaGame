#!/usr/bin/env python3
"""
Gera os assets de pixel art da plantação (rode da raiz do projeto: python3 tools/gen_soil_art.py)

  assets/soil_tiles.png  -> tiles de terra 32x32 (arte em 16x16, ampliada 2x sem suavização)
        linhas = estado x variação: [vazia(0-2), arada(3-5), regada(6-8)]
        colunas = máscara de vizinhos 0..15  (N=1, E=2, S=4, W=8; bit ligado = tem terra do mesmo tipo)
        -> as bordas externas ficam irregulares/arredondadas e o miolo é contínuo (sem grade).
  assets/crops_sheet.png -> plantas 32x48: linhas = cenoura, morango, milho, abóbora;
        colunas = estágio 0 semente, 1 broto, 2 crescendo, 3 pronta para colher.
"""
import random
from PIL import Image

OUT_SOIL = 'assets/soil_tiles.png'
OUT_CROPS = 'assets/crops_sheet.png'
S = 16          # lado do tile em "pixels de arte"
UP = 2          # ampliação (16 -> 32)


def hexc(h, a=255):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def lighten(c, k):
    return (min(255, int(c[0] + (255 - c[0]) * k)), min(255, int(c[1] + (255 - c[1]) * k)), min(255, int(c[2] + (255 - c[2]) * k)), c[3])


def darken(c, k):
    return (int(c[0] * (1 - k)), int(c[1] * (1 - k)), int(c[2] * (1 - k)), c[3])


# ---------------------------------------------------------------- TERRA
PALETTES = {
    # terra vazia (ainda não arada): marrom-claro compactado, com seixos
    'dry': dict(base=['#b57b3f', '#ad7439', '#bb8445', '#a86e36'], speck=['#8f5d2d', '#c8955a'], pebble=['#dcb985', '#7b5230'],
                furrow=None),
    # terra arada: marrom médio com sulcos horizontais
    'tilled': dict(ridge_hi='#9a6338', ridge='#8a5630', base='#7a4a28', furrow='#5b351b', furrow_deep='#4a2b15',
                   speck=['#6a3f20', '#a06a3e'], pebble=['#b88a5a']),
    # terra regada: bem mais escura, úmida, com brilho azulado
    'wet': dict(ridge_hi='#5d3a20', ridge='#4e301a', base='#432916', furrow='#2f1b0d', furrow_deep='#24140a',
                speck=['#2f1b0d', '#6a4a30'], pebble=['#6f8aa0']),
}


def base_texture(kind, variant):
    """Textura 16x16 do miolo (determinística por tipo/variação: igual em todas as máscaras)."""
    rng = random.Random(f'{kind}-{variant}-tex')
    p = PALETTES[kind]
    img = [[None] * S for _ in range(S)]
    if kind == 'dry':
        for y in range(S):
            for x in range(S):
                img[y][x] = hexc(rng.choice(p['base']))
        for _ in range(26):
            img[rng.randrange(S)][rng.randrange(S)] = hexc(rng.choice(p['speck']))
        for _ in range(2 + variant):
            x, y = rng.randrange(1, S - 2), rng.randrange(1, S - 2)
            img[y][x] = hexc(p['pebble'][0]); img[y][x + 1] = hexc(p['pebble'][0])
            img[y + 1][x] = hexc(p['pebble'][1]); img[y + 1][x + 1] = hexc(p['pebble'][1])
        if variant == 2:                       # tufinho de grama seca/verde
            x, y = rng.randrange(3, S - 3), rng.randrange(3, S - 3)
            for dx, dy, col in [(0, 0, '#5f9a3e'), (1, -1, '#7bc74d'), (-1, -1, '#4c8a34'), (0, -1, '#7bc74d')]:
                img[y + dy][x + dx] = hexc(col)
    else:
        for y in range(S):
            m = y % 8
            if m in (0, 1):
                col = p['ridge_hi'] if m == 0 else p['ridge']
            elif m in (2, 3):
                col = p['ridge'] if m == 2 else p['base']
            elif m in (4, 5):
                col = p['furrow'] if m == 4 else p['furrow_deep']
            else:
                col = p['furrow'] if m == 6 else p['base']
            for x in range(S):
                img[y][x] = hexc(col)
        for _ in range(22):                    # torrões e variação
            x, y = rng.randrange(S), rng.randrange(S)
            c = hexc(rng.choice(p['speck']))
            img[y][x] = c
            if rng.random() < 0.4 and x + 1 < S:
                img[y][x + 1] = c
        for _ in range(1 + (variant == 1)):    # pedrinha
            x, y = rng.randrange(1, S - 2), rng.randrange(1, S - 2)
            img[y][x] = hexc(p['pebble'][0])
            if kind == 'tilled':
                img[y][x + 1] = darken(hexc(p['pebble'][0]), 0.25)
        if kind == 'wet':                      # brilho de umidade nos sulcos
            for _ in range(3 + variant):
                x, y = rng.randrange(1, S - 1), rng.choice([4, 12, 5, 13])
                img[y][x] = lighten(hexc('#6f8aa0'), 0.15)
                if rng.random() < 0.6:
                    img[y][x + 1] = hexc('#4f6b82')
    return img


def apply_edges(img, kind, variant, mask):
    """Recorta as bordas sem vizinho: contorno irregular, 'lábio' claro em cima/esquerda, sombra embaixo/direita."""
    out = [[px for px in row] for row in img]
    sides = {'N': not (mask & 1), 'E': not (mask & 2), 'S': not (mask & 4), 'W': not (mask & 8)}
    rng = random.Random(f'{kind}-{variant}-{mask}-edge')

    def profile():
        return [rng.choice([1, 2, 2, 3]) for _ in range(S)]

    cut = [[False] * S for _ in range(S)]
    if sides['N']:
        pr = profile()
        for x in range(S):
            for y in range(pr[x]): cut[y][x] = True
    if sides['S']:
        pr = profile()
        for x in range(S):
            for y in range(pr[x]): cut[S - 1 - y][x] = True
    if sides['W']:
        pr = profile()
        for y in range(S):
            for x in range(pr[y]): cut[y][x] = True
    if sides['E']:
        pr = profile()
        for y in range(S):
            for x in range(pr[y]): cut[y][S - 1 - x] = True
    # cantos arredondados quando duas bordas se encontram
    r = 5
    for (a, b, cx, cy) in [('N', 'W', 0, 0), ('N', 'E', S - 1, 0), ('S', 'W', 0, S - 1), ('S', 'E', S - 1, S - 1)]:
        if sides[a] and sides[b]:
            for y in range(S):
                for x in range(S):
                    if abs(x - cx) + abs(y - cy) < r: cut[y][x] = True
    for y in range(S):
        for x in range(S):
            if cut[y][x]: out[y][x] = None

    def solid(x, y):
        return 0 <= x < S and 0 <= y < S and out[y][x] is not None

    # lábio claro (N/W) e sombra (S/E) nos pixels de contorno
    res = [[px for px in row] for row in out]
    for y in range(S):
        for x in range(S):
            c = out[y][x]
            if c is None: continue
            n_open = (y > 0 and out[y - 1][x] is None) and sides['N'] or (y > 0 and out[y - 1][x] is None and cut[y - 1][x])
            s_open = (y < S - 1 and out[y + 1][x] is None and cut[y + 1][x])
            w_open = (x > 0 and out[y][x - 1] is None and cut[y][x - 1])
            e_open = (x < S - 1 and out[y][x + 1] is None and cut[y][x + 1])
            if n_open: c = lighten(c, 0.18)
            if w_open: c = lighten(c, 0.08)
            if s_open: c = darken(c, 0.22)
            if e_open: c = darken(c, 0.12)
            res[y][x] = c
    # sombrinha suave logo abaixo das bordas inferiores (dentro da área recortada)
    for y in range(S):
        for x in range(S):
            if res[y][x] is None and y > 0 and solid(x, y - 1) and cut[y][x]:
                res[y][x] = (40, 22, 8, 70)
    return res


def upscale(grid, up=UP):
    im = Image.new('RGBA', (len(grid[0]) * up, len(grid) * up), (0, 0, 0, 0))
    for y, row in enumerate(grid):
        for x, c in enumerate(row):
            if c is None: continue
            for dy in range(up):
                for dx in range(up):
                    im.putpixel((x * up + dx, y * up + dy), c)
    return im


def build_soil():
    kinds = ['dry', 'tilled', 'wet']
    atlas = Image.new('RGBA', (16 * S * UP, len(kinds) * 3 * S * UP), (0, 0, 0, 0))
    for ki, kind in enumerate(kinds):
        for v in range(3):
            tex = base_texture(kind, v)
            for mask in range(16):
                tile = upscale(apply_edges(tex, kind, v, mask))
                atlas.paste(tile, (mask * S * UP, (ki * 3 + v) * S * UP))
    atlas.save(OUT_SOIL)


# ---------------------------------------------------------------- PLANTAS
W, H = 16, 24
OUTLINE = (43, 30, 16, 235)
G_DK, G_MD, G_LT, G_HI = hexc('#2f6b2a'), hexc('#4c9a38'), hexc('#7bc74d'), hexc('#b0e870')


class Spr:
    def __init__(self):
        self.g = [[None] * W for _ in range(H)]

    def set(self, x, y, c):
        if 0 <= x < W and 0 <= y < H: self.g[y][x] = c

    def line(self, x0, y0, x1, y1, c):
        n = max(abs(x1 - x0), abs(y1 - y0), 1)
        for i in range(n + 1):
            self.set(round(x0 + (x1 - x0) * i / n), round(y0 + (y1 - y0) * i / n), c)

    def disc(self, cx, cy, rx, ry, base, shade=True):
        for y in range(H):
            for x in range(W):
                dx, dy = (x - cx) / rx, (y - cy) / ry
                d = dx * dx + dy * dy
                if d <= 1.0:
                    c = base
                    if shade:
                        t = dx * 0.6 + dy * 0.8
                        if t < -0.35: c = lighten(base, 0.28)
                        elif t > 0.45: c = darken(base, 0.25)
                    self.set(x, y, c)

    def shadow(self):
        for x in range(4, 13):
            if self.g[20][x] is None: self.g[20][x] = (35, 20, 8, 55)
        for x in range(5, 12):
            if self.g[19][x] is None and x in (5, 6, 10, 11): self.g[19][x] = (35, 20, 8, 45)

    def outline(self):
        src = [[px for px in row] for row in self.g]
        for y in range(H):
            for x in range(W):
                if src[y][x] is not None and src[y][x][3] >= 200: continue
                if src[y][x] is not None: continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < W and 0 <= ny < H and src[ny][nx] is not None and src[ny][nx][3] >= 200:
                        self.g[y][x] = OUTLINE
                        break


def seed_mound(sp, seed_col):
    for x, y, c in [(6, 19, '#a56f3a'), (7, 18, '#b98046'), (8, 18, '#c18a4f'), (9, 18, '#b98046'), (10, 19, '#a56f3a'),
                    (7, 19, '#8d5a2c'), (8, 19, '#8d5a2c'), (9, 19, '#8d5a2c')]:
        sp.set(x, y, hexc(c))
    sp.set(8, 17, hexc(seed_col)); sp.set(9, 17, darken(hexc(seed_col), 0.2))


def frond(sp, x0, y0, x1, y1):
    sp.line(x0, y0, x1, y1, G_MD)
    n = max(abs(x1 - x0), abs(y1 - y0))
    for i in range(1, n + 1):
        px = round(x0 + (x1 - x0) * i / n); py = round(y0 + (y1 - y0) * i / n)
        if i % 2 == 0:
            sp.set(px - 1, py, G_LT); sp.set(px + 1, py, G_LT)
    sp.set(x1, y1 - 1, G_HI)


def carrot(stage):
    sp = Spr()
    if stage == 0: seed_mound(sp, '#f08a24'); return sp
    sp.shadow()
    if stage == 1:
        frond(sp, 8, 19, 7, 15); frond(sp, 8, 19, 10, 15)
    else:
        frond(sp, 8, 19, 4, 11); frond(sp, 8, 19, 8, 8); frond(sp, 8, 19, 12, 11)
        if stage == 2:
            frond(sp, 8, 19, 6, 13)
    if stage == 3:
        sp.disc(8, 19, 3.2, 1.8, hexc('#f28a1f'))
        for x in (7, 9): sp.set(x, 19, hexc('#ffb55a'))
        sp.set(8, 18, hexc('#3f8a2d'))
    return sp


def strawberry(stage):
    sp = Spr()
    if stage == 0: seed_mound(sp, '#e8d27a'); return sp
    sp.shadow()
    if stage == 1:
        sp.disc(6, 17, 2.2, 1.6, G_MD); sp.disc(10, 17, 2.2, 1.6, G_MD); sp.disc(8, 15, 2.2, 1.6, G_LT)
    else:
        sp.disc(4.5, 17.5, 3.2, 2.4, G_MD); sp.disc(11.5, 17.5, 3.2, 2.4, G_MD)
        sp.disc(8, 15.5, 3.6, 2.8, G_LT); sp.disc(8, 18.5, 4.0, 2.0, G_MD)
        for x, y in [(6, 15), (10, 16), (4, 17), (12, 18)]: sp.set(x, y, G_HI)
        if stage == 2:                                   # florzinha branca
            for x, y in [(8, 12), (7, 13), (9, 13), (8, 14)]: sp.set(x, y, hexc('#fff6e0'))
            sp.set(8, 13, hexc('#f5c842'))
    if stage == 3:
        red, red_hi = hexc('#d72a3a'), hexc('#ff7a85')
        for bx, by in [(4, 19), (8, 20), (12, 19), (6, 16), (11, 15)]:
            sp.disc(bx, by, 1.8, 2.0, red)
            sp.set(bx - 1, by - 1, red_hi)
            sp.set(bx, by - 2, hexc('#3f8a2d'))
            sp.set(bx + 1, by + 1, hexc('#f5d76e'))
    return sp


def corn(stage):
    sp = Spr()
    if stage == 0: seed_mound(sp, '#f2cf4a'); return sp
    sp.shadow()
    if stage == 1:
        sp.line(8, 19, 6, 14, G_MD); sp.line(8, 19, 10, 14, G_MD); sp.line(8, 19, 8, 13, G_LT)
        sp.set(6, 13, G_HI); sp.set(10, 13, G_HI); sp.set(8, 12, G_HI)
        return sp
    top = 8 if stage == 2 else 4
    for y in range(top, 20):
        sp.set(8, y, G_MD); sp.set(9, y, G_DK)
    # folhas longas e caídas
    leaves = [(16, -6, 3), (14, 6, 4), (11, -7, 4), (9, 7, 3)] if stage == 3 else [(16, -5, 2), (13, 5, 3), (10, -5, 3)]
    for (ly, dx, droop) in leaves:
        sx = 8 if dx < 0 else 9
        tx = sx + dx
        ty = ly + droop
        sp.line(sx, ly, sx + dx // 2, ly - 1, G_LT)
        sp.line(sx + dx // 2, ly - 1, tx, ty, G_MD)
        sp.set(tx, ty, G_DK)
    if stage == 3:
        for x, y in [(7, 5), (8, 3), (9, 3), (10, 5), (8, 2), (9, 2)]:  # pendão
            sp.set(x, y, hexc('#d9c26a'))
        for (cx, cy, side) in [(11, 11, 1), (5, 14, -1)]:           # espigas
            for yy in range(cy - 2, cy + 3):
                for xx in (cx, cx + 1):
                    sp.set(xx, yy, hexc('#f4cf3a') if (xx + yy) % 2 == 0 else hexc('#e0b01f'))
            sp.set(cx, cy - 3, hexc('#c9d98a')); sp.set(cx + 1, cy - 3, hexc('#7bc74d'))
            sp.set(cx + (0 if side > 0 else 1), cy, hexc('#fff0a0'))
            sp.set(cx + (-1 if side < 0 else 2), cy + 1, hexc('#4c9a38'))
            sp.set(cx + (-1 if side < 0 else 2), cy + 2, hexc('#4c9a38'))
    return sp


def pumpkin(stage):
    sp = Spr()
    if stage == 0: seed_mound(sp, '#efe3b0'); return sp
    sp.shadow()
    if stage == 1:
        sp.disc(6, 17, 2.6, 1.8, G_MD); sp.disc(10, 17, 2.6, 1.8, G_LT)
        sp.line(8, 19, 8, 17, G_DK)
        return sp
    if stage == 2:
        sp.disc(4.5, 17, 3.2, 2.2, G_MD); sp.disc(11.5, 17, 3.2, 2.2, G_LT)
        sp.disc(8, 14, 3.2, 2.2, G_MD)
        sp.disc(8, 19, 2.6, 1.8, hexc('#8fae3a'))
        sp.line(8, 17, 8, 16, G_DK)
        for x, y in [(4, 16), (12, 16), (8, 13)]: sp.set(x, y, G_HI)
        return sp
    # pronta: grande abóbora laranja com gomos
    sp.disc(3.5, 16, 2.6, 1.6, G_MD); sp.disc(12.5, 16, 2.6, 1.6, G_LT)
    sp.disc(8, 16.5, 6.4, 5.0, hexc('#ee7d1c'))
    for x, y0, y1 in [(5, 13, 20), (8, 12, 21), (11, 13, 20)]:
        for y in range(y0, y1):
            sp.set(x, y, darken(hexc('#ee7d1c'), 0.3))
    for x, y in [(4, 14), (5, 13), (6, 12), (7, 12)]: sp.set(x, y, hexc('#ffb05a'))
    for x, y in [(8, 11), (8, 10), (9, 10)]: sp.set(x, y, hexc('#6b4a22'))
    sp.set(9, 11, hexc('#4c9a38'))
    return sp


def build_crops():
    makers = [carrot, strawberry, corn, pumpkin]
    atlas = Image.new('RGBA', (4 * W * UP, len(makers) * H * UP), (0, 0, 0, 0))
    for r, mk in enumerate(makers):
        for st in range(4):
            sp = mk(st)
            sp.outline()
            atlas.paste(upscale(sp.g), (st * W * UP, r * H * UP))
    atlas.save(OUT_CROPS)


if __name__ == '__main__':
    build_soil()
    build_crops()
    print('ok:', OUT_SOIL, OUT_CROPS)
