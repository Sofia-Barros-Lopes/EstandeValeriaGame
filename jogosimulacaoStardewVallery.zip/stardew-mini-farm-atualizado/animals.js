/**
 * ANIMAIS DOS CURRAIS (vacas, porcos e galinhas)
 * Cada espécie vive no seu cercado do mapa do celeiro (BARN_WORLD.pens): andam, descansam,
 * dormem e podem ser acariciados. Os sprites vêm de folhas em assets/ (a vaca em assets/cow_*.png,
 * o porco em assets/animal_pig.png e a galinha em assets/animal_hen.png).
 * Os retângulos dos frames de cada folha estão em BOXES.
 */
(function () {
    const COW_BOXES = {"brown": [[92, 40, 189, 258], [352, 51, 314, 242], [743, 41, 193, 257], [122, 338, 124, 174], [348, 338, 129, 174], [553, 337, 123, 181], [726, 358, 206, 160], [133, 583, 134, 175], [348, 583, 129, 180], [552, 584, 123, 179], [752, 584, 133, 179], [46, 783, 139, 175], [266, 854, 211, 99], [543, 803, 195, 146], [794, 786, 194, 173]], "white": [[92, 41, 189, 256], [352, 51, 314, 241], [743, 41, 193, 256], [123, 338, 123, 174], [348, 339, 129, 173], [553, 338, 123, 179], [727, 358, 205, 159], [133, 583, 134, 175], [348, 583, 127, 180], [552, 584, 124, 178], [752, 583, 133, 180], [46, 783, 139, 175], [266, 855, 211, 98], [542, 803, 196, 145], [794, 786, 194, 173]], "purple": [[75, 34, 162, 204], [381, 39, 272, 198], [781, 35, 163, 205], [90, 284, 126, 142], [336, 285, 123, 137], [562, 286, 137, 141], [808, 286, 116, 142], [50, 464, 203, 128], [296, 465, 201, 127], [530, 466, 204, 130], [777, 466, 192, 126], [97, 629, 114, 147], [336, 629, 112, 146], [556, 634, 142, 141], [797, 634, 136, 141], [70, 807, 148, 174], [275, 864, 189, 112], [490, 848, 209, 127], [741, 867, 123, 133], [883, 868, 122, 132]]};
    const BOXES = {
        cow: COW_BOXES,
        pig: [[77, 67, 153, 184], [271, 82, 246, 169], [563, 72, 149, 174], [794, 40, 148, 211], [82, 328, 143, 169], [328, 328, 143, 174], [553, 323, 143, 173], [743, 328, 240, 159], [87, 563, 133, 194], [333, 563, 133, 194], [553, 563, 138, 195], [804, 563, 138, 189], [46, 794, 149, 163], [266, 855, 210, 97], [543, 804, 194, 143], [794, 788, 199, 169]],
        hen: [[155, 25, 108, 148], [434, 32, 136, 140], [729, 25, 108, 147], [1014, 25, 108, 148], [155, 193, 108, 155], [445, 193, 108, 155], [724, 193, 109, 151], [999, 198, 145, 150], [155, 369, 108, 151], [445, 369, 108, 151], [730, 369, 108, 151], [1020, 369, 107, 151], [145, 546, 129, 135], [423, 556, 141, 125], [724, 557, 130, 124], [1014, 546, 114, 140]]
    };

    const PIG = { down: [4, 5, 6, 5], up: [8, 9, 10, 11], side: [1, 7], sit: 12, sleep: 14, happy: 3 };
    const HEN = { down: [4, 5, 6, 5], up: [8, 9, 10, 11], side: [1, 7], sit: 12, sleep: 14, happy: 15 };

    // Mapeamento dos frames (índices em BOXES). 'side' = virada para a DIREITA (esquerda é espelhada)
    const SPECIES = {
        cow: {
            targetH: 46, speed: 24, stepTime: 0.22, half: 22, shadow: 14, flipStep: true,
            kinds: [
                { key: 'brown', name: 'Caramelo', img: 'assets/cow_brown.png', down: [3, 4], up: [8, 9], side: [6], sit: 11, sleep: 13, happy: 14 },
                { key: 'white', name: 'Leitinho', img: 'assets/cow_white.png', down: [3, 4], up: [8, 9], side: [6], sit: 11, sleep: 13, happy: 14 },
                { key: 'purple', name: 'Violeta', img: 'assets/cow_purple.png', down: [3, 4], up: [6, 11], side: [8, 9, 10, 9], sit: 15, sleep: 17, happy: 19 }
            ],
            ref: (kind) => kind.down[0]
        },
        pig: {
            targetH: 34, speed: 22, stepTime: 0.24, half: 16, shadow: 12, flipStep: false,
            kinds: [
                Object.assign({ key: 'pig', name: 'Rosinha', img: 'assets/animal_pig.png', scale: 1.0 }, PIG),
                Object.assign({ key: 'pig', name: 'Pipoca', img: 'assets/animal_pig.png', scale: 0.92 }, PIG),
                Object.assign({ key: 'pig', name: 'Lola', img: 'assets/animal_pig.png', scale: 1.06 }, PIG)
            ],
            ref: () => 4
        },
        hen: {
            targetH: 28, speed: 30, stepTime: 0.17, half: 9, shadow: 8, flipStep: false,
            kinds: [
                Object.assign({ key: 'hen', name: 'Penélope', img: 'assets/animal_hen.png', scale: 1.0 }, HEN),
                Object.assign({ key: 'hen', name: 'Cocó', img: 'assets/animal_hen.png', scale: 0.9 }, HEN),
                Object.assign({ key: 'hen', name: 'Pintadinha', img: 'assets/animal_hen.png', scale: 1.05 }, HEN),
                Object.assign({ key: 'hen', name: 'Dona Clara', img: 'assets/animal_hen.png', scale: 0.95 }, HEN),
                Object.assign({ key: 'hen', name: 'Maria Chiquinha', img: 'assets/animal_hen.png', scale: 0.88 }, HEN)
            ],
            ref: () => 4
        }
    };

    function boxesOf(species, kind) {
        return species === 'cow' ? BOXES.cow[kind.key] : BOXES[species];
    }

    class BarnAnimals {
        constructor() {
            this.animals = [];
            this.images = {};
            this.last = 0;
            this.ready = false;
            Object.keys(SPECIES).forEach(sp => SPECIES[sp].kinds.forEach(k => {
                if (!this.images[k.img]) {
                    const img = new Image();
                    img.src = k.img;
                    this.images[k.img] = img;
                }
            }));
        }

        pen(sp) {
            const W = window.BARN_WORLD;
            return W && W.pens ? W.pens[sp] : null;
        }

        spawn() {
            this.animals = [];
            Object.keys(SPECIES).forEach(sp => {
                const b = this.pen(sp);
                if (!b) return;
                SPECIES[sp].kinds.forEach(kind => {
                    let x, y, tries = 0;
                    do {
                        x = b.minX + Math.random() * (b.maxX - b.minX);
                        y = b.minY + Math.random() * (b.maxY - b.minY);
                        tries++;
                    } while (tries < 30 && this.animals.some(o => Math.hypot(o.x - x, (o.y - y) * 1.6) < SPECIES[sp].half * 2.6));
                    this.animals.push({
                        sp, kind, name: kind.name, x, y,
                        dir: ['down', 'left', 'right', 'up'][Math.floor(Math.random() * 4)],
                        mode: 'idle', t: 0.4 + Math.random() * 2, step: 0, stepT: 0,
                        phase: Math.random() * 6, happyT: 0
                    });
                });
            });
            this.ready = true;
        }

        body(a) {
            const h = SPECIES[a.sp].half;
            return { left: a.x - h, right: a.x + h, top: a.y - 8, bottom: a.y + 3 };
        }
        overlap(a, b) { return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top; }
        grow(r, m) { return { left: r.left - m, right: r.right + m, top: r.top - m, bottom: r.bottom + m }; }

        // Animal ao alcance do ponto "à frente do jogador" (para acariciar por cima da cerca)
        findNear(fx, fy) {
            let best = null, bd = 1e9;
            this.animals.forEach(a => {
                const dx = fx - a.x, dy = fy - (a.y - 14);
                if (Math.abs(dx) <= 58 && Math.abs(dy) <= 50) {
                    const d = dx * dx + dy * dy;
                    if (d < bd) { bd = d; best = a; }
                }
            });
            return best;
        }

        pet(a) { a.mode = 'happy'; a.t = 2.6; a.happyT = 2.6; }

        chooseMode(a) {
            const b = this.pen(a.sp);
            const r = Math.random();
            if (r < 0.58) {
                a.mode = 'walk';
                a.t = 1.2 + Math.random() * 2.4;
                const opts = [];
                if (a.x > b.minX + 14) opts.push('left');
                if (a.x < b.maxX - 14) opts.push('right');
                if (a.y > b.minY + 10) opts.push('up');
                if (a.y < b.maxY - 10) opts.push('down');
                a.dir = opts[Math.floor(Math.random() * opts.length)] || 'down';
            } else if (r < 0.80) {
                a.mode = 'idle'; a.t = 1 + Math.random() * 2;
            } else if (r < 0.92) {
                a.mode = 'sit'; a.t = 3 + Math.random() * 3;
            } else {
                a.mode = 'sleep'; a.t = 4 + Math.random() * 4;
            }
        }

        update(now) {
            if (!this.ready) { if (window.BARN_WORLD && window.BARN_WORLD.pens) this.spawn(); else return; }
            let dt = this.last ? (now - this.last) / 1000 : 0;
            this.last = now;
            dt = Math.min(Math.max(dt, 0), 0.05);

            this.animals.forEach(a => {
                const S = SPECIES[a.sp], b = this.pen(a.sp);
                a.phase += dt;
                a.t -= dt;
                if (a.mode === 'happy') {
                    a.happyT -= dt;
                    if (a.happyT <= 0) { a.mode = 'idle'; a.t = 1; }
                    return;
                }
                if (a.mode === 'walk') {
                    const dx = a.dir === 'left' ? -1 : a.dir === 'right' ? 1 : 0;
                    const dy = a.dir === 'up' ? -1 : a.dir === 'down' ? 1 : 0;
                    const nx = a.x + dx * S.speed * dt, ny = a.y + dy * S.speed * dt;
                    let blocked = nx < b.minX || nx > b.maxX || ny < b.minY || ny > b.maxY;
                    if (!blocked) {
                        const h = S.half;
                        const nb = { left: nx - h, right: nx + h, top: ny - 8, bottom: ny + 3 };
                        blocked = this.animals.some(o => o !== a && this.overlap(nb, this.grow(this.body(o), 3)));
                    }
                    if (blocked) {
                        a.mode = 'idle'; a.t = 0.3 + Math.random() * 0.7;
                    } else {
                        a.x = nx; a.y = ny;
                        a.stepT += dt;
                        if (a.stepT >= S.stepTime) { a.stepT = 0; a.step++; }
                    }
                }
                if (a.t <= 0) this.chooseMode(a);
            });
        }

        // Desenha todos, ordenados por Y (profundidade)
        draw(ctx) {
            this.animals.slice().sort((p, q) => p.y - q.y).forEach(a => this.drawOne(ctx, a));
        }

        drawOne(ctx, a) {
            const S = SPECIES[a.sp], def = a.kind, img = this.images[def.img];
            if (!img || !img.complete || !img.naturalWidth) return;
            const boxes = boxesOf(a.sp, def);
            const K = (S.targetH / boxes[S.ref(def)][3]) * (def.scale || 1);

            let idx, flip = false, bob = 0, sy = 1;
            const walking = a.mode === 'walk';
            if (a.mode === 'sit') idx = def.sit;
            else if (a.mode === 'sleep') idx = def.sleep;
            else if (a.mode === 'happy') { idx = def.happy; flip = a.dir === 'right'; }
            else if (a.dir === 'down' || a.dir === 'up') {
                const list = a.dir === 'down' ? def.down : def.up;
                idx = walking ? list[a.step % list.length] : list[0];
                flip = S.flipStep && walking && (a.step % 2 === 1);
            } else {
                idx = walking ? def.side[a.step % def.side.length] : def.side[0];
                flip = a.dir === 'left';
            }
            if (walking) bob = -Math.abs(Math.sin((a.step + a.stepT / S.stepTime) * Math.PI)) * (a.sp === 'hen' ? 1.2 : 1.8);
            else sy = 1 + Math.sin(a.phase * 2.2) * 0.012; // respiração

            const f = boxes[idx];
            const dw = f[2] * K, dh = f[3] * K * sy;
            const x = Math.round(a.x), y = Math.round(a.y);

            // sombra
            ctx.fillStyle = 'rgba(0,0,0,0.24)';
            ctx.beginPath(); ctx.ellipse(x, y + 1, Math.max(S.shadow, dw * 0.38), a.sp === 'hen' ? 3 : 5, 0, 0, Math.PI * 2); ctx.fill();

            ctx.save();
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            ctx.translate(x, y + bob);
            if (flip) ctx.scale(-1, 1);
            ctx.drawImage(img, f[0], f[1], f[2], f[3], -dw / 2, -dh, dw, dh);
            ctx.restore();

            // "z z z" subindo quando a vaca roxa dorme (o sprite dela não traz zzz)
            if (a.mode === 'sleep' && def.key === 'purple') {
                ctx.fillStyle = '#93c5fd';
                ctx.font = 'bold 10px sans-serif';
                ctx.textAlign = 'center';
                for (let i = 0; i < 3; i++) {
                    const p = (a.phase * 0.7 + i / 3) % 1;
                    ctx.globalAlpha = 1 - p;
                    ctx.fillText('z', x + 14 + p * 8 + i * 3, y - dh - 2 - p * 14);
                }
                ctx.globalAlpha = 1;
            }
        }
    }

    window.BarnAnimals = BarnAnimals;
    window.barnAnimals = new BarnAnimals();
})();
