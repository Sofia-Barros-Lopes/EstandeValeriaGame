/**
 * VALE DO CREPÚSCULO - BASE DE DADOS DO JOGO
 * Personagens Oficiais (Luis, Sofia e Rebeca), Culturas, Catálogo de Móveis e Diálogos
 */

// Personagens Oficiais (Luis, Sofia e Rebeca)
const CHARACTERS = {
    luis: {
        id: 'luis',
        name: 'Luis',
        title: 'Fazendeiro Clássico',
        desc: 'Dedicação e amor à terra. Veste camisa xadrez azul/branca, macacão jeans com barra dobrada e chapéu de palha com fita marrom.',
        avatar: 'assets/luis_avatar.png',
        sprites: {
            down: 'assets/luis_down.png',
            up: 'assets/luis_up.png',
            left: 'assets/luis_left.png',
            right: 'assets/luis_right.png'
        },
        colors: {
            skin: '#fed7aa',
            hair: '#543310',
            shirt: '#3b82f6',
            overalls: '#1d4ed8',
            hat: '#ca8a04'
        }
    },
    sofia: {
        id: 'sofia',
        name: 'Sofia',
        title: 'Guardiã Botânica',
        desc: 'Alegre e apaixonada por flores e hortaliças. Destaca-se por seus cabelos castanhos ondulados, suéter listrado rosa e macacão jeans.',
        avatar: 'assets/sofia_avatar.png',
        sprites: {
            down: 'assets/sofia_down.png',
            up: 'assets/sofia_up.png',
            left: 'assets/sofia_left.png',
            right: 'assets/sofia_right.png'
        },
        colors: {
            skin: '#ffedd5',
            hair: '#78350f',
            shirt: '#f472b6',
            overalls: '#2563eb',
            hat: '#d97706'
        }
    },
    rebeca: {
        id: 'rebeca',
        name: 'Rebeca',
        title: 'Mestra da Terra',
        desc: 'Energética e determinada. Destaca-se por seus volumosos cachos escuros, camisa quadriculada bege e macacão jeans.',
        avatar: 'assets/rebeca_avatar.png',
        sprites: {
            down: 'assets/rebeca_down.png',
            up: 'assets/rebeca_up.png',
            left: 'assets/rebeca_left.png',
            right: 'assets/rebeca_right.png'
        },
        colors: {
            skin: '#8d5b4c',
            hair: '#271b16',
            shirt: '#fef3c7',
            overalls: '#1e40af',
            hat: '#b45309'
        }
    }
};

// Compatibilidade com saves antigos ou referências por 'sofi'
CHARACTERS.sofi = CHARACTERS.sofia;

// Diálogos e Interações dos Personagens no Mundo do Jogo
const NPC_DIALOGUES = {
    luis: {
        id: 'luis',
        name: 'Luis',
        title: 'Fazendeiro Clássico',
        avatar: 'assets/luis_avatar.png',
        quotes: [
            "Olá! Que dia maravilhoso para cuidar da terra no Vale do Crepúsculo!",
            "Lembre-se: regar a terra todos os dias faz os brotos crescerem fortes e saudáveis!",
            "Milho e abóboras demoram mais para amadurecer, mas o lucro no baú de vendas é incrível!",
            "Se precisar de mais sementes ou novos móveis, dê um pulinho no Mercado do vilarejo!"
        ]
    },
    sofia: {
        id: 'sofia',
        name: 'Sofia',
        title: 'Guardiã Botânica',
        avatar: 'assets/sofia_avatar.png',
        quotes: [
            "Oi! Olha como a fazenda fica mais acolhedora com flores e morangos coloridos!",
            "Adoro a brisa fresca da manhã... Dá uma paz incrível ver nossas plantações crescendo!",
            "Sabia que em dias de chuva a água do céu rega todos os canteiros de graça?",
            "Depois de um dia puxado na lida, nada melhor do que descansar na cama do nosso quarto!"
        ]
    },
    rebeca: {
        id: 'rebeca',
        name: 'Rebeca',
        title: 'Mestra da Terra',
        avatar: 'assets/rebeca_avatar.png',
        quotes: [
            "E aí! Já preparou a enxada? Hoje é dia de bater o recorde da nossa colheita!",
            "Se colher tudo que estiver maduro, corra até o baú de vendas para encher nossos bolsos de ouro!",
            "Eu amo essa terra! O solo do Vale do Crepúsculo é fértil demais, tudo que plantamos vinga!",
            "Com o dinheiro das safras podemos comprar móveis lindos e deixar nossa casa super estilosa!"
        ]
    },
    pierre: {
        id: 'pierre',
        name: 'Pierre',
        title: 'Comerciante da Feira',
        avatar: 'assets/luis_avatar.png',
        quotes: [
            "Bem-vindo à minha barraca na Feira da Cidade! Trouxe sementes fresquinhas de altíssima qualidade!",
            "Plantar na época certa é o grande segredo para encher os bolsos de ouro!",
            "As sementes de morango e abóbora são as mais lucrativas de todo o Vale do Crepúsculo!",
            "Compre todas as sementes que precisar aqui na feira e volte sempre para abastecer sua fazenda!"
        ]
    }
};
NPC_DIALOGUES.sofi = NPC_DIALOGUES.sofia;

// Configuração de Posições dos NPCs no Mapa (quando não estão sendo controlados pelo jogador)
const NPC_SPAWNS = {
    farm: {
        luis: { x: 7 * 32, y: 6 * 32, dir: 'down', animOffset: 0.1 },
        sofia: { x: 18 * 32, y: 8 * 32, dir: 'left', animOffset: 1.2 },
        rebeca: { x: 7 * 32, y: 9 * 32, dir: 'right', animOffset: 2.4 }
    },
    house: {
        luis: { x: 10 * 32, y: 3 * 32, dir: 'down', animOffset: 0.5 },
        sofia: { x: 5 * 32, y: 4 * 32, dir: 'down', animOffset: 1.8 },
        rebeca: { x: 4 * 32, y: 7 * 32, dir: 'right', animOffset: 3.1 }
    }
};

// Culturas Agrícolas
const CROPS_DATA = {
    carrot: {
        id: 'carrot',
        name: 'Cenoura',
        seedName: 'Sem. Cenoura',
        icon: '🥕',
        seedCost: 8,
        sellPrice: 20,
        daysToGrow: 2,
        color: '#f97316'
    },
    strawberry: {
        id: 'strawberry',
        name: 'Morango',
        seedName: 'Sem. Morango',
        icon: '🍓',
        seedCost: 18,
        sellPrice: 46,
        daysToGrow: 3,
        color: '#f43f5e'
    },
    corn: {
        id: 'corn',
        name: 'Milho',
        seedName: 'Sem. Milho',
        icon: '🌽',
        seedCost: 32,
        sellPrice: 85,
        daysToGrow: 4,
        color: '#eab308'
    },
    pumpkin: {
        id: 'pumpkin',
        name: 'Abóbora',
        seedName: 'Sem. Abóbora',
        icon: '🎃',
        seedCost: 60,
        sellPrice: 165,
        daysToGrow: 5,
        color: '#ea580c'
    }
};

// Catálogo de Móveis para Decoração da Casa
const FURNITURE_CATALOG = {
    bed_royal: {
        id: 'bed_royal',
        name: 'Cama Imperial Roxa',
        category: 'cama',
        width: 2,
        height: 2,
        cost: 120,
        solid: true,
        isBed: true,
        colorMain: '#581c87',
        colorAccent: '#a855f7',
        colorPillow: '#f1f5f9',
        desc: 'Cama luxuosa com edredom violeta. Permite dormir e avançar o dia.'
    },
    sofa_indigo: {
        id: 'sofa_indigo',
        name: 'Sofá Aveludado Anil',
        category: 'assento',
        width: 2,
        height: 1,
        cost: 85,
        solid: true,
        colorMain: '#1e1b4b',
        colorAccent: '#3b82f6',
        desc: 'Sofá macio e elegante para descanso.'
    },
    table_wood: {
        id: 'table_wood',
        name: 'Mesa de Carvalho & Toalha Violeta',
        category: 'mesas',
        width: 2,
        height: 1,
        cost: 65,
        solid: true,
        colorMain: '#78350f',
        colorAccent: '#9333ea',
        desc: 'Mesa rústica decorada com caminho de mesa roxo.'
    },
    rug_purple: {
        id: 'rug_purple',
        name: 'Tapete Estelar Roxo',
        category: 'tapete',
        width: 3,
        height: 2,
        cost: 45,
        solid: false,
        colorMain: '#3b0764',
        colorAccent: '#c084fc',
        desc: 'Tapete bordado com motivos astrais acolhedores.'
    },
    rug_blue: {
        id: 'rug_blue',
        name: 'Tapete Nobre Anil',
        category: 'tapete',
        width: 2,
        height: 2,
        cost: 40,
        solid: false,
        colorMain: '#172554',
        colorAccent: '#60a5fa',
        desc: 'Tapete azul suave com detalhes dourados.'
    },
    plant_pot: {
        id: 'plant_pot',
        name: 'Samambaia em Vaso Violeta',
        category: 'planta',
        width: 1,
        height: 1,
        cost: 30,
        solid: true,
        colorMain: '#7c3aed',
        colorAccent: '#22c55e',
        desc: 'Planta de interior que purifica o ar da casa.'
    },
    bookshelf: {
        id: 'bookshelf',
        name: 'Estante de Grimórios',
        category: 'estante',
        width: 2,
        height: 1,
        cost: 95,
        solid: true,
        colorMain: '#451a03',
        colorAccent: '#818cf8',
        desc: 'Repleta de histórias, guias de botânica e magia.'
    },
    lamp_cozy: {
        id: 'lamp_cozy',
        name: 'Abajur Cristal Ametista',
        category: 'luz',
        width: 1,
        height: 1,
        cost: 50,
        solid: true,
        colorMain: '#c084fc',
        colorAccent: '#fef08a',
        desc: 'Luminária suave que emana um brilho caloroso.'
    }
};

const MAP_CONFIG = {
    tileSize: 32,
    farm: {
        cols: 28,
        rows: 16,
        // Mundo da fazenda (px) - tamanho da imagem do cenário; a câmera acompanha o jogador
        worldW: 1863,
        worldH: 844,
        house: { x: 15, y: 7 },
        spawn: { x: 17, y: 12 },
        houseDoor: { x: 17, y: 11 },
        shippingBin: { x: 20, y: 11 },
        townSign: { x: 50, y: 15 },
        soilBounds: { startX: 19, startY: 14, endX: 28, endY: 19 }
    },
    house: {
        cols: 16,
        rows: 12,
        offsetX: 4,
        offsetY: 2,
        spawn: { x: 8, y: 9 },
        exitDoor: { x: 8, y: 10 },
        roomBounds: { startX: 1, startY: 3, endX: 14, endY: 9 }
    }
};


// ==========================================================
// CENÁRIO 3: CELEIRO (acima da fazenda) - layout compartilhado entre desenho, colisão e interações
// Todas as posições em tiles (32px), centralizadas na largura do mapa (cols)
// ==========================================================
function getBarnLayout(cols, rows) {
    const ts = 32;
    const cx = Math.floor(cols / 2);
    const box = (tx, ty, tw, th, pad = {}) => ({
        left: tx * ts + (pad.l || 0),
        right: (tx + tw) * ts - (pad.r || 0),
        top: ty * ts + (pad.t || 0),
        bottom: (ty + th) * ts - (pad.b || 0)
    });

    const barn = { x: cx - 4, y: 1, w: 8, h: 5 };
    const silo = { x: cx - 7, y: 1, w: 2, h: 5 };
    const hay = [{ x: cx + 5, y: 4 }, { x: cx + 6, y: 4 }, { x: cx + 5, y: 5 }];
    const trough = { x: cx - 5, y: 7, w: 2, h: 1 };
    const barrels = [{ x: cx - 8, y: 6 }, { x: cx - 8, y: 7 }];
    const cans = [{ x: cx + 3, y: 6 }, { x: cx + 4, y: 6 }];
    const sign = { x: cx + 2, y: 7 };
    const pen = { x1: cx + 3, y1: 8, x2: cx + 11, y2: 12 };
    const cow = { x: pen.x1 + 3, y: pen.y1 + 2 };
    const chickens = [
        { x: pen.x1 + 1.6, y: pen.y1 + 1.6, off: 0 },
        { x: pen.x1 + 4.4, y: pen.y1 + 3.0, off: 1.7 },
        { x: pen.x1 + 2.0, y: pen.y1 + 3.2, off: 3.1 }
    ];

    const colliders = [
        box(barn.x, barn.y, barn.w, barn.h, { l: 6, r: 6, t: 44, b: 6 }),
        box(silo.x, silo.y, silo.w, silo.h, { l: 4, r: 4, t: 36, b: 6 }),
        ...hay.map(h => box(h.x, h.y, 1, 1, { l: 2, r: 2, t: 10, b: 4 })),
        box(trough.x, trough.y, trough.w, trough.h, { l: 2, r: 2, t: 10, b: 4 }),
        ...barrels.map(b => box(b.x, b.y, 1, 1, { l: 4, r: 4, t: 8, b: 4 })),
        ...cans.map(c => box(c.x, c.y, 1, 1, { l: 8, r: 8, t: 10, b: 4 })),
        box(sign.x, sign.y, 1, 1, { l: 10, r: 10, t: 14, b: 4 }),
        // Cercado: cima, baixo, direita e esquerda (com portão aberto no meio)
        box(pen.x1, pen.y1, pen.x2 - pen.x1 + 1, 1, { t: 10, b: 8 }),
        box(pen.x1, pen.y2, pen.x2 - pen.x1 + 1, 1, { t: 10, b: 8 }),
        box(pen.x2, pen.y1, 1, pen.y2 - pen.y1 + 1, { l: 10, r: 10 }),
        box(pen.x1, pen.y1, 1, 1, { l: 10, r: 10, t: 10 }),
        box(pen.x1, pen.y2 - 1, 1, 1, { l: 10, r: 10, b: 0 })
    ];

    const rect = (tx, ty, tw, th) => ({ left: tx * ts, right: (tx + tw) * ts, top: ty * ts, bottom: (ty + th) * ts });
    const interactives = [
        { ...rect(barn.x + 3, 4, 2, 2), prompt: '[E] Bater na Porta', msg: '🚪 O celeiro está trancado por enquanto...' },
        { ...rect(sign.x, sign.y, 1, 1), prompt: '[E] Ler a Placa', msg: '📜 Celeiro do Vale do Crepúsculo — em breve: animais e ração!' },
        ...hay.map(h => ({ ...rect(h.x, h.y, 1, 1), prompt: '[E] Pegar Feno', msg: '🌾 Feno fresquinho e cheiroso!' })),
        { ...rect(trough.x, trough.y, trough.w, trough.h), prompt: '[E] Ver Bebedouro', msg: '💧 O bebedouro está cheio de água fresca.' },
        ...cans.map(c => ({ ...rect(c.x, c.y, 1, 1), prompt: '[E] Latão de Leite', msg: '🥛 Leite fresco esperando para ser vendido.' })),
        ...barrels.map(b => ({ ...rect(b.x, b.y, 1, 1), prompt: '[E] Barril', msg: '🛢️ Um barril de carvalho bem lacrado.' }))
    ];

    return {
        cx, barn, silo, hay, trough, barrels, cans, sign, pen, cow, chickens, colliders, interactives,
        npcSpawns: {
            luis: { x: (cx - 2) * ts, y: 8 * ts, dir: 'up', animOffset: 0.4 },
            sofia: { x: (cx + 1) * ts, y: 10 * ts, dir: 'left', animOffset: 1.5 },
            rebeca: { x: (cx - 5) * ts, y: 10 * ts, dir: 'right', animOffset: 2.6 }
        }
    };
}
window.getBarnLayout = getBarnLayout;


// ==========================================================
// CASA DOS AMIGOS (segunda casa na fazenda): onde os personagens NÃO selecionados ficam
// ==========================================================
function getFriendHouse(cols) {
    const x = 35; // largura da casa = 5 tiles (posição fixa no mundo da fazenda)
    return { x: x, y: 7, doorX: x + 2, doorY: 11 };
}
window.getFriendHouse = getFriendHouse;

// Móveis fixos do interior da Casa dos Amigos (coordenadas locais do interior, em tiles)
const FRIEND_HOUSE_FURNITURE = [
    { id: 101, type: 'rug_purple', x: 5, y: 4 },
    { id: 102, type: 'rug_blue', x: 11, y: 5 },
    { id: 103, type: 'bed_royal', x: 2, y: 3 },
    { id: 104, type: 'bed_royal', x: 12, y: 3 },
    { id: 105, type: 'bookshelf', x: 6, y: 3 },
    { id: 106, type: 'lamp_cozy', x: 9, y: 3 },
    { id: 107, type: 'plant_pot', x: 1, y: 8 },
    { id: 108, type: 'table_wood', x: 6, y: 5 },
    { id: 109, type: 'sofa_indigo', x: 11, y: 7 }
];
window.FRIEND_HOUSE_FURNITURE = FRIEND_HOUSE_FURNITURE;

NPC_SPAWNS.house2 = {
    luis: { x: 9 * 32, y: 4 * 32, dir: 'down', animOffset: 0.5 },
    sofia: { x: 4 * 32, y: 6 * 32, dir: 'right', animOffset: 1.8 },
    rebeca: { x: 12 * 32, y: 5 * 32, dir: 'left', animOffset: 3.1 }
};

window.CHARACTERS = CHARACTERS;
window.NPC_DIALOGUES = NPC_DIALOGUES;
window.NPC_SPAWNS = NPC_SPAWNS;
window.CROPS_DATA = CROPS_DATA;
window.FURNITURE_CATALOG = FURNITURE_CATALOG;
window.MAP_CONFIG = MAP_CONFIG;

// Menor linha (y) em que um móvel pode ficar sem que o desenho invada a parede.
// O chão da casa começa na linha roomBounds.startY; sprites mais altos que a área
// ocupada "sobram" para cima, então precisam ficar mais para baixo.
function getFurnitureMinY(type) {
    const def = FURNITURE_CATALOG[type];
    const base = MAP_CONFIG.house.roomBounds.startY;
    if (!def || !def.sprite || def.category === 'parede' || def.category === 'tapete') return base;
    const spriteH = (def.dw || def.width) * (def.ratio || 0);
    const extra = Math.max(0, Math.ceil(spriteH - def.height - 0.3));
    return base + extra;
}
window.getFurnitureMinY = getFurnitureMinY;
