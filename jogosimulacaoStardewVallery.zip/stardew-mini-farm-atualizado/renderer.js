/**
 * VALE DO CREPÚSCULO - RENDERIZADOR CANVAS 2D
 * Renderiza o mapa, móveis, culturas e os sprites dos personagens anexados
 */

class GameRenderer {
    constructor(canvas, ctx) {
        this.canvas = canvas;
        this.ctx = ctx;
        this.tileSize = MAP_CONFIG.tileSize; // 32px
        this.animTimer = 0;
        this.smokePuffs = [
            { x: 0, y: 0, size: 4, life: 0 },
            { x: 0, y: -8, size: 6, life: 30 },
            { x: 2, y: -16, size: 8, life: 60 }
        ];

        // Pré-carregamento dos sprites dos personagens das ilustrações
        this.spriteImages = {};
        this.loadCharacterSprites();

        // Pré-carregamento dos novos sprites das árvores da ilustração oficial
        this.treeImages = {};
        this.loadTreeSprites();

        // Imagem de cenário da fazenda
        this.farmBg = new Image();
        this.farmBg.src = 'assets/farm_bg.jpg';

        // Mundo grande da fazenda (câmera segue o jogador)
        this.farmWorldBg = new Image();
        this.farmWorldBg.src = window.FARM_WORLD ? window.FARM_WORLD.bg : 'assets/farm_world.jpg';
        this.cam = { x: 0, y: 0 };
        this._camScene = null;

        // Mundo do Centro da Cidade (hospital, igreja, mercado...), ao lado direito da vila
        this.barnWorldBg = new Image();
        this.barnWorldBg.src = window.BARN_WORLD ? window.BARN_WORLD.bg : 'assets/barn_world.jpg';
        this.cityWorldBg = new Image();
        this.cityWorldBg.src = window.CITY_WORLD ? window.CITY_WORLD.bg : 'assets/city_world.png';

        // Nova casa (exterior) e interior em pixel art estilo Stardew Valley
        this.houseExterior = new Image();
        this.houseExterior.src = 'assets/house_exterior.png';
        this.houseInterior = new Image();
        this.houseInterior.src = 'assets/house_interior.png';
        this.barnImg = new Image();
        this.barnImg.src = 'assets/barn.png';

        // Pixel art da plantação: tiles de terra (autotile) e plantas por estágio
        this.soilAtlas = new Image();
        this.soilAtlas.src = 'assets/soil_tiles.png';
        this.cropAtlas = new Image();
        this.cropAtlas.src = 'assets/crops_sheet.png';
    }

    loadTreeSprites() {
        this.treeImages = {
            oak: new Image(),
            fruit: new Image(),
            blossom: new Image(),
            autumn: new Image()
        };
        this.treeImages.oak.src = 'assets/tree_oak.png';
        this.treeImages.fruit.src = 'assets/tree_fruit.png';
        this.treeImages.blossom.src = 'assets/tree_blossom.png';
        this.treeImages.autumn.src = 'assets/tree_autumn.png';
    }

    loadCharacterSprites() {
        ['luis', 'sofia', 'rebeca'].forEach(charKey => {
            this.spriteImages[charKey] = {};
            const def = CHARACTERS[charKey];
            if (!def) return;
            ['down', 'up', 'left', 'right'].forEach(dir => {
                const img = new Image();
                img.src = def.sprites[dir];
                this.spriteImages[charKey][dir] = img;
            });
        });
        // Alias para compatibilidade
        this.spriteImages['sofi'] = this.spriteImages['sofia'];
        // Moradores da cidade
        (window.TOWN_NPCS || []).forEach(n => {
            this.spriteImages[n.id] = {};
            ['down', 'up', 'left', 'right'].forEach(dir => {
                const img = new Image();
                img.src = n.sprites[dir];
                this.spriteImages[n.id][dir] = img;
            });
        });
    }

    updateAnimations() {
        this.animTimer += 0.05;

        // Fumaça da chaminé
        this.smokePuffs.forEach(p => {
            p.life = (p.life + 1) % 90;
            p.y = - (p.life * 0.35);
            p.x = Math.sin(p.life * 0.08) * 4;
            p.size = 3 + (p.life * 0.1);
        });
    }

    render(gameState) {
        this.updateAnimations();
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Câmera: na fazenda o mundo é maior que a tela e a vista acompanha o jogador
        const inWorld = ['farm', 'city', 'barn', 'barnin'].includes(gameState.currentScene);
        if (inWorld) {
            this.updateCamera(gameState.player, gameState.currentScene);
            this.ctx.save();
            this.ctx.translate(-Math.round(this.cam.x), -Math.round(this.cam.y));
        } else {
            this.cam.x = 0;
            this.cam.y = 0;
            this._camScene = gameState.currentScene;
        }

        if (gameState.currentScene === 'farm') {
            this.renderFarmScene(gameState);
        } else if (gameState.currentScene === 'house') {
            this.renderHouseScene(gameState);
        } else if (gameState.currentScene === 'barn') {
            this.renderBarnScene(gameState);
        } else if (gameState.currentScene === 'barnin') {
            this.renderBarnInsideScene(gameState);
        } else if (gameState.currentScene === 'house2') {
            this.renderHouseScene(gameState, 'friends');
        } else if (gameState.currentScene === 'city') {
            this.renderCityScene(gameState);
        }

        // Renderiza entidades (Jogador, NPCs e Árvores) com ordenação Y para profundidade 2.5D perfeita
        const activeNPCs = (gameState.npcs || []).filter(npc => npc.scene === gameState.currentScene);
        const entities = [
            { type: 'player', y: gameState.player.y + 24, data: gameState.player },
            ...activeNPCs.map(npc => ({ type: 'npc', y: npc.y + 24, data: npc }))
        ];

        // Na fazenda, inclui as árvores na ordenação Y para que o jogador possa caminhar na frente e atrás delas
        if (gameState.currentScene === 'farm') {
            const trees = gameState.trees || this.getFarmTrees();
            trees.forEach(tree => {
                entities.push({ type: 'tree', y: tree.y + 28, data: tree });
            });
        }

        entities.sort((a, b) => a.y - b.y);

        entities.forEach(entity => {
            if (entity.type === 'player') {
                this.renderPlayer(entity.data, gameState.currentScene);
            } else if (entity.type === 'npc') {
                this.renderNPC(entity.data, gameState.currentScene);
            } else if (entity.type === 'tree') {
                this.renderTree(entity.data.x, entity.data.y, entity.data.type, gameState);
            }
        });

        // Renderiza balão contextual de ação (oculto durante a seleção ativa de solo)
        if (gameState.interactionPrompt && !gameState.decorMode && (!gameState.soilSelection || !gameState.soilSelection.active)) {
            this.renderInteractionPrompt(gameState.interactionPrompt, gameState.player);
        }

        // Overlay de Seleção e Marcações de Alcance de Solo (Stardew Valley)
        if (gameState.currentScene === 'farm') {
            this.renderSoilSelectionOverlay(gameState);
        }

        // Modo Decoração na Casa
        if (gameState.currentScene === 'house' && gameState.decorMode) {
            this.renderDecorOverlay(gameState);
        }

        if (inWorld) this.ctx.restore();

        // Escurecer do fim do dia (apenas ao ar livre): entardecer a partir das 17h, noite plena perto das 24h
        if (inWorld && gameState.currentScene !== 'barnin') this.renderDayNight(gameState.time);
    }

    renderDayNight(t) {
        if (typeof t !== 'number') return;
        const clamp = (v) => Math.max(0, Math.min(1, v));
        const dusk = clamp((t - 1020) / 240);          // 17:00 -> 21:00 laranja suave
        const night = clamp((t - 1140) / 360);         // 19:00 -> 01:00 azul escuro
        if (dusk <= 0 && night <= 0) return;
        const ctx = this.ctx, w = this.canvas.width, h = this.canvas.height;
        ctx.save();
        if (dusk > 0) {
            ctx.fillStyle = `rgba(255, 130, 50, ${0.16 * dusk * (1 - night * 0.6)})`;
            ctx.fillRect(0, 0, w, h);
        }
        if (night > 0) {
            ctx.fillStyle = `rgba(8, 12, 48, ${0.62 * night})`;
            ctx.fillRect(0, 0, w, h);
        }
        ctx.restore();
    }

    // Posiciona a câmera centralizada no jogador, sem sair das bordas do mundo (fazenda ou feira)
    updateCamera(player, scene) {
        scene = scene || 'farm';
        const cw = this.canvas.width, ch = this.canvas.height;
        const WORLD = scene === 'city' ? window.CITY_WORLD : scene === 'barn' ? window.BARN_WORLD : scene === 'barnin' ? window.BARN_INSIDE : null;
        const worldW = WORLD ? WORLD.w : MAP_CONFIG.farm.worldW;
        const worldH = WORLD ? WORLD.h : MAP_CONFIG.farm.worldH;
        const clampAxis = (target, view, world) => {
            if (world <= view) return -(view - world) / 2; // mundo menor que a tela: centraliza
            return Math.max(0, Math.min(world - view, target));
        };
        const tx = clampAxis(player.x + 16 - cw / 2, cw, worldW);
        const ty = clampAxis(player.y + 16 - ch / 2, ch, worldH);
        if (this._camScene !== scene) {
            this.cam.x = tx; this.cam.y = ty; // ao entrar no mapa, posiciona direto
            this._camScene = scene;
        } else {
            this.cam.x += (tx - this.cam.x) * 0.2;
            this.cam.y += (ty - this.cam.y) * 0.2;
            if (Math.abs(tx - this.cam.x) < 0.3) this.cam.x = tx;
            if (Math.abs(ty - this.cam.y) < 0.3) this.cam.y = ty;
        }
    }

    // ==========================================================
    // RENDERIZAÇÃO DO PERSONAGEM DO JOGADOR
    // ==========================================================
    renderPlayer(player, scene) {
        const ts = this.tileSize;
        let px = player.x;
        let py = player.y;

        if (scene === 'house' || scene === 'house2') {
            px += MAP_CONFIG.house.offsetX * ts;
            py += MAP_CONFIG.house.offsetY * ts;
        }

        const charKey = player.characterId || 'luis';
        const charDef = CHARACTERS[charKey] || CHARACTERS.luis;
        const dir = player.dir || 'down';

        const bob = player.isMoving ? Math.sin(this.animTimer * 14) * 2 : 0;

        // Sombra suave sob os pés
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.38)';
        this.ctx.beginPath();
        this.ctx.ellipse(px + 16, py + 29, 11, 4.5, 0, 0, Math.PI * 2);
        this.ctx.fill();

        // Renderiza o Sprite PNG recortado transparente
        const charSprites = this.spriteImages[charKey] || this.spriteImages[charDef.id];
        const img = charSprites ? charSprites[dir] : null;

        if (img && img.complete && img.naturalWidth > 0) {
            const spriteH = 48;
            const spriteW = Math.round(spriteH * (img.naturalWidth / img.naturalHeight));
            const drawX = Math.round(px + 16 - spriteW / 2);
            const drawY = Math.round(py + 30 - spriteH + bob);

            this.ctx.drawImage(img, drawX, drawY, spriteW, spriteH);
        } else {
            this.renderProceduralFarmer(px, py, bob, player.dir, player.isMoving, charDef);
        }
    }

    // ==========================================================
    // RENDERIZAÇÃO DOS NPCS COMPANHEIROS (LUIS, SOFIA, REBECA)
    // ==========================================================
        renderNPC(npc, scene) {
        const ts = this.tileSize;
        let nx = npc.x;
        let ny = npc.y;

        if (scene === 'house' || scene === 'house2') {
            nx += MAP_CONFIG.house.offsetX * ts;
            ny += MAP_CONFIG.house.offsetY * ts;
        }

        const charKey = npc.characterId || npc.id;
        const charDef = CHARACTERS[charKey] || (npc.town ? { id: charKey, name: npc.name } : CHARACTERS.rebeca);
        const dir = npc.dir || 'down';

        // Animação sutil de respiração idle
        const animOffset = npc.animOffset || 0;
        const bob = Math.sin(this.animTimer * 2.5 + animOffset) * 0.75;

        // Se for a Princesa, desenha proceduralmente (ou tenta carregar o sprite se existir)
        if (npc.id === 'princesa') {
            const petImg = this.spriteImages['princesa'] ? this.spriteImages['princesa'][dir] : null;
            if (petImg && petImg.complete && petImg.naturalWidth > 0) {
                const spriteH = 24; // Pets são menores
                const spriteW = Math.round(spriteH * (petImg.naturalWidth / petImg.naturalHeight));
                const drawX = Math.round(nx + 16 - spriteW / 2);
                const drawY = Math.round(ny + 30 - spriteH + bob);
                this.ctx.drawImage(petImg, drawX, drawY, spriteW, spriteH);
            } else {
                // Desenho procedural da gatinha
                this.ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
                this.ctx.beginPath();
                this.ctx.ellipse(nx + 16, ny + 28, 10, 4, 0, 0, Math.PI * 2);
                this.ctx.fill();

                // Corpo branco
                this.ctx.fillStyle = '#ffffff';
                this.ctx.beginPath();
                this.ctx.ellipse(nx + 16, ny + 20 + bob, 10, 8, 0, 0, Math.PI * 2);
                this.ctx.fill();

                // Manchas pretas
                this.ctx.fillStyle = '#1a1a1a';
                this.ctx.beginPath();
                this.ctx.ellipse(nx + 10, ny + 18 + bob, 3, 4, 0, 0, Math.PI * 2);
                this.ctx.fill();

                // Cabeça
                this.ctx.fillStyle = '#ffffff';
                this.ctx.beginPath();
                this.ctx.arc(nx + 16, ny + 12 + bob, 7, 0, Math.PI * 2);
                this.ctx.fill();

                // Orelhas
                this.ctx.fillStyle = '#1a1a1a';
                this.ctx.beginPath();
                this.ctx.moveTo(nx + 10, ny + 6 + bob);
                this.ctx.lineTo(nx + 12, ny + 1 + bob);
                this.ctx.lineTo(nx + 14, ny + 6 + bob);
                this.ctx.fill();
                this.ctx.beginPath();
                this.ctx.moveTo(nx + 18, ny + 6 + bob);
                this.ctx.lineTo(nx + 20, ny + 1 + bob);
                this.ctx.lineTo(nx + 22, ny + 6 + bob);
                this.ctx.fill();

                // Olhos verdes
                this.ctx.fillStyle = '#65a30d';
                this.ctx.fillRect(nx + 13, ny + 11 + bob, 2, 2);
                this.ctx.fillRect(nx + 17, ny + 11 + bob, 2, 2);

                // Coleira rosa
                this.ctx.strokeStyle = '#f472b6';
                this.ctx.lineWidth = 2;
                this.ctx.beginPath();
                this.ctx.arc(nx + 16, ny + 15 + bob, 7, 0, Math.PI);
                this.ctx.stroke();
            }
            
            // Crachá flutuante
            const badgeY = ny - 12 + bob;
            const badgeText = `🐾 ${npc.name}`;
            this.ctx.font = 'bold 10px Nunito, sans-serif';
            const textMetrics = this.ctx.measureText(badgeText);
            const badgeW = textMetrics.width + 16;

            this.ctx.fillStyle = 'rgba(15, 12, 30, 0.85)';
            this.ctx.beginPath();
            this.ctx.roundRect(nx + 16 - badgeW / 2, badgeY, badgeW, 16, 8);
            this.ctx.fill();
            this.ctx.strokeStyle = '#f472b6';
            this.ctx.lineWidth = 1.2;
            this.ctx.stroke();

            this.ctx.fillStyle = '#ffffff';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(badgeText, nx + 16, badgeY + 11);
            return;
        }

        // Sombra sob os pés (NPCs normais)
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.38)';
        this.ctx.beginPath();
        this.ctx.ellipse(nx + 16, ny + 29, 11, 4.5, 0, 0, Math.PI * 2);
        this.ctx.fill();

        // Renderiza o Sprite PNG recortado
        const charSprites = this.spriteImages[charKey] || this.spriteImages[charDef.id];
        const img = charSprites ? charSprites[dir] : null;

        if (img && img.complete && img.naturalWidth > 0) {
            const spriteH = 48;
            const spriteW = Math.round(spriteH * (img.naturalWidth / img.naturalHeight));
            const drawX = Math.round(nx + 16 - spriteW / 2);
            const drawY = Math.round(ny + 30 - spriteH + bob);

            this.ctx.drawImage(img, drawX, drawY, spriteW, spriteH);
        } else {
            if (!npc.town) this.renderProceduralFarmer(nx, ny, bob, dir, false, charDef);
        }

        // Crachá flutuante acima da cabeça do NPC com nome e ícone de diálogo
        const badgeY = ny - 24 + bob;
        const badgeText = `💬 ${charDef.name}`;
        this.ctx.font = 'bold 10px Nunito, sans-serif';
        const textMetrics = this.ctx.measureText(badgeText);
        const badgeW = textMetrics.width + 16;

        this.ctx.fillStyle = 'rgba(15, 12, 30, 0.85)';
        this.ctx.beginPath();
        this.ctx.roundRect(nx + 16 - badgeW / 2, badgeY, badgeW, 16, 8);
        this.ctx.fill();
        this.ctx.strokeStyle = '#c084fc';
        this.ctx.lineWidth = 1.2;
        this.ctx.stroke();

        this.ctx.fillStyle = '#ffffff';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(badgeText, nx + 16, badgeY + 11);
    }

    renderProceduralFarmer(px, py, bob, dir, isMoving, charDef) {
        const colors = charDef.colors;
        const footSwing = isMoving ? Math.cos(this.animTimer * 14) * 3 : 0;

        // Botas de trabalho marrom
        this.ctx.fillStyle = '#5c3a21';
        this.ctx.fillRect(px + 9 + footSwing, py + 23 + bob, 5, 8);
        this.ctx.fillRect(px + 18 - footSwing, py + 23 + bob, 5, 8);

        // Barra dobrada do macacão jeans
        this.ctx.fillStyle = '#93c5fd';
        this.ctx.fillRect(px + 8 + footSwing, py + 22 + bob, 7, 2);
        this.ctx.fillRect(px + 17 - footSwing, py + 22 + bob, 7, 2);

        // Calça do Macacão Jeans
        this.ctx.fillStyle = colors.overalls;
        this.ctx.fillRect(px + 8, py + 12 + bob, 16, 11);

        // Camisa
        this.ctx.fillStyle = colors.shirt;
        this.ctx.fillRect(px + 6, py + 10 + bob, 20, 5);

        // Cabelo e Cabeça
        this.ctx.fillStyle = colors.hair;
        if (charDef.id === 'sofi' || charDef.id === 'sofia' || charDef.id === 'rebeca') {
            this.ctx.beginPath();
            this.ctx.arc(px + 16, py + 12 + bob, 11, 0, Math.PI * 2);
            this.ctx.fill();
        }

        // Rosto
        this.ctx.fillStyle = colors.skin;
        this.ctx.beginPath();
        this.ctx.arc(px + 16, py + 9 + bob, 7, 0, Math.PI * 2);
        this.ctx.fill();

        // Olhos
        this.ctx.fillStyle = '#1e1b4b';
        if (dir === 'down') {
            this.ctx.fillRect(px + 13, py + 8 + bob, 2, 2);
            this.ctx.fillRect(px + 17, py + 8 + bob, 2, 2);
        } else if (dir === 'left') {
            this.ctx.fillRect(px + 11, py + 8 + bob, 2, 2);
        } else if (dir === 'right') {
            this.ctx.fillRect(px + 19, py + 8 + bob, 2, 2);
        }

        // Chapéu de Palha com aba e fita
        this.ctx.fillStyle = colors.hat;
        this.ctx.beginPath();
        this.ctx.ellipse(px + 16, py + 4 + bob, 13, 5, 0, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.beginPath();
        this.ctx.arc(px + 16, py + 2 + bob, 7, Math.PI, 0);
        this.ctx.fill();

        // Fita do chapéu (marrom ou rosa)
        this.ctx.fillStyle = (charDef.id === 'sofi' || charDef.id === 'sofia') ? '#ec4899' : '#78350f';
        this.ctx.fillRect(px + 10, py + 1 + bob, 12, 2);
    }

    // ==========================================================
    // CENA 1: FAZENDA (EXTERIOR)
    // ==========================================================
    renderFarmScene(state) {
        const ts = this.tileSize;
        const F = MAP_CONFIG.farm;

        // Cenário em tamanho real (1:1) - a câmera mostra apenas a parte visível
        const bg = this.farmWorldBg;
        const hasBg = bg && bg.complete && bg.naturalWidth > 0;
        this.ctx.fillStyle = '#1b3a1f';
        this.ctx.fillRect(-2, -2, F.worldW + 4, F.worldH + 4);
        if (hasBg) {
            this.ctx.imageSmoothingEnabled = true;
            this.ctx.imageSmoothingQuality = 'high';
            this.ctx.drawImage(bg, 0, 0, F.worldW, F.worldH);
        }

        this.renderSoilPlots(state);

        this.renderFarmhouse(F.house.x * ts, F.house.y * ts);
        const fhs = getFriendHouse();
        this.renderFarmhouse(fhs.x * ts, fhs.y * ts, { wall: '#b45309', line: '#92400e', roof: '#0f766e', roofEdge: '#2dd4bf', mat: '#14b8a6' });
        this.renderShippingBin(F.shippingBin.x * ts, F.shippingBin.y * ts);

        // Placa indicativa da estrada para o Centro da Cidade (lado direito)
        this.renderRoadSignToTown(F.townSign.x * ts, F.townSign.y * ts);
        // (As árvores são desenhadas em render(), ordenadas por Y junto com jogador e NPCs)
    }

    renderRoadSignToTown(x, y) {
        const c = this.ctx;
        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.fillRect(x + 10, y + 26, 14, 4);

        // Poste de madeira rústica
        c.fillStyle = '#78350f';
        c.fillRect(x + 14, y + 8, 5, 22);

        // Placa de madeira em formato de seta apontando para a direita
        c.fillStyle = '#b45309';
        c.beginPath();
        c.moveTo(x - 6, y - 4);
        c.lineTo(x + 24, y - 4);
        c.lineTo(x + 36, y + 7);
        c.lineTo(x + 24, y + 18);
        c.lineTo(x - 6, y + 18);
        c.closePath();
        c.fill();

        c.strokeStyle = '#78350f';
        c.lineWidth = 1.5;
        c.stroke();

        // Texto da placa
        c.fillStyle = '#fef08a';
        c.font = 'bold 9px sans-serif';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText('CIDADE ➡️', x + 12, y + 7);
    }

    renderCobblestonePath(cols = 24) {
        const ts = this.tileSize;
        const pathTiles = [
            { x: 5, y: 6 }, { x: 5, y: 7 }, { x: 6, y: 7 }, { x: 7, y: 7 }, { x: 8, y: 7 },
            { x: 8, y: 6 },
            { x: 9, y: 7 }, { x: 17, y: 7 }, { x: 17, y: 8 }, { x: 17, y: 9 }, { x: 17, y: 10 }
        ];

        // Extensão do caminho de pedra em direção ao lago e para a Feira da Cidade na borda direita
        const pondCol = Math.max(18, cols - 7);
        for (let px = 18; px < cols; px++) {
            pathTiles.push({ x: px, y: 7 });
            pathTiles.push({ x: px, y: 8 });
        }

        this.ctx.fillStyle = '#64748b';
        pathTiles.forEach(p => {
            this.ctx.fillRect(p.x * ts + 2, p.y * ts + 2, ts - 4, ts - 4);
            this.ctx.fillStyle = '#475569';
            this.ctx.fillRect(p.x * ts + 4, p.y * ts + 4, 10, 8);
            this.ctx.fillRect(p.x * ts + 16, p.y * ts + 14, 12, 10);
            this.ctx.fillStyle = '#64748b';
        });
    }

    renderFarmhouse(x, y, style) {
        const img = this.houseExterior;
        const ts = this.tileSize;
        const w = 5 * ts;       // largura lógica da casa (5 tiles)
        const h = 4.5 * ts;     // altura lógica do corpo da casa
        const cx = x + w / 2;   // a porta fica no centro da imagem

        if (img && img.complete && img.naturalWidth > 0) {
            // Base da imagem alinhada logo abaixo da porta (degraus de pedra)
            const dh = 5.6 * ts;
            const dw = dh * (img.naturalWidth / img.naturalHeight);
            const bottom = y + h + 10;
            this.ctx.imageSmoothingEnabled = false;
            this.ctx.drawImage(img, cx - dw / 2, bottom - dh, dw, dh);

            // Fumaça animada saindo da chaminé
            const chY = bottom - dh + 6;
            this.ctx.fillStyle = 'rgba(241, 245, 249, 0.45)';
            this.smokePuffs.forEach(p => {
                this.ctx.beginPath();
                this.ctx.arc(cx + 2 + p.x, chY + p.y * 0.5, p.size * 0.6, 0, Math.PI * 2);
                this.ctx.fill();
            });
        }
    }

    renderShippingBin(x, y) {
        const ts = this.tileSize;
        this.ctx.fillStyle = '#713f12';
        this.ctx.fillRect(x + 2, y + 6, ts - 4, ts - 8);
        this.ctx.fillStyle = '#451a03';
        this.ctx.fillRect(x + 4, y + 10, ts - 8, 4);

        this.ctx.fillStyle = '#fbbf24';
        this.ctx.fillRect(x + ts / 2 - 3, y + 14, 6, 8);
        this.ctx.strokeStyle = '#d97706';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(x + 2, y + 6, ts - 4, ts - 8);
    }

    // Terra da plantação montada por código a partir de tiles em pixel art (assets/soil_tiles.png).
    // Cada tile escolhe a arte conforme os vizinhos (máscara N=1,E=2,S=4,W=8), então só as bordas
    // externas do canteiro ficam irregulares e o miolo é contínuo, sem grade nem contornos pretos.
    renderSoilPlots(state) {
        const ts = this.tileSize;
        const ctx = this.ctx;
        const atlas = this.soilAtlas;
        const atlasOk = atlas && atlas.complete && atlas.naturalWidth > 0;
        const plots = state.farmPlots || [];

        const byPos = new Map();
        plots.forEach(p => byPos.set(p.x + ',' + p.y, p));
        const at = (x, y) => byPos.get(x + ',' + y);
        const maskOf = (p, pred) => {
            let m = 0;
            if (pred(at(p.x, p.y - 1))) m |= 1;
            if (pred(at(p.x + 1, p.y))) m |= 2;
            if (pred(at(p.x, p.y + 1))) m |= 4;
            if (pred(at(p.x - 1, p.y))) m |= 8;
            return m;
        };
        const exists = q => !!q;
        const isTilled = q => !!q && q.state === 'tilled';
        const isWet = q => !!q && q.state === 'tilled' && q.isWatered;
        const variantOf = p => ((p.x * 7 + p.y * 13) % 3 + 3) % 3;
        const drawTile = (kindIdx, p, mask) => {
            ctx.drawImage(atlas, mask * 32, (kindIdx * 3 + variantOf(p)) * 32, 32, 32, p.x * ts, p.y * ts, ts, ts);
        };

        ctx.save();
        ctx.imageSmoothingEnabled = false;

        if (atlasOk) {
            // 1) terra vazia (base de todo o canteiro)
            plots.forEach(p => drawTile(0, p, maskOf(p, exists)));
            // 2) terra arada por cima; 3) manchas de terra regada por cima da arada
            plots.forEach(p => { if (isTilled(p)) drawTile(1, p, maskOf(p, isTilled)); });
            plots.forEach(p => { if (isWet(p)) drawTile(2, p, maskOf(p, isWet)); });
        } else {
            // alternativa enquanto a arte carrega: cores lisas, sem bordas escuras
            plots.forEach(p => {
                ctx.fillStyle = p.state === 'tilled' ? (p.isWatered ? '#432916' : '#7a4a28') : '#b57b3f';
                ctx.fillRect(p.x * ts, p.y * ts, ts, ts);
            });
        }

        // brilhos suaves de umidade na terra regada
        plots.forEach(p => {
            if (!isWet(p)) return;
            const ph = this.animTimer * 1.6 + p.x * 1.7 + p.y * 2.3;
            const a = Math.max(0, Math.sin(ph)) * 0.55;
            if (a < 0.05) return;
            ctx.fillStyle = 'rgba(190, 225, 245, ' + a.toFixed(2) + ')';
            ctx.fillRect(p.x * ts + 6 + ((p.x * 5 + p.y * 3) % 4) * 5, p.y * ts + 9 + ((p.x + p.y) % 2) * 12, 2, 2);
        });
        ctx.restore();

        // plantas por cima, de cima para baixo (as altas, como o milho, sobrepõem a fileira de trás)
        plots.slice().sort((a, b) => a.y - b.y || a.x - b.x).forEach(p => {
            if (p.crop) this.renderCrop(p.crop, p.x * ts, p.y * ts);
        });
    }

    // Planta sobre a terra. Estágios (assets/crops_sheet.png): 0 semente, 1 broto, 2 crescendo, 3 pronta
    renderCrop(crop, tx, ty) {
        const ts = this.tileSize;
        const config = CROPS_DATA[crop.type];
        const ROWS = { carrot: 0, strawberry: 1, corn: 2, pumpkin: 3 };
        const atlas = this.cropAtlas;
        const row = ROWS[crop.type];
        const progress = crop.daysPlanted / crop.daysToGrow;

        if (row !== undefined && atlas && atlas.complete && atlas.naturalWidth > 0) {
            const stage = crop.ready ? 3 : (progress < 0.34 ? 0 : (progress < 0.67 ? 1 : 2));
            const ctx = this.ctx;
            ctx.save();
            ctx.imageSmoothingEnabled = false;
            // leve balanço da planta pronta; as demais ficam paradas
            const sway = crop.ready ? Math.round(Math.sin(this.animTimer * 2.2 + tx * 0.05) * 1) : 0;
            ctx.drawImage(atlas, stage * 32, row * 48, 32, 48, tx + sway, ty + ts - 48, 32, 48);

            if (crop.ready) {
                // brilhinhos dourados indicando que pode colher
                const t = this.animTimer * 3 + tx * 0.13 + ty * 0.07;
                [[0, 6, 8], [1, 24, 12], [2, 14, 2]].forEach(([i, ox, oy]) => {
                    const a = Math.max(0, Math.sin(t + i * 2.1));
                    if (a < 0.2) return;
                    ctx.fillStyle = 'rgba(255, 236, 140, ' + a.toFixed(2) + ')';
                    const sx = tx + ox, sy = ty + oy + (crop.type === 'corn' ? -8 : 4);
                    ctx.fillRect(sx, sy - 1, 1, 3);
                    ctx.fillRect(sx - 1, sy, 3, 1);
                });
            }
            ctx.restore();
            return;
        }

        // alternativa (cultura sem sprite): emojis como antes
        if (crop.ready) {
            const bounce = Math.sin(this.animTimer * 4) * 3;
            this.ctx.font = '22px sans-serif';
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText(config.icon, tx + ts / 2, ty + ts / 2 - 2 + bounce);
        } else {
            this.ctx.font = progress < 0.5 ? '16px sans-serif' : '18px sans-serif';
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText(progress < 0.5 ? '🌱' : '🌿', tx + ts / 2, ty + ts / 2);
        }
    }

    renderPond(x, y, w, h) {
        this.ctx.fillStyle = '#0284c7';
        this.ctx.beginPath();
        this.ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
        this.ctx.fill();

        this.ctx.fillStyle = '#38bdf8';
        const waveOffset = Math.sin(this.animTimer * 2) * 4;
        this.ctx.beginPath();
        this.ctx.ellipse(x + w / 2 + waveOffset, y + h / 2, w / 2 - 8, h / 2 - 8, 0, 0, Math.PI * 2);
        this.ctx.fill();

        this.ctx.fillStyle = '#64748b';
        this.ctx.beginPath();
        this.ctx.arc(x + 10, y + 14, 6, 0, Math.PI * 2);
        this.ctx.arc(x + w - 12, y + h - 16, 8, 0, Math.PI * 2);
        this.ctx.fill();
    }

    // Lista de árvores da fazenda (mesmas posições usadas na colisão em game.js)
    getFarmTrees() {
        // O cenário em imagem já traz suas próprias árvores; mude para true para usar as árvores desenhadas
        if (!this.useSpriteTrees) return [];
        const cols = MAP_CONFIG.farm.cols;
        const rows = MAP_CONFIG.farm.rows;
        const ts = this.tileSize;
        const trees = [
            { x: 1 * ts, y: 9 * ts, type: 'oak' },
            { x: (cols - 3) * ts, y: 2 * ts, type: 'fruit' },
            { x: (cols - 3) * ts, y: Math.min(rows - 8, 7) * ts, type: 'blossom' },
            { x: (cols - 7) * ts, y: 2 * ts, type: 'autumn' }
        ];
        if (cols >= 30) trees.push({ x: (cols - 11) * ts, y: 2 * ts, type: 'oak' });
        if (cols >= 34) trees.push({ x: (cols - 15) * ts, y: 2 * ts, type: 'fruit' });
        if (rows >= 18) trees.push({ x: 1 * ts, y: (rows - 4) * ts, type: 'blossom' });
        return trees;
    }

    renderTree(x, y, type) {
        const img = this.treeImages && this.treeImages[type];
        if (img && img.complete && img.naturalWidth > 0) {
            // Altura ~ 76px, base do tronco alinhada ao tile
            const h = 76;
            const w = Math.round(h * (img.naturalWidth / img.naturalHeight));
            this.ctx.drawImage(img, Math.round(x + 16 - w / 2), Math.round(y + 46 - h), w, h);
            return;
        }
        this.renderProceduralTree(x, y);
    }

    renderProceduralTree(x, y) {
        this.ctx.fillStyle = '#5c2d11';
        this.ctx.fillRect(x + 10, y + 24, 12, 22);

        this.ctx.fillStyle = '#15803d';
        this.ctx.beginPath();
        this.ctx.arc(x + 16, y + 16, 20, 0, Math.PI * 2);
        this.ctx.fill();

        this.ctx.fillStyle = '#22c55e';
        this.ctx.beginPath();
        this.ctx.arc(x + 14, y + 12, 14, 0, Math.PI * 2);
        this.ctx.fill();

        this.ctx.fillStyle = '#ef4444';
        this.ctx.beginPath();
        this.ctx.arc(x + 8, y + 14, 3, 0, Math.PI * 2);
        this.ctx.arc(x + 22, y + 10, 3, 0, Math.PI * 2);
        this.ctx.arc(x + 18, y + 24, 3, 0, Math.PI * 2);
        this.ctx.fill();
    }


    // ==========================================================
    // CENA 3: CELEIRO (mesmo cenário de fundo, com construções e itens estilo Stardew Valley)
    // ==========================================================
    drawBackdrop() {
        const bg = this.farmBg;
        if (bg && bg.complete && bg.naturalWidth > 0) {
            const cw = this.canvas.width, ch = this.canvas.height;
            const scale = Math.max(cw / bg.naturalWidth, ch / bg.naturalHeight);
            const dw = bg.naturalWidth * scale, dh = bg.naturalHeight * scale;
            this.ctx.imageSmoothingEnabled = true;
            this.ctx.imageSmoothingQuality = 'high';
            this.ctx.drawImage(bg, (cw - dw) / 2, (ch - dh) / 2, dw, dh);
        } else {
            this.ctx.fillStyle = '#224729';
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        }
    }

    renderBarnScene(state) {
        // Cenário dos currais em tamanho real - a câmera segue o jogador
        const T = window.BARN_WORLD;
        const bg = this.barnWorldBg;
        this.ctx.fillStyle = '#1b3a1f';
        this.ctx.fillRect(-2, -2, T.w + 4, T.h + 4);
        if (bg && bg.complete && bg.naturalWidth > 0) {
            this.ctx.imageSmoothingEnabled = true;
            this.ctx.imageSmoothingQuality = 'high';
            this.ctx.drawImage(bg, 0, 0, T.w, T.h);
        }

        // Vacas, porcos e galinhas nos seus cercados
        if (window.barnAnimals) {
            window.barnAnimals.update(performance.now());
            window.barnAnimals.draw(this.ctx);
        }
    }

    // Interiores dos currais (celeiro, abrigo dos porcos e galinheiro), desenhados por código
    renderBarnInsideScene(state) {
        const T = window.BARN_INSIDE, ctx = this.ctx, kind = T.kind || 'cow';
        const PAL = {
            cow: { wallA: '#832e26', wallB: '#6e2520', base: '#4a2a14', floorA: '#c29556', floorB: '#b0803f', side: '#5a1f1a', sideEdge: '#3d1612' },
            pig: { wallA: '#7a5230', wallB: '#684324', base: '#3e2a16', floorA: '#9c7a52', floorB: '#8c6b45', side: '#5a3c22', sideEdge: '#3a2514' },
            hen: { wallA: '#a9774a', wallB: '#98683c', base: '#6b4423', floorA: '#d2a766', floorB: '#c49a5a', side: '#8a5a2e', sideEdge: '#5e3d1e' }
        }[kind];
        ctx.fillStyle = '#14100c';
        ctx.fillRect(-2, -2, T.w + 4, T.h + 4);

        // parede de fundo (tábuas verticais)
        const wallH = T.floor.top;
        for (let x = 0; x < T.w; x += 16) {
            ctx.fillStyle = (x / 16) % 2 ? PAL.wallB : PAL.wallA;
            ctx.fillRect(x, 0, 15, wallH);
            ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x + 15, 0, 1, wallH);
        }
        ctx.fillStyle = PAL.base; ctx.fillRect(0, wallH - 8, T.w, 8);
        [[150, 24], [310, 24]].forEach(([wx, wy]) => {
            ctx.fillStyle = '#3a2412'; ctx.fillRect(wx - 2, wy - 2, 36, 40);
            ctx.fillStyle = '#ffe9a8'; ctx.fillRect(wx, wy, 32, 36);
            ctx.fillStyle = '#3a2412'; ctx.fillRect(wx + 15, wy, 2, 36); ctx.fillRect(wx, wy + 17, 32, 2);
        });

        // piso de tábuas com palha
        for (let y = wallH; y < T.h; y += 16) {
            ctx.fillStyle = ((y - wallH) / 16) % 2 ? PAL.floorB : PAL.floorA;
            ctx.fillRect(0, y, T.w, 15);
            ctx.fillStyle = 'rgba(60,35,15,0.35)'; ctx.fillRect(0, y + 15, T.w, 1);
        }
        for (let i = 0; i < 70; i++) {
            const sx = (i * 97) % (T.w - 60) + 30, sy = wallH + 8 + ((i * 53) % (T.h - wallH - 24));
            ctx.fillStyle = i % 2 ? '#e9c46a' : '#d4a64a';
            ctx.fillRect(sx, sy, 6, 1.5);
        }
        if (kind === 'pig') {            // poças de lama no chão
            ctx.fillStyle = 'rgba(70,42,20,0.55)';
            ctx.beginPath(); ctx.ellipse(170, 236, 46, 18, 0, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.ellipse(300, 276, 38, 14, 0, 0, Math.PI * 2); ctx.fill();
        }
        ctx.fillStyle = PAL.side; ctx.fillRect(0, wallH, 32, T.h - wallH); ctx.fillRect(T.w - 32, wallH, 32, T.h - wallH);
        ctx.fillStyle = PAL.sideEdge; ctx.fillRect(30, wallH, 3, T.h - wallH); ctx.fillRect(T.w - 33, wallH, 3, T.h - wallH);

        const hay = (hx, hy, w, h) => {
            ctx.fillStyle = '#e0b448'; ctx.fillRect(hx, hy, w, h);
            ctx.fillStyle = '#f3d070'; ctx.fillRect(hx, hy, w, 5);
            ctx.fillStyle = '#9a6b1e'; ctx.fillRect(hx + 10, hy, 2, h); ctx.fillRect(hx + w - 12, hy, 2, h);
        };
        const barrel = (bx, by) => {
            ctx.fillStyle = '#7b4a22'; ctx.fillRect(bx, by, 24, 28);
            ctx.fillStyle = '#a06a35'; ctx.fillRect(bx + 2, by, 6, 28);
            ctx.fillStyle = '#3b3b3b'; ctx.fillRect(bx, by + 6, 24, 3); ctx.fillRect(bx, by + 19, 24, 3);
        };
        const trough = (tx, ty, w) => {
            ctx.fillStyle = '#6b4423'; ctx.fillRect(tx, ty, w, 28);
            ctx.fillStyle = '#8a5a2e'; ctx.fillRect(tx, ty, w, 8);
            ctx.fillStyle = '#4a7c3a'; ctx.fillRect(tx + 8, ty + 6, w - 16, 8);
        };

        if (kind === 'cow') {
            for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) hay(40 + c * 42, 106 + r * 26, 40, 24);
            trough(196, 106, 88);
            ctx.fillStyle = '#4a2a14'; ctx.fillRect(340, 104, 100, 4);
            for (let i = 0; i < 4; i++) { ctx.fillStyle = '#6b4423'; ctx.fillRect(342 + i * 26, 104, 6, 68); }
            ctx.fillStyle = '#8a5a2e'; ctx.fillRect(340, 130, 100, 5); ctx.fillRect(340, 164, 100, 5);
            ctx.fillStyle = '#e0b448'; ctx.fillRect(352, 140, 76, 18);
            barrel(50, 252); barrel(68, 270);
        } else if (kind === 'pig') {
            trough(40, 106, 120);
            for (let r = 0; r < 2; r++) hay(332, 106 + r * 34, 106, 32);
            ctx.fillStyle = '#6b6b6b';                       // baldes
            [[376, 252], [404, 262]].forEach(([bx, by]) => { ctx.fillRect(bx, by, 22, 26); ctx.fillStyle = '#9a9a9a'; ctx.fillRect(bx, by, 22, 5); ctx.fillStyle = '#6b6b6b'; });
        } else {
            // ninhos na parede do fundo, com ovos
            ctx.fillStyle = '#6b4423'; ctx.fillRect(40, 106, 400, 34);
            for (let i = 0; i < 8; i++) {
                const nx = 48 + i * 48;
                ctx.fillStyle = '#3a2412'; ctx.fillRect(nx, 112, 40, 22);
                ctx.fillStyle = '#e0b448'; ctx.fillRect(nx + 3, 124, 34, 8);
                ctx.fillStyle = '#fff6df'; ctx.fillRect(nx + 12, 120, 7, 9); if (i % 2) ctx.fillRect(nx + 22, 121, 7, 8);
            }
            ctx.fillStyle = '#8a5a2e'; ctx.fillRect(40, 138, 400, 4);
            ctx.fillStyle = '#7b5a2a'; ctx.fillRect(50, 250, 52, 48);             // caixotes
            ctx.fillStyle = '#9b7a3c'; ctx.fillRect(50, 250, 52, 8); ctx.fillRect(74, 250, 4, 48);
            ctx.fillStyle = '#6b4423'; ctx.fillRect(366, 228, 66, 42);            // comedouro
            ctx.fillStyle = '#e9c46a'; ctx.fillRect(372, 232, 54, 12);
        }

        // porta de saída (vão central embaixo) com luz de fora
        ctx.fillStyle = '#8fd16a'; ctx.fillRect(204, T.floor.bottom - 6, 72, T.h - T.floor.bottom + 6);
        ctx.fillStyle = PAL.side; ctx.fillRect(196, T.floor.bottom - 8, 8, T.h - T.floor.bottom + 8); ctx.fillRect(276, T.floor.bottom - 8, 8, T.h - T.floor.bottom + 8);
        ctx.fillStyle = 'rgba(255,240,170,0.18)'; ctx.fillRect(204, T.floor.bottom - 60, 72, 60);
    }

    renderBarn(bx, by, bw, bh) {
        const c = this.ctx;
        const img = this.barnImg;
        if (!(img && img.complete && img.naturalWidth > 0)) return;

        // Imagem centralizada na área do celeiro, base alinhada ao chão (portão no centro)
        const dh = bh + 30;
        const dw = dh * (img.naturalWidth / img.naturalHeight);
        const cx = bx + bw / 2;
        const bottom = by + bh + 8;

        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.fillRect(cx - dw / 2 + 14, bottom - 18, dw - 28, 10);

        c.imageSmoothingEnabled = false;
        c.drawImage(img, cx - dw / 2, bottom - dh, dw, dh);
    }

    renderSilo(sx, sy, h) {
        const c = this.ctx;
        const w = 56, x = sx + 4, top = sy + 34, bottom = sy + h;
        c.fillStyle = 'rgba(0,0,0,0.28)';
        c.fillRect(x - 2, bottom - 5, w + 8, 9);

        const grad = c.createLinearGradient(x, 0, x + w, 0);
        grad.addColorStop(0, '#64748b');
        grad.addColorStop(0.35, '#cbd5e1');
        grad.addColorStop(1, '#475569');
        c.fillStyle = grad;
        c.fillRect(x, top, w, bottom - top);

        c.fillStyle = 'rgba(30, 41, 59, 0.45)';
        for (let y = top + 14; y < bottom - 6; y += 18) c.fillRect(x, y, w, 2);

        // Cúpula
        c.fillStyle = '#94a3b8';
        c.beginPath();
        c.ellipse(x + w / 2, top, w / 2, 20, 0, Math.PI, 0);
        c.fill();
        c.fillStyle = '#e2e8f0';
        c.beginPath();
        c.ellipse(x + w / 2 - 8, top - 8, 9, 5, -0.4, 0, Math.PI * 2);
        c.fill();
        c.fillStyle = '#475569';
        c.fillRect(x + w / 2 - 2, top - 26, 4, 8);

        // Porta e escada
        c.fillStyle = '#7f1d1d';
        c.fillRect(x + w / 2 - 9, bottom - 34, 18, 30);
        c.fillStyle = '#f5f5f4';
        c.fillRect(x + w / 2 - 9, bottom - 34, 18, 2);
        c.fillStyle = '#334155';
        c.fillRect(x + 6, top + 6, 2, bottom - top - 40);
        c.fillRect(x + 12, top + 6, 2, bottom - top - 40);
        for (let y = top + 12; y < bottom - 40; y += 8) c.fillRect(x + 6, y, 8, 2);
    }

    renderHayBale(x, y, i = 0) {
        const c = this.ctx;
        const bx = x + 1, by = y + 8, bw = 30, bh = 22;
        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.fillRect(bx + 1, by + bh - 2, bw, 4);
        c.fillStyle = '#eab308';
        c.fillRect(bx, by, bw, bh);
        c.fillStyle = '#facc15';
        c.fillRect(bx, by, bw, 5);
        c.fillStyle = '#ca8a04';
        for (let k = 0; k < 9; k++) c.fillRect(bx + 2 + k * 3 + (i % 2), by + 3 + (k * 7) % 16, 2, 5);
        c.fillStyle = '#92400e';
        c.fillRect(bx + 7, by, 2, bh);
        c.fillRect(bx + bw - 9, by, 2, bh);
        c.strokeStyle = '#a16207';
        c.lineWidth = 1;
        c.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
    }

    renderBarrel(x, y) {
        const c = this.ctx;
        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.beginPath(); c.ellipse(x + 16, y + 29, 12, 4, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#92400e';
        c.fillRect(x + 6, y + 6, 20, 22);
        c.fillStyle = '#b45309';
        c.fillRect(x + 8, y + 6, 6, 22);
        c.fillStyle = '#78350f';
        c.beginPath(); c.ellipse(x + 16, y + 7, 10, 4, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#a16207';
        c.beginPath(); c.ellipse(x + 16, y + 6, 8, 3, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#404040';
        c.fillRect(x + 6, y + 11, 20, 2);
        c.fillRect(x + 6, y + 22, 20, 2);
    }

    renderMilkCan(x, y) {
        const c = this.ctx;
        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.beginPath(); c.ellipse(x + 16, y + 29, 9, 3, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#94a3b8';
        c.fillRect(x + 9, y + 12, 14, 17);
        c.fillStyle = '#e2e8f0';
        c.fillRect(x + 11, y + 12, 4, 17);
        c.fillStyle = '#64748b';
        c.fillRect(x + 7, y + 8, 18, 5);
        c.fillStyle = '#cbd5e1';
        c.fillRect(x + 11, y + 3, 10, 6);
        c.fillStyle = '#ef4444';
        c.fillRect(x + 9, y + 20, 14, 3);
        c.fillStyle = '#475569';
        c.fillRect(x + 6, y + 12, 3, 8);
        c.fillRect(x + 23, y + 12, 3, 8);
    }

    renderTrough(x, y) {
        const c = this.ctx;
        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.fillRect(x + 4, y + 26, 58, 5);
        c.fillStyle = '#78350f';
        c.fillRect(x + 3, y + 22, 5, 8);
        c.fillRect(x + 56, y + 22, 5, 8);
        c.fillStyle = '#92400e';
        c.fillRect(x + 1, y + 8, 62, 18);
        c.fillStyle = '#b45309';
        c.fillRect(x + 1, y + 8, 62, 3);
        c.fillStyle = '#38bdf8';
        c.fillRect(x + 5, y + 11, 54, 9);
        c.fillStyle = '#bae6fd';
        const t = Math.sin(this.animTimer * 2) * 3;
        c.fillRect(x + 12 + t, y + 13, 10, 2);
        c.fillRect(x + 36 - t, y + 16, 12, 2);
    }

    renderSignpost(x, y) {
        const c = this.ctx;
        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.fillRect(x + 11, y + 28, 12, 3);
        c.fillStyle = '#78350f';
        c.fillRect(x + 14, y + 12, 4, 18);
        c.fillStyle = '#b45309';
        c.beginPath();
        c.moveTo(x + 3, y + 4); c.lineTo(x + 24, y + 4); c.lineTo(x + 30, y + 10);
        c.lineTo(x + 24, y + 16); c.lineTo(x + 3, y + 16); c.closePath();
        c.fill();
        c.strokeStyle = '#78350f'; c.lineWidth = 1.5; c.stroke();
        c.fillStyle = '#fde68a';
        c.fillRect(x + 7, y + 8, 14, 2);
        c.fillRect(x + 7, y + 11, 10, 2);
    }

    renderPen(L) {
        const ts = this.tileSize, c = this.ctx;
        const { x1, y1, x2, y2 } = L.pen;
        const left = x1 * ts, right = (x2 + 1) * ts, top = y1 * ts, bottom = (y2 + 1) * ts;

        // Chão do cercado (terra pisada + palha)
        c.fillStyle = 'rgba(133, 77, 14, 0.38)';
        c.fillRect(left + 8, top + 18, right - left - 16, bottom - top - 28);
        c.strokeStyle = '#facc15'; c.lineWidth = 1.5;
        for (let i = 0; i < 22; i++) {
            const sx = left + 14 + ((i * 41) % (right - left - 30));
            const sy = top + 24 + ((i * 29) % (bottom - top - 50));
            c.beginPath(); c.moveTo(sx, sy); c.lineTo(sx + 5, sy + (i % 2 ? 2 : -1)); c.stroke();
        }

        const fenceH = (xa, xb, y) => {
            c.fillStyle = '#a16207';
            c.fillRect(xa, y + 8, xb - xa, 3);
            c.fillRect(xa, y + 16, xb - xa, 3);
            c.fillStyle = '#78350f';
            for (let x = xa; x <= xb - 6; x += 24) c.fillRect(x, y + 3, 6, 20);
        };
        const fenceV = (x, ya, yb) => {
            c.fillStyle = '#a16207';
            c.fillRect(x + 7, ya, 3, yb - ya);
            c.fillRect(x + 15, ya, 3, yb - ya);
            c.fillStyle = '#78350f';
            for (let y = ya; y <= yb - 6; y += 22) c.fillRect(x + 5, y, 6, 18);
        };

        fenceH(left, right, top);
        // Animais (dentro do cercado), entre a cerca de trás e a da frente
        // Vacas (andando) e galinhas, ordenadas por Y para a profundidade ficar correta
        const herd = window.cowHerd;
        const drawList = L.chickens.map(ch => ({ y: ch.y * ts + 14, fn: () => this.renderChicken(ch.x * ts, ch.y * ts, ch.off) }));
        if (herd) herd.cows.forEach(cow => drawList.push({ y: cow.y, fn: () => herd.draw(c, cow) }));
        drawList.sort((a, b) => a.y - b.y).forEach(it => it.fn());
        fenceV(left, top, top + 2 * ts);
        fenceV(left, bottom - 2 * ts + 8, bottom - 6);
        fenceV(right - ts, top, bottom - 6);
        fenceH(left, right, bottom - ts);
        // Cocho de feno dentro do cercado
        c.fillStyle = '#78350f';
        c.fillRect(right - 3 * ts, top + ts + 6, 44, 14);
        c.fillStyle = '#eab308';
        c.fillRect(right - 3 * ts + 3, top + ts + 4, 38, 8);
    }

    renderCow(x, y) {
        const c = this.ctx;
        const bob = Math.sin(this.animTimer * 1.8) * 0.8;
        y += bob;
        c.fillStyle = 'rgba(0,0,0,0.28)';
        c.beginPath(); c.ellipse(x + 16, y + 28, 22, 5, 0, 0, Math.PI * 2); c.fill();
        // pernas
        c.fillStyle = '#e5e5e5';
        c.fillRect(x - 2, y + 14, 5, 13); c.fillRect(x + 8, y + 15, 5, 12);
        c.fillRect(x + 22, y + 14, 5, 13); c.fillRect(x + 32, y + 15, 5, 12);
        c.fillStyle = '#292524';
        c.fillRect(x - 2, y + 24, 5, 3); c.fillRect(x + 8, y + 24, 5, 3);
        c.fillRect(x + 22, y + 24, 5, 3); c.fillRect(x + 32, y + 24, 5, 3);
        // corpo
        c.fillStyle = '#fafafa';
        c.fillRect(x - 4, y + 2, 42, 18);
        c.fillStyle = '#e5e5e5';
        c.fillRect(x - 4, y + 16, 42, 4);
        c.fillStyle = '#292524';
        c.fillRect(x + 2, y + 4, 9, 7); c.fillRect(x + 20, y + 8, 11, 7); c.fillRect(x + 26, y + 3, 6, 4);
        // úbere
        c.fillStyle = '#f9a8d4';
        c.fillRect(x + 22, y + 19, 8, 4);
        // cabeça (à esquerda)
        c.fillStyle = '#fafafa';
        c.fillRect(x - 14, y + 2, 14, 14);
        c.fillStyle = '#292524';
        c.fillRect(x - 12, y + 2, 5, 5);
        c.fillStyle = '#f9a8d4';
        c.fillRect(x - 16, y + 10, 10, 7);
        c.fillStyle = '#be185d';
        c.fillRect(x - 14, y + 13, 2, 2); c.fillRect(x - 9, y + 13, 2, 2);
        c.fillStyle = '#171717';
        c.fillRect(x - 4, y + 5, 2, 2);
        c.fillStyle = '#fde68a';
        c.fillRect(x - 3, y - 2, 3, 5); c.fillRect(x - 14, y - 2, 3, 5);
        // rabo
        c.fillStyle = '#d4d4d4';
        c.fillRect(x + 38, y + 4, 2, 12);
        c.fillStyle = '#292524';
        c.fillRect(x + 37, y + 14, 4, 4);
    }

    renderChicken(x, y, off = 0) {
        const c = this.ctx;
        const hop = Math.max(0, Math.sin(this.animTimer * 3 + off)) * 2;
        y -= hop;
        c.fillStyle = 'rgba(0,0,0,0.25)';
        c.beginPath(); c.ellipse(x + 8, y + 15 + hop, 8, 3, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#f97316';
        c.fillRect(x + 5, y + 11, 2, 5); c.fillRect(x + 9, y + 11, 2, 5);
        c.fillStyle = '#fafafa';
        c.beginPath(); c.ellipse(x + 8, y + 8, 8, 6, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#e5e5e5';
        c.beginPath(); c.ellipse(x + 11, y + 9, 4, 3, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#fafafa';
        c.fillRect(x - 2, y + 1, 4, 4);
        c.fillStyle = '#ef4444';
        c.fillRect(x - 1, y - 1, 3, 3);
        c.fillStyle = '#f59e0b';
        c.fillRect(x - 5, y + 3, 4, 2);
        c.fillStyle = '#171717';
        c.fillRect(x - 1, y + 2, 1, 1);
    }

    renderPerimeterFence(cols, rows) {
        const ts = this.tileSize;
        this.ctx.fillStyle = '#854d0e';
        for (let c = 0; c < cols; c++) {
            this.ctx.fillRect(c * ts + 12, 4, 8, 20);
            this.ctx.fillRect(c * ts + 12, (rows - 1) * ts + 4, 8, 20);
        }
        for (let r = 0; r < rows; r++) {
            this.ctx.fillRect(4, r * ts + 12, 20, 8);
            this.ctx.fillRect((cols - 1) * ts + 4, r * ts + 12, 20, 8);
        }
    }

    // ==========================================================
    // CENÁRIO 4: CENTRO DA CIDADE
    // ==========================================================
    // Centro da Cidade: imagem em escala 1:1, a câmera mostra só a parte visível
    renderCityScene(state) {
        const T = window.CITY_WORLD;
        const bg = this.cityWorldBg;
        this.ctx.fillStyle = '#1b3a1f';
        this.ctx.fillRect(-2, -2, T.w + 4, T.h + 4);
        if (bg && bg.complete && bg.naturalWidth > 0) {
            this.ctx.imageSmoothingEnabled = true;
            this.ctx.imageSmoothingQuality = 'high';
            this.ctx.drawImage(bg, 0, 0, T.w, T.h);
        }
    }

    // ==========================================================
    // CENA 2: INTERIOR DA CASA (HOUSE INTERIOR)
    // ==========================================================
    renderHouseScene(state, variant) {
        const friends = variant === 'friends';
        const ts = this.tileSize;
        const conf = MAP_CONFIG.house;
        const ox = conf.offsetX * ts;
        const oy = conf.offsetY * ts;
        const w = conf.cols * ts;
        const h = conf.rows * ts;

        this.ctx.fillStyle = '#080612';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        const img = this.houseInterior;
        if (img && img.complete && img.naturalWidth > 0) {
            this.ctx.imageSmoothingEnabled = false;
            this.ctx.drawImage(img, ox, oy, w, h);
        } else {
            // Fallback enquanto a imagem carrega
            this.ctx.fillStyle = '#92400e';
            this.ctx.fillRect(ox, oy, w, h);
        }

        this.renderPlacedFurniture(state, friends ? FRIEND_HOUSE_FURNITURE : state.placedFurniture);
    }

    renderPlacedFurniture(state, list) {
        list = list || state.placedFurniture;
        const ts = this.tileSize;
        const ox = MAP_CONFIG.house.offsetX * ts;
        const oy = MAP_CONFIG.house.offsetY * ts;

        const rugs = list.filter(item => !FURNITURE_CATALOG[item.type].solid);
        const solids = list.filter(item => FURNITURE_CATALOG[item.type].solid);

        rugs.forEach(item => this.drawFurniturePiece(item, ox, oy, ts, state));
        // Móveis sólidos ordenados por profundidade (quem está mais abaixo desenha por cima)
        solids.slice()
            .sort((a, b) => (a.y + FURNITURE_CATALOG[a.type].height) - (b.y + FURNITURE_CATALOG[b.type].height))
            .forEach(item => this.drawFurniturePiece(item, ox, oy, ts, state));
    }

    // Móveis com sprite (imagem pixel art): largura "dw" em blocos, alinhado à base da área ocupada
    getFurnitureImage(src) {
        if (!this._furnImgs) this._furnImgs = {};
        let img = this._furnImgs[src];
        if (!img) {
            img = new Image();
            img.src = src;
            this._furnImgs[src] = img;
        }
        return img;
    }

    drawFurnitureSprite(def, fx, fy, fw, fh, alpha = 1) {
        const img = this.getFurnitureImage(def.sprite);
        if (!img.complete || !img.naturalWidth) return;
        const dw = (def.dw || def.width) * this.tileSize;
        const dh = dw * (img.naturalHeight / img.naturalWidth);
        const x = fx + (fw - dw) / 2;
        const y = fy + fh - dh;
        this.ctx.save();
        this.ctx.globalAlpha = alpha;
        this.ctx.imageSmoothingEnabled = true;
        this.ctx.drawImage(img, x, y, dw, dh);
        this.ctx.restore();
    }

    drawFurniturePiece(item, ox, oy, ts, state) {
        const def = FURNITURE_CATALOG[item.type];
        const fx = ox + item.x * ts;
        const fy = oy + item.y * ts;
        const fw = def.width * ts;
        const fh = def.height * ts;

        if (state.decorMode && state.selectedPlacedFurniture === item) {
            this.ctx.strokeStyle = '#fbbf24';
            this.ctx.lineWidth = 3;
            this.ctx.strokeRect(fx - 2, fy - 2, fw + 4, fh + 4);
        }

        if (def.sprite) {
            this.drawFurnitureSprite(def, fx, fy, fw, fh);
            return;
        }

        switch (item.type) {
            case 'bed_royal':
                this.ctx.fillStyle = '#451a03';
                this.ctx.fillRect(fx, fy, fw, fh);
                this.ctx.fillStyle = def.colorMain;
                this.ctx.fillRect(fx + 4, fy + 8, fw - 8, fh - 12);
                this.ctx.fillStyle = def.colorAccent;
                this.ctx.fillRect(fx + 4, fy + 24, fw - 8, 12);
                this.ctx.fillStyle = def.colorPillow;
                this.ctx.fillRect(fx + 8, fy + 8, (fw - 24) / 2, 14);
                this.ctx.fillRect(fx + fw / 2 + 4, fy + 8, (fw - 24) / 2, 14);
                break;

            case 'sofa_indigo':
                this.ctx.fillStyle = def.colorMain;
                this.ctx.fillRect(fx + 2, fy + 4, fw - 4, fh - 6);
                this.ctx.fillStyle = def.colorAccent;
                this.ctx.fillRect(fx + 6, fy + 8, (fw - 16) / 2, fh - 14);
                this.ctx.fillRect(fx + fw / 2 + 2, fy + 8, (fw - 16) / 2, fh - 14);
                this.ctx.fillStyle = '#1e1b4b';
                this.ctx.fillRect(fx, fy + 4, 6, fh - 6);
                this.ctx.fillRect(fx + fw - 6, fy + 4, 6, fh - 6);
                break;

            case 'table_wood':
                this.ctx.fillStyle = def.colorMain;
                this.ctx.fillRect(fx + 4, fy + 4, fw - 8, fh - 8);
                this.ctx.fillStyle = def.colorAccent;
                this.ctx.fillRect(fx + fw / 2 - 8, fy + 4, 16, fh - 8);
                this.ctx.fillStyle = '#fef08a';
                this.ctx.beginPath();
                this.ctx.arc(fx + fw / 2, fy + fh / 2, 4, 0, Math.PI * 2);
                this.ctx.fill();
                break;

            case 'rug_purple':
            case 'rug_blue':
                this.ctx.fillStyle = def.colorMain;
                this.ctx.fillRect(fx + 4, fy + 4, fw - 8, fh - 8);
                this.ctx.strokeStyle = def.colorAccent;
                this.ctx.lineWidth = 2;
                this.ctx.strokeRect(fx + 8, fy + 8, fw - 16, fh - 16);
                this.ctx.fillStyle = def.colorAccent;
                this.ctx.font = '14px sans-serif';
                this.ctx.textAlign = 'center';
                this.ctx.textBaseline = 'middle';
                this.ctx.fillText('✨', fx + fw / 2, fy + fh / 2);
                break;

            case 'plant_pot':
                this.ctx.fillStyle = def.colorMain;
                this.ctx.fillRect(fx + 8, fy + 16, 16, 12);
                this.ctx.fillStyle = def.colorAccent;
                this.ctx.beginPath();
                this.ctx.arc(fx + 16, fy + 12, 10, 0, Math.PI * 2);
                this.ctx.fill();
                this.ctx.fillStyle = '#4ade80';
                this.ctx.beginPath();
                this.ctx.arc(fx + 16, fy + 8, 6, 0, Math.PI * 2);
                this.ctx.fill();
                break;

            case 'bookshelf':
                this.ctx.fillStyle = def.colorMain;
                this.ctx.fillRect(fx + 2, fy + 2, fw - 4, fh - 4);
                const bookColors = ['#f43f5e', '#a855f7', '#38bdf8', '#fbbf24', '#4ade80'];
                for (let i = 0; i < 8; i++) {
                    this.ctx.fillStyle = bookColors[i % bookColors.length];
                    this.ctx.fillRect(fx + 6 + i * 6, fy + 8, 4, fh - 14);
                }
                break;

            case 'lamp_cozy':
                this.ctx.fillStyle = '#581c87';
                this.ctx.fillRect(fx + 14, fy + 18, 4, 10);
                this.ctx.fillStyle = def.colorMain;
                this.ctx.beginPath();
                this.ctx.arc(fx + 16, fy + 14, 8, 0, Math.PI * 2);
                this.ctx.fill();
                const halo = this.ctx.createRadialGradient(fx + 16, fy + 14, 2, fx + 16, fy + 14, 38);
                halo.addColorStop(0, 'rgba(254, 240, 138, 0.35)');
                halo.addColorStop(1, 'rgba(254, 240, 138, 0)');
                this.ctx.fillStyle = halo;
                this.ctx.beginPath();
                this.ctx.arc(fx + 16, fy + 14, 38, 0, Math.PI * 2);
                this.ctx.fill();
                break;
        }
    }

    renderDecorOverlay(state) {
        const ts = this.tileSize;
        const conf = MAP_CONFIG.house;
        const ox = conf.offsetX * ts;
        const oy = conf.offsetY * ts;

        this.ctx.strokeStyle = 'rgba(168, 85, 247, 0.25)';
        this.ctx.lineWidth = 1;

        for (let r = conf.roomBounds.startY; r <= conf.roomBounds.endY; r++) {
            for (let c = conf.roomBounds.startX; c <= conf.roomBounds.endX; c++) {
                this.ctx.strokeRect(ox + c * ts, oy + r * ts, ts, ts);
            }
        }

        if (state.draggedFurniture) {
            const def = FURNITURE_CATALOG[state.draggedFurniture.type];
            const gx = ox + state.dragGhostPos.x * ts;
            const gy = oy + state.dragGhostPos.y * ts;
            const gw = def.width * ts;
            const gh = def.height * ts;

            if (def.sprite) this.drawFurnitureSprite(def, gx, gy, gw, gh, 0.75);
            this.ctx.fillStyle = state.dragGhostValid ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)';
            this.ctx.fillRect(gx, gy, gw, gh);
            this.ctx.strokeStyle = state.dragGhostValid ? '#22c55e' : '#ef4444';
            this.ctx.lineWidth = 2;
            this.ctx.strokeRect(gx, gy, gw, gh);
        }
    }

    renderInteractionPrompt(text, player) {
        const px = player.x;
        const py = player.y - 20;

        this.ctx.font = 'bold 11px Fredoka, sans-serif';
        const textWidth = this.ctx.measureText(text).width;
        const boxW = textWidth + 16;
        const boxH = 20;

        this.ctx.fillStyle = 'rgba(24, 20, 48, 0.92)';
        this.ctx.strokeStyle = '#c084fc';
        this.ctx.lineWidth = 1.5;

        const bx = px + 16 - boxW / 2;
        const by = py - boxH;

        this.ctx.beginPath();
        this.ctx.roundRect(bx, by, boxW, boxH, 6);
        this.ctx.fill();
        this.ctx.stroke();

        this.ctx.fillStyle = '#f8fafc';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(text, px + 16, by + boxH / 2);
    }

    // ==========================================================
    // OVERLAY DE SELEÇÃO E MARCAÇÕES DE ALCANCE DO SOLO
    // ==========================================================
    renderSoilSelectionOverlay(state) {
        if (state.currentScene !== 'farm') return;
        const soil = state.soilSelection;
        if (!soil) return;

        const ts = this.tileSize;
        const p = state.player;
        const px = p.x + 16;
        const py = p.y + 16;
        const reachRadius = soil.reachRadius || 96;

        const isHoveringSoil = soil.hoverTile && state.farmPlots.some(pt => pt.x === soil.hoverTile.tileX && pt.y === soil.hoverTile.tileY);
        const showReach = soil.active || isHoveringSoil;

        // 1. Aura e Marcações de Alcance ("até onde ela irá conseguir fazer")
        if (showReach) {
            this.ctx.save();

            // Círculo suave de alcance ao redor do jogador
            this.ctx.beginPath();
            this.ctx.arc(px, py, reachRadius, 0, Math.PI * 2);
            this.ctx.strokeStyle = 'rgba(250, 204, 21, 0.45)';
            this.ctx.lineWidth = 1.5;
            this.ctx.setLineDash([4, 4]);
            this.ctx.stroke();
            this.ctx.fillStyle = 'rgba(250, 204, 21, 0.04)';
            this.ctx.fill();

            // Marcação com contornos pontilhados em todos os canteiros dentro do alcance
            state.farmPlots.forEach(plot => {
                const tx = plot.x * ts;
                const ty = plot.y * ts;
                const dist = Math.hypot((tx + 16) - px, (ty + 16) - py);
                if (dist <= reachRadius) {
                    this.ctx.strokeStyle = 'rgba(250, 204, 21, 0.3)';
                    this.ctx.lineWidth = 1;
                    this.ctx.setLineDash([3, 3]);
                    this.ctx.strokeRect(tx + 2, ty + 2, ts - 4, ts - 4);
                }
            });

            this.ctx.restore();
        }

        // 2. Canteiros Selecionados (Marcações de Ação Ativas)
        if (soil.active && soil.selectedPlots && soil.selectedPlots.length > 0) {
            let validCount = 0;
            let actionLabel = '';
            let lastPlot = null;

            soil.selectedPlots.forEach(item => {
                const plot = item.plot;
                const tx = plot.x * ts;
                const ty = plot.y * ts;
                const dist = Math.hypot((tx + 16) - px, (ty + 16) - py);
                const inRange = dist <= reachRadius;
                lastPlot = plot;

                this.ctx.save();

                if (!inRange) {
                    // Marcado como FORA DO ALCANCE
                    this.ctx.fillStyle = 'rgba(239, 68, 68, 0.25)';
                    this.ctx.fillRect(tx + 2, ty + 2, ts - 4, ts - 4);
                    this.ctx.strokeStyle = '#ef4444';
                    this.ctx.lineWidth = 2;
                    this.ctx.setLineDash([3, 3]);
                    this.ctx.strokeRect(tx + 2, ty + 2, ts - 4, ts - 4);

                    this.ctx.font = 'bold 12px sans-serif';
                    this.ctx.fillStyle = '#f87171';
                    this.ctx.textAlign = 'center';
                    this.ctx.textBaseline = 'middle';
                    this.ctx.fillText('🚫', tx + 16, ty + 16);
                } else {
                    // DENTRO DO ALCANCE
                    const action = item.action;
                    let strokeColor = '#facc15';
                    let fillColor = 'rgba(250, 204, 21, 0.3)';
                    let icon = '⛏️';

                    if (action === 'till') {
                        strokeColor = '#facc15';
                        fillColor = 'rgba(234, 179, 8, 0.32)';
                        icon = '⛏️';
                        actionLabel = 'Arar Solo';
                        validCount++;
                    } else if (action === 'water') {
                        strokeColor = '#38bdf8';
                        fillColor = 'rgba(56, 189, 248, 0.35)';
                        icon = '💧';
                        actionLabel = 'Regar Solo';
                        validCount++;
                    } else if (action === 'plant') {
                        strokeColor = '#4ade80';
                        fillColor = 'rgba(34, 197, 94, 0.35)';
                        const cropDef = CROPS_DATA[item.seedType] || CROPS_DATA.carrot;
                        icon = cropDef.icon || '🌱';
                        actionLabel = `Plantar ${cropDef.name}`;
                        validCount++;
                    } else if (action === 'harvest') {
                        strokeColor = '#fbbf24';
                        fillColor = 'rgba(251, 191, 36, 0.4)';
                        icon = '✂️';
                        actionLabel = 'Colher Safra';
                        validCount++;
                    } else {
                        strokeColor = 'rgba(148, 163, 184, 0.5)';
                        fillColor = 'rgba(148, 163, 184, 0.15)';
                        icon = '✓';
                    }

                    const pulse = Math.sin(this.animTimer * 6) * 1.5;
                    this.ctx.fillStyle = fillColor;
                    this.ctx.fillRect(tx + 2, ty + 2, ts - 4, ts - 4);

                    this.ctx.strokeStyle = strokeColor;
                    this.ctx.lineWidth = 2;
                    this.ctx.strokeRect(tx + 2, ty + 2, ts - 4, ts - 4);

                    // Cantoneiras pixel art estilo Stardew Valley
                    this.ctx.fillStyle = strokeColor;
                    this.ctx.fillRect(tx + 1, ty + 1, 4, 2);
                    this.ctx.fillRect(tx + 1, ty + 1, 2, 4);
                    this.ctx.fillRect(tx + ts - 5, ty + 1, 4, 2);
                    this.ctx.fillRect(tx + ts - 3, ty + 1, 2, 4);
                    this.ctx.fillRect(tx + 1, ty + ts - 3, 4, 2);
                    this.ctx.fillRect(tx + 1, ty + ts - 5, 2, 4);
                    this.ctx.fillRect(tx + ts - 5, ty + ts - 3, 4, 2);
                    this.ctx.fillRect(tx + ts - 3, ty + ts - 5, 2, 4);

                    // Ícone da tarefa
                    this.ctx.font = '16px sans-serif';
                    this.ctx.textAlign = 'center';
                    this.ctx.textBaseline = 'middle';
                    this.ctx.fillText(icon, tx + 16, ty + 16 - pulse);
                }

                this.ctx.restore();
            });

            // 3. Banner Flutuante de Instrução e Contagem: "[Solte o botão para executar]"
            if (lastPlot) {
                const bx = Math.min(Math.max(lastPlot.x * ts + 16, 95), this.canvas.width - 95);
                const by = Math.max(lastPlot.y * ts - 26, 32);

                this.ctx.save();
                const textMain = validCount > 0 
                    ? `${actionLabel} (${validCount})` 
                    : 'Nenhum canteiro válido ao alcance';
                const textSub = validCount > 0 
                    ? 'Solte o botão para executar ↵' 
                    : 'Aproxime-se do canteiro';

                this.ctx.font = 'bold 12px Fredoka, sans-serif';
                const tw1 = this.ctx.measureText(textMain).width;
                this.ctx.font = 'bold 10px Nunito, sans-serif';
                const tw2 = this.ctx.measureText(textSub).width;
                const bannerW = Math.max(tw1, tw2) + 24;
                const bannerH = 34;

                this.ctx.fillStyle = 'rgba(255, 243, 207, 0.98)';
                this.ctx.strokeStyle = '#5a3115';
                this.ctx.lineWidth = 2;
                this.ctx.beginPath();
                if (this.ctx.roundRect) {
                    this.ctx.roundRect(bx - bannerW / 2, by - bannerH / 2, bannerW, bannerH, 6);
                } else {
                    this.ctx.rect(bx - bannerW / 2, by - bannerH / 2, bannerW, bannerH);
                }
                this.ctx.fill();
                this.ctx.stroke();

                this.ctx.fillStyle = '#3e1f0b';
                this.ctx.font = 'bold 12px Fredoka, sans-serif';
                this.ctx.textAlign = 'center';
                this.ctx.textBaseline = 'top';
                this.ctx.fillText(textMain, bx, by - bannerH / 2 + 4);

                this.ctx.fillStyle = validCount > 0 ? '#15803d' : '#b91c1c';
                this.ctx.font = 'bold 10px Nunito, sans-serif';
                this.ctx.fillText(textSub, bx, by - bannerH / 2 + 18);

                this.ctx.restore();
            }
        } else if (isHoveringSoil && !soil.active) {
            // Mira Stardew Valley quando o mouse apenas sobrevoa
            const plot = state.farmPlots.find(pt => pt.x === soil.hoverTile.tileX && pt.y === soil.hoverTile.tileY);
            if (plot) {
                const tx = plot.x * ts;
                const ty = plot.y * ts;
                const dist = Math.hypot((tx + 16) - px, (ty + 16) - py);
                const inRange = dist <= reachRadius;

                this.ctx.save();
                this.ctx.strokeStyle = inRange ? '#facc15' : 'rgba(239, 68, 68, 0.7)';
                this.ctx.lineWidth = 2;
                this.ctx.strokeRect(tx + 2, ty + 2, ts - 4, ts - 4);

                if (!inRange) {
                    this.ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
                    this.ctx.fillRect(tx + 2, ty + 2, ts - 4, ts - 4);
                }
                this.ctx.restore();
            }
        }
    }
}

window.GameRenderer = GameRenderer;
