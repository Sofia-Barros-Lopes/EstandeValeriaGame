/**
 * VALE DO CREPÚSCULO - REBANHO DE VACAS
 * 3 vaquinhas (caramelo, malhada e roxa) que andam, descansam e podem ser acariciadas no celeiro.
 * Os sprites vêm de folhas (sprite sheets) em assets/cow_*.png; os retângulos dos frames estão em BOXES.
 */
(function () {
    const BOXES = {"brown": [[92, 40, 189, 258], [352, 51, 314, 242], [743, 41, 193, 257], [122, 338, 124, 174], [348, 338, 129, 174], [553, 337, 123, 181], [726, 358, 206, 160], [133, 583, 134, 175], [348, 583, 129, 180], [552, 584, 123, 179], [752, 584, 133, 179], [46, 783, 139, 175], [266, 854, 211, 99], [543, 803, 195, 146], [794, 786, 194, 173]], "white": [[92, 41, 189, 256], [352, 51, 314, 241], [743, 41, 193, 256], [123, 338, 123, 174], [348, 339, 129, 173], [553, 338, 123, 179], [727, 358, 205, 159], [133, 583, 134, 175], [348, 583, 127, 180], [552, 584, 124, 178], [752, 583, 133, 180], [46, 783, 139, 175], [266, 855, 211, 98], [542, 803, 196, 145], [794, 786, 194, 173]], "purple": [[75, 34, 162, 204], [381, 39, 272, 198], [781, 35, 163, 205], [90, 284, 126, 142], [336, 285, 123, 137], [562, 286, 137, 141], [808, 286, 116, 142], [50, 464, 203, 128], [296, 465, 201, 127], [530, 466, 204, 130], [777, 466, 192, 126], [97, 629, 114, 147], [336, 629, 112, 146], [556, 634, 142, 141], [797, 634, 136, 141], [70, 807, 148, 174], [275, 864, 189, 112], [490, 848, 209, 127], [741, 867, 123, 133], [883, 868, 122, 132]]};

    // Mapeamento dos frames de cada vaca (índices em BOXES). 'side' = virada para a DIREITA (esquerda é espelhada)
    const DEFS = {
        brown:  { name: 'Caramelo', img: 'assets/cow_brown.png',  down: [3, 4], up: [8, 9],  side: [6],           sit: 11, sleep: 13, happy: 14 },
        white:  { name: 'Leitinho', img: 'assets/cow_white.png',  down: [3, 4], up: [8, 9],  side: [6],           sit: 11, sleep: 13, happy: 14 },
        purple: { name: 'Violeta',  img: 'assets/cow_purple.png', down: [3, 4], up: [6, 11], side: [8, 9, 10, 9], sit: 15, sleep: 17, happy: 19 }
    };
    const TARGET_H = 46;      // altura (px do jogo) de uma vaca em pé, de frente
    const SPEED = 24;         // px por segundo ao caminhar
    const STEP_TIME = 0.22;   // segundos por frame de caminhada

    class CowHerd {
        constructor() {
            this.cows = [];
            this.images = {};
            this.bounds = null;
            this.last = 0;
            Object.keys(DEFS).forEach(k => {
                const img = new Image();
                img.src = DEFS[k].img;
                this.images[k] = img;
            });
        }

        // Define a área de passeio (em px) dentro do cercado: x/y são os PÉS da vaca
        setPen(pen, ts) {
            const left = pen.x1 * ts, right = (pen.x2 + 1) * ts, top = pen.y1 * ts, bottom = (pen.y2 + 1) * ts;
            const b = { minX: left + 50, maxX: right - ts - 30, minY: top + 56, maxY: bottom - ts + 2 };
            const same = this.bounds && this.bounds.minX === b.minX && this.bounds.maxX === b.maxX &&
                this.bounds.minY === b.minY && this.bounds.maxY === b.maxY;
            this.bounds = b;
            if (!this.cows.length || !same) this.spawn();
        }

        spawn() {
            const b = this.bounds, w = b.maxX - b.minX, h = b.maxY - b.minY;
            const spots = [[0.12, 0.25], [0.5, 0.9], [0.88, 0.35]];
            this.cows = Object.keys(DEFS).map((type, i) => ({
                type, name: DEFS[type].name,
                x: b.minX + w * spots[i][0], y: b.minY + h * spots[i][1],
                dir: ['down', 'right', 'left'][i], mode: 'idle', t: 0.5 + i * 0.7,
                step: 0, stepT: 0, phase: Math.random() * 6, happyT: 0
            }));
        }

        // Caixa de colisão dos pés (para o jogador não atravessar a vaca)
        body(cow) { return { left: cow.x - 22, right: cow.x + 22, top: cow.y - 10, bottom: cow.y + 4 }; }

        overlap(a, b) { return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top; }

        grow(r, m) { return { left: r.left - m, right: r.right + m, top: r.top - m, bottom: r.bottom + m }; }

        collides(box) { return this.cows.some(c => this.overlap(box, this.body(c))); }

        // Vaca ao alcance do ponto "à frente do jogador" (para acariciar)
        findNear(fx, fy) {
            let best = null, bd = 1e9;
            this.cows.forEach(c => {
                const dx = fx - c.x, dy = fy - (c.y - 18);
                if (Math.abs(dx) <= 36 && Math.abs(dy) <= 36) {
                    const d = dx * dx + dy * dy;
                    if (d < bd) { bd = d; best = c; }
                }
            });
            return best;
        }

        pet(cow) {
            cow.mode = 'happy'; cow.t = 2.6; cow.happyT = 2.6;
        }

        chooseMode(cow) {
            const r = Math.random();
            if (r < 0.58) {
                cow.mode = 'walk';
                cow.t = 1.4 + Math.random() * 2.4;
                const b = this.bounds;
                const opts = [];
                if (cow.x > b.minX + 14) opts.push('left');
                if (cow.x < b.maxX - 14) opts.push('right');
                if (cow.y > b.minY + 10) opts.push('up');
                if (cow.y < b.maxY - 10) opts.push('down');
                cow.dir = opts[Math.floor(Math.random() * opts.length)] || 'down';
            } else if (r < 0.80) {
                cow.mode = 'idle'; cow.t = 1 + Math.random() * 2;
            } else if (r < 0.92) {
                cow.mode = 'sit'; cow.t = 3 + Math.random() * 3;
            } else {
                cow.mode = 'sleep'; cow.t = 4 + Math.random() * 4;
            }
        }

        update(now, playerBox) {
            if (!this.bounds) return;
            let dt = this.last ? (now - this.last) / 1000 : 0;
            this.last = now;
            dt = Math.min(Math.max(dt, 0), 0.05);
            const b = this.bounds;

            this.cows.forEach(cow => {
                cow.phase += dt;
                cow.t -= dt;
                if (cow.mode === 'happy') {
                    cow.happyT -= dt;
                    if (cow.happyT <= 0) { cow.mode = 'idle'; cow.t = 1; }
                    return;
                }
                if (cow.mode === 'walk') {
                    const dx = cow.dir === 'left' ? -1 : cow.dir === 'right' ? 1 : 0;
                    const dy = cow.dir === 'up' ? -1 : cow.dir === 'down' ? 1 : 0;
                    const nx = cow.x + dx * SPEED * dt, ny = cow.y + dy * SPEED * dt;
                    let blocked = nx < b.minX || nx > b.maxX || ny < b.minY || ny > b.maxY;
                    if (!blocked) {
                        const nb = { left: nx - 22, right: nx + 22, top: ny - 10, bottom: ny + 4 };
                        blocked = this.cows.some(o => o !== cow && this.overlap(nb, this.grow(this.body(o), 4))) ||
                            (playerBox && this.overlap(nb, this.grow(playerBox, 4)));
                    }
                    if (blocked) {
                        cow.mode = 'idle'; cow.t = 0.3 + Math.random() * 0.7;
                    } else {
                        cow.x = nx; cow.y = ny;
                        cow.stepT += dt;
                        if (cow.stepT >= STEP_TIME) { cow.stepT = 0; cow.step++; }
                    }
                }
                if (cow.t <= 0) this.chooseMode(cow);
            });
        }

        // Desenha uma vaca com os pés em (cow.x, cow.y)
        draw(ctx, cow) {
            const def = DEFS[cow.type], img = this.images[cow.type];
            if (!img || !img.complete || !img.naturalWidth) return;
            const K = TARGET_H / BOXES[cow.type][def.down[0]][3];

            let idx, flip = false, bob = 0, sy = 1;
            const walking = cow.mode === 'walk';
            if (cow.mode === 'sit') idx = def.sit;
            else if (cow.mode === 'sleep') idx = def.sleep;
            else if (cow.mode === 'happy') { idx = def.happy; flip = cow.dir === 'right'; }
            else if (cow.dir === 'down' || cow.dir === 'up') {
                const list = cow.dir === 'down' ? def.down : def.up;
                idx = walking ? list[cow.step % list.length] : list[0];
                flip = walking && (cow.step % 2 === 1);
            } else {
                idx = walking ? def.side[cow.step % def.side.length] : def.side[0];
                flip = cow.dir === 'left';
            }
            if (walking) bob = -Math.abs(Math.sin((cow.step + cow.stepT / STEP_TIME) * Math.PI)) * 1.8;
            else sy = 1 + Math.sin(cow.phase * 2.2) * 0.012; // respiração

            const f = BOXES[cow.type][idx];
            const dw = f[2] * K, dh = f[3] * K * sy;
            const x = Math.round(cow.x), y = Math.round(cow.y);

            // sombra
            ctx.fillStyle = 'rgba(0,0,0,0.24)';
            ctx.beginPath(); ctx.ellipse(x, y + 1, Math.max(14, dw * 0.38), 5, 0, 0, Math.PI * 2); ctx.fill();

            ctx.save();
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            ctx.translate(x, y + bob);
            if (flip) ctx.scale(-1, 1);
            ctx.drawImage(img, f[0], f[1], f[2], f[3], -dw / 2, -dh, dw, dh);
            ctx.restore();

            // "z z z" subindo quando a vaca roxa dorme (o sprite dela não traz zzz)
            if (cow.mode === 'sleep' && cow.type === 'purple') {
                ctx.fillStyle = '#93c5fd';
                ctx.font = 'bold 10px sans-serif';
                ctx.textAlign = 'center';
                for (let i = 0; i < 3; i++) {
                    const p = (cow.phase * 0.7 + i / 3) % 1;
                    ctx.globalAlpha = 1 - p;
                    ctx.fillText('z', x + 14 + p * 8 + i * 3, y - dh - 2 - p * 14);
                }
                ctx.globalAlpha = 1;
            }
        }
    }

    window.CowHerd = CowHerd;
    window.cowHerd = new CowHerd();
})();
