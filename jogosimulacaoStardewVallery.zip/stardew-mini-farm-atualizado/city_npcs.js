/**
 * MORADORES DA CIDADE (NPCs do Centro da Cidade)
 * - Sprites em assets/npcs/<id>_<down|up|left|right>.png e retrato em assets/npcs/<id>_avatar.png
 * - (fx, fy) = posição dos PÉS no mapa da cidade (px). O jogo converte para a caixa 32x32 do NPC.
 * - Aperte [E] perto deles para conversar.
 */
window.TOWN_NPCS = [
    { id: 'arthur',  name: 'Arthur',  title: 'Vizinho · Casa azul-escura', fx: 292,  fy: 902, dir: 'down',  anim: 0.2 },
    { id: 'pietro',  name: 'Pietro',  title: 'Vizinho · Casa laranja',    fx: 226,  fy: 606, dir: 'down',  anim: 1.1 },
    { id: 'daniel',  name: 'Daniel',  title: 'Vizinho · Casa azul',       fx: 452,  fy: 694, dir: 'down',  anim: 2.0 },
    { id: 'mary',    name: 'Mary',    title: 'Vizinha · Casa vermelha',   fx: 1100, fy: 608, dir: 'down',  anim: 0.7 },
    { id: 'evelyn',  name: 'Evelyn',  title: 'Vizinha · Casa roxa',       fx: 1424, fy: 608, dir: 'down',  anim: 1.6 },
    { id: 'thiago',  name: 'Thiago',  title: 'Vizinho · Casa azul',       fx: 1090, fy: 906, dir: 'down',  anim: 2.6 },
    { id: 'joao',    name: 'João',    title: 'Vizinho · Casa marrom',     fx: 1426, fy: 908, dir: 'down',  anim: 3.1 },
    { id: 'padre',   name: 'Padre',   title: 'Padre da Cidade',           fx: 672,  fy: 352, dir: 'down',  anim: 0.4 },
    { id: 'regina',  name: 'Regina',  title: 'Dona do Mercado',           fx: 1152, fy: 354, dir: 'down',  anim: 1.4 },
    { id: 'antonie', name: 'Dr. Antonie Wilson', title: 'Médico do Hospital', fx: 380, fy: 320, dir: 'down', anim: 0.9 },
    { id: 'princesa', name: 'Princesa', title: 'Gatinha da Evelyn',       fx: 1470, fy: 640, dir: 'down', anim: 1.8, isPet: true }
].map(n => ({
    ...n,
    avatar: `assets/npcs/${n.id}_avatar.png`,
    sprites: {
        down: `assets/npcs/${n.id}_down.png`, up: `assets/npcs/${n.id}_up.png`,
        left: `assets/npcs/${n.id}_left.png`, right: `assets/npcs/${n.id}_right.png`
    }
}));

// Falas (rodam em sequência a cada conversa)
window.TOWN_DIALOGUES = {
    arthur: [
        "Fala, vizinho! Aqui no Vale do Crepúsculo todo mundo se ajuda.",
        "Sou professor, então nas horas vagas sempre tenho que carpir meu jardim... mas eu adio o máximo que posso, haha!",
        "Tenho uma noiva incrível que vive usando o meu Spotify e bagunçando todo o meu algoritmo de recomendações! 😂"
    ],
    pietro: [
        "Oi! Eu moro aqui na casa laranja, bem em cima da casa do Arthur.",
        "Sou da cidade grande, uma pessoa super tranquila e sempre focado nos meus objetivos.",
        "O Daniel e eu morávamos juntos, mas ele foi embora depois que começou a namorar. Hoje somos ótimos amigos!"
    ],
    daniel: [
        "E aí! Eu sou o Daniel, moro na casa azul aqui pertinho do Pietro.",
        "O Pietro e eu morávamos juntos, mas ele foi embora depois que começou a namorar. Ainda nos falamos sempre!",
        "Dizem que morango é o que mais dá lucro. Eu só sei comer, não plantar! 😄"
    ],
    mary: [
        "Oi, oi! Eu sou a Mary. Moro na casa vermelha, ao lado da Evelyn.",
        "Eu adoro desenhar, escutar música, desenvolver jogos e sair com o meu namorado, o Thiago.",
        "A Evelyn é minha melhor amiga desde a faculdade! A gente sempre toma um café juntas."
    ],
    evelyn: [
        "Olá! Eu sou a Evelyn, da casa roxa. Que bom ver uma cara nova por aqui!",
        "Eu encontrei a Princesa na faculdade e agora ela é minha companheira fiel. Ela é a coisa mais fofa!",
        "Gosto de sair para fazer compras e, quando dá, ficar em casa maratonando séries com a Princesa no colo."
    ],
    thiago: [
        "Fala! Thiago aqui, da casa azul embaixo da casa da Mary.",
        "A Mary é minha namorada. Eu tenho uma moto e adoro dar rolês por aí.",
        "Gosto muito de jogar e desenvolver jogos. Quem sabe um dia a gente não cria um jogo juntos?"
    ],
    joao: [
        "Fala, tudo certo? Eu sou o João, da casa marrom, bem no cantinho da cidade.",
        "Gosto de ficar em casa e ficar jogando. É meu passatempo favorito!",
        "O Thiago mora aqui do lado, a gente vive trocando ideia na praça."
    ],
    padre: [
        "Que a paz esteja com você. A igreja está sempre de portas abertas.",
        "Agradecer pela colheita faz bem ao coração, meu filho.",
        "Os sinos tocam todo fim de tarde. Passe por aqui para um momento de calma."
    ],
    regina: [
        "Bem-vindo ao Meu Mercado! Sementes fresquinhas e móveis bonitos, é só entrar!",
        "Quem planta com carinho colhe em dobro. Pode acreditar!",
        "Entre pela porta do Mercado e dê uma olhada na vitrine. Tenho novidades!"
    ],
    antonie: [
        "Olá! Sou o Dr. Antonie Wilson. Sou o médico responsável por este hospital.",
        "Se você se machucar na fazenda, pode vir que eu cuido de tudo. Mas cuidado com o cansaço, hein?",
        "Dizem que a Princesa da Evelyn é a gata mais fofa da cidade. Confesso que concordo!"
    ],
    princesa: [
        "Miau! 🐾 *Princesa esfrega a cabeça na sua perna*",
        "Miau miau! 🐱 *Ela parece muito feliz em ver você*",
        "Prrr... 🐈 *A gatinha ronrona baixinho*"
    ]
};