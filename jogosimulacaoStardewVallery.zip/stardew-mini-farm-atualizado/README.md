# 🌾 Vale do Crepúsculo - Mini RPG de Fazenda & Decoração

Uma experiência web completa, imersiva e funcional de simulação e RPG de fazenda inspirada no clássico **Stardew Valley**, desenvolvida em **HTML5 Canvas 2D**, **CSS3 moderno** e **Vanilla JavaScript**, sem nenhuma dependência externa pesada.

---

## 🧑‍🌾 Personagens Oficiais Disponíveis (Luis, Sofia e Rebeca)

O jogo inclui os 3 personagens das ilustrações oficiais, agora com **sprites 100% transparentes (sem quadrados escuros de fundo)** e **cabelos de textura preservada com opacidade total**:

1. **Luis (Fazendeiro Clássico):**
   - Veste camisa xadrez azul e branca, macacão jeans com barra dobrada, chapéu de palha com cinto de couro marrom e botas de couro.
2. **Sofia (Guardiã Botânica):**
   - Cachos castanhos ondulados, suéter listrado rosa e branco, macacão jeans e chapéu de palha com laço delicado.
3. **Rebeca (Mestra da Terra):**
   - Volumosos cachos escuros radiantes, camisa quadriculada bege, macacão jeans azul e chapéu de palha rústico.

> [!TIP]
> **Interação com Companheiros (NPCs):** Os dois personagens que você não estiver controlando no momento caminham e ficam presentes na fazenda e na casa como NPCs! Aproxime-se e aperte **E** para conversar com eles, receber dicas valiosas ou até mesmo trocar de protagonista na hora!
> Você também pode alternar entre qualquer um dos 3 personagens a qualquer momento clicando no **Avatar no topo da tela** ou apertando a tecla **C**!

---

## 🎮 Principais Mecânicas do Jogo

### 1. 🚶 Movimentação Livre e Mapa Aberto
- **Controle Total:** Movimente o avatar usando as teclas **WASD** ou as **Setas do Teclado**.
- **Animações em 4 Direções:** Sprites fiéis para Cima, Baixo, Esquerda e Direita com animação de passada suave.
- **Sistema de Colisão Fiel:** Bounding boxes que impedem atravessar cercas, árvores, lago, paredes, móveis sólidos e os outros companheiros na fazenda.

### 2. 💬 Sistema de Diálogos Stardew Valley
- Aproxime-se de qualquer companheiro (Luis, Sofia ou Rebeca) e aperte **E** para abrir uma charmosa caixa de diálogo com retrato do personagem, título e falas únicas sobre o dia, dicas de colheita e clima.
- Botão instantâneo no diálogo para assumir o controle do personagem com quem você está conversando.

### 3. 🏠 Transição de Cenários (Fazenda <-> Interior da Casa)
- **Exterior (Fazenda):** Canteiros aráveis, baú de remessa comercial (*shipping bin*), lago de água cristalina, árvores frutíferas e a casa de campo.
- **Interior da Casa:** Entre pela porta para acessar o quarto aconchegante com piso de madeira, papel de parede violeta e janelas iluminadas.

### 🛋️ Móveis Temáticos (Gata Preta, Gata Rosa e Cachorro Caramelo)
- Na aba **Móveis & Decoração** do Mercado (tecla **M**, botão do HUD ou Mercado da cidade) há filtros por conjunto: Clássicos, Gata Preta, Gata Rosa e Cachorro Caramelo.
- Cada conjunto tem camas, cômoda, mesas, cadeiras, sofá, poltrona, estante, luminária, tapete, janela, relógio, quadro, caminha, tigelas e árvore de brincar, todos com sprites em pixel art.
- Dados em `furniture_sets.js`; imagens em `assets/furniture/`.

### 🏙️ Centro da Cidade (ao lado direito da Fazenda)
- **Como chegar:** na fazenda, siga a estrada de pedra pela **borda direita** (placa "CIDADE ➡️"). Você chega ao Centro pela ponte do lado oeste. Para voltar, ande para a esquerda na mesma ponte (ou aperte **E** perto dela).
- **Mundo expansivo:** mapa grande (1536×1024 px) com câmera que acompanha o personagem, revelando o cenário conforme você explora.
- **O que fazer:**
  - 🛒 **Mercado:** **E** na entrada abre a loja (sementes e, na outra aba, móveis e decoração).
  - 🏥 **Hospital:** **E** na porta recupera 100% da energia.
  - ⛪ **Igreja**, ⛲ **chafariz** e 🏡 **casas dos moradores** (portas trancadas): interações de ambientação.
- **Arquivos:** imagem em `assets/city_world.png`; colisão e interações em `city_world.js` (grade de 16 px, igual ao `farm_world.js`).

### 4. 🛋️ Modo Decoração de Casa (Customização Total)
- **Catálogo de Móveis:** Camas reais roxas, sofás anil aveludados, mesas de carvalho com toalha violeta, tapetes astrais e azuis (caminháveis), vasos de samambaia, estantes de livros e abajures de cristal ametista.
- **Drag-and-Drop:** Arraste móveis do seu inventário diretamente para o chão da casa com grade indicativa e pré-visualização em tempo real (verde para locais livres, vermelho para locais bloqueados).
- **Recolhimento Rápido:** Clique com o **botão direito do mouse** em qualquer móvel para devolvê-lo ao seu inventário de decoração.

### 5. 🎒 Hotbar de Inventário Estilo Stardew Valley
- **Caixas na Tela do Jogo:** Hotbar de 12 slots em madeira moldada com acabamento rústico e cursor ativo vermelho clássico do Stardew Valley, posicionada diretamente na tela do jogo.
- **Ferramentas Básicas:** Enxada (⛏️ [1]), Regador (💧 [2]), Foice de Colheita (✂️ [3]).
- **Alimentos e Sementes:** Sementes de Cenoura (🥕 [4]), Morango (🍓 [5]), Milho (🌽 [6]), Abóbora (🎃 [7]).
- **Colheitas no Estoque:** Alimentos frescos colhidos (Cenoura [8], Morango [9], Milho [0], Abóbora [-]) e Baú de Vendas ([=]).
- **Contador em Tempo Real:** Quantidade disponível visível no canto de cada caixa com atualização instantânea ao comprar sementes ou colher.
- **Transparência Dinâmica:** Ao caminhar para perto do fundo da tela, a hotbar fica sutilmente translúcida para nunca cobrir o personagem.
- **Roda do Mouse:** Gire a roda do mouse para alternar e equipar itens rapidamente!

### 6. 🌱 Interação com o Solo por Seleção e Marcações de Alcance (Soltar para Executar)
- **Seleção com o Mouse:** Clique e arraste o mouse sobre qualquer canteiro que desejar arar, regar, plantar ou colher. Você pode selecionar canteiros individuais ou múltiplos em área arrastando sobre eles.
- **Marcações Visuais de Alcance:**
  - **Aura de Alcance (Dourada):** Mostra o raio exato até onde o fazendeiro consegue trabalhar sem se deslocar.
  - **Canteiros ao Alcance:** Cantoneiras pixel art no estilo Stardew Valley iluminam a terra com a cor da ação correspondente (Dourado para Arar ⛏️, Ciano para Regar 💧, Verde para Plantar 🌱, Amarelo para Colher ✂️).
  - **Fora de Alcance (`🚫`):** Canteiros selecionados além da distância de alcance aparecem marcados em vermelho com aviso para se aproximar.
  - **Banner Flutuante:** Exibe a ação planejada, a quantidade de canteiros válidos e a instrução: *"Solte o botão para executar ↵"*.
- **Execução Somente ao Soltar:** A tarefa **só é realizada quando o jogador solta o botão** do mouse (`mouseup`) ou a tecla de interação (`keyup`). Se você mudar de ideia antes de soltar, basta apertar `Esc` ou clicar com o botão direito para cancelar sem gastar sementes ou energia.
- **Seleção pelo Teclado:** Segure `E` ou `Espaço` em frente a um canteiro para ver a mira e marcações; solte a tecla para efetuar o trabalho.

### 7. 💰 Economia & Mercado do Vilarejo
- **Baú de Vendas:** Fique em frente ao baú de madeira ao lado da casa e pressione `E` para vender todas as colheitas guardadas por ouro imediato.
- **Mercado do Vilarejo (`M`):** Duas abas para compra de sementes e novos móveis para a casa.

### 8. 🌙 Ciclo de Dormir & Clima
- **Dormir na Cama Imperial:** Interaja com a cama dentro de casa para avançar para o próximo dia.
- **Clima Dinâmico:** 25% de chance de chuva (`🌧️`), regando **todos os canteiros da fazenda automaticamente**!

---

## ⌨️ Tabela de Controles

| Tecla / Ação | Função |
| :--- | :--- |
| **`W`, `A`, `S`, `D`** ou **Setas** | Movimentar o personagem |
| **Clique & Arraste do Mouse** | Selecionar canteiros de solo (arar, regar, plantar, colher); executa ao soltar |
| **`E`** ou **`Espaço` (Segurar e Soltar)** | Seleção de solo via teclado (marca alcance e executa ao soltar); ou interagir com NPCs, portas, baú e cama |
| **Botão Direito do Mouse** ou **`Esc`** | Cancelar seleção de solo em andamento / recolher móveis na casa |
| **`1` a `7`** | Selecionar Ferramentas & Sementes (Enxada, Regador, Foice, Cenoura, Morango, Milho, Abóbora) |
| **`8`, `9`, `0`, `-`, `=`** | Selecionar Alimentos Colhidos e Baú de Vendas na Hotbar |
| **Roda do Mouse** | Alternar rapidamente entre as caixas de inventário da Hotbar |
| **`C`** | Abrir Menu de Troca de Personagem (Luis, Sofia, Rebeca) |
| **`F`** ou Botão **`⛶`** | Alternar Tela Cheia (Fullscreen Responsivo) |
| **Botão `🔊 / 🔇`** | Ativar / Desativar Música Ambiente e Efeitos Sonoros |
| **`M`** | Abrir Mercado do Vilarejo |
| **`Esc`** | Fechar janelas ou sair do Modo Decoração |

---

## 🚀 Como Executar

Basta abrir o arquivo [index.html](file:///c:/Users/bv3058735.AD/Desktop/stardew-mini-farm-atualizado/index.html) em qualquer navegador web moderno.


## Plantação em pixel art (visual)

A terra e as plantas são desenhadas por código a partir de tiles/sprites (nada de imagem estática):

- `assets/soil_tiles.png` — tiles 32x32 de terra vazia, arada e regada, com 16 máscaras de vizinhança
  (bordas externas irregulares, miolo contínuo) e 3 variações cada.
- `assets/crops_sheet.png` — plantas 32x48 (cenoura, morango, milho, abóbora) em 4 estágios:
  semente, broto, crescendo e pronta para colher.
- `renderer.js` → `renderSoilPlots()` (autotile) e `renderCrop()` (estágio pelo progresso do cultivo).
- `tools/gen_soil_art.py` — gera os dois PNGs (`python3 tools/gen_soil_art.py`); edite as paletas ali
  para mudar o visual. Uma nova cultura só precisa de uma linha nova em `crops_sheet.png` e do id em
  `ROWS` dentro de `renderCrop()`.
